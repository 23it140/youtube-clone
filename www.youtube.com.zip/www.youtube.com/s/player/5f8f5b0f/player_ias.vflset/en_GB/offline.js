(function(g) {
    var window = this;
    'use strict';
    var Jkb = function(a) {
            var b = new g.qL("und", new g.uN("Default", "und", !0));
            b.captionTracks = a.captionTracks;
            return b
        },
        Kkb = function(a) {
            return new g.pi(function(b, c) {
                var d = a.length,
                    e = [];
                if (d)
                    for (var f = function(n, p) {
                            d--;
                            e[n] = p;
                            d == 0 && b(e)
                        }, h = function(n) {
                            c(n)
                        }, l = 0, m; l < a.length; l++) m = a[l], g.nfa(m, g.Wa(f, l), h);
                else b(e)
            })
        },
        M5 = function(a) {
            this.j = a
        },
        N5 = function() {
            M5.apply(this, arguments)
        },
        Lkb = function() {
            N5.apply(this, arguments)
        },
        Mkb = function() {
            N5.apply(this, arguments)
        },
        Nkb = function() {
            N5.apply(this, arguments)
        },
        Okb = function() {
            N5.apply(this, arguments)
        },
        Pkb = function() {
            M5.apply(this, arguments)
        },
        Qkb = function() {
            N5.apply(this, arguments)
        },
        Rkb = function() {
            N5.apply(this, arguments)
        },
        Skb = function() {
            N5.apply(this, arguments)
        },
        Tkb = function() {
            N5.apply(this, arguments)
        },
        Ukb = function() {
            N5.apply(this, arguments)
        },
        Vkb = function() {
            N5.apply(this,
                arguments)
        },
        Wkb = function() {
            N5.apply(this, arguments)
        },
        Xkb = function() {
            N5.apply(this, arguments)
        },
        Ykb = function() {
            N5.apply(this, arguments)
        },
        Zkb = function() {
            N5.apply(this, arguments)
        },
        $kb = function() {
            N5.apply(this, arguments)
        },
        alb = function() {
            M5.apply(this, arguments)
        },
        blb = function() {
            N5.apply(this, arguments)
        },
        clb = function() {
            N5.apply(this, arguments)
        },
        dlb = function() {
            N5.apply(this, arguments)
        },
        elb = function() {
            N5.apply(this, arguments)
        },
        flb = function() {
            N5.apply(this, arguments)
        },
        glb = function() {
            N5.apply(this, arguments)
        },
        hlb = function() {
            N5.apply(this, arguments)
        },
        ilb = function() {
            N5.apply(this, arguments)
        },
        jlb = function() {
            N5.apply(this, arguments)
        },
        klb = function() {
            M5.apply(this, arguments)
        },
        llb = function() {
            M5.apply(this, arguments)
        },
        mlb = function() {
            M5.apply(this, arguments)
        },
        nlb = function() {
            N5.apply(this, arguments)
        },
        olb = function() {
            N5.apply(this, arguments)
        },
        plb = function() {
            N5.apply(this, arguments)
        },
        qlb = function() {
            N5.apply(this, arguments)
        },
        rlb = function() {
            N5.apply(this, arguments)
        },
        slb = function() {
            N5.apply(this, arguments)
        },
        tlb = function() {
            N5.apply(this,
                arguments)
        },
        ulb = function() {
            N5.apply(this, arguments)
        },
        vlb = function() {
            N5.apply(this, arguments)
        },
        wlb = function() {
            N5.apply(this, arguments)
        },
        xlb = function() {
            N5.apply(this, arguments)
        },
        ylb = function() {
            N5.apply(this, arguments)
        },
        zlb = function() {
            N5.apply(this, arguments)
        },
        Alb = function() {
            N5.apply(this, arguments)
        },
        Blb = function() {
            N5.apply(this, arguments)
        },
        Clb = function() {
            N5.apply(this, arguments)
        },
        Dlb = function() {
            N5.apply(this, arguments)
        },
        Elb = function() {
            N5.apply(this, arguments)
        },
        Flb = function() {
            N5.apply(this, arguments)
        },
        Glb = function() {
            N5.apply(this, arguments)
        },
        Hlb = function() {
            N5.apply(this, arguments)
        },
        Ilb = function() {
            N5.apply(this, arguments)
        },
        Jlb = function() {
            N5.apply(this, arguments)
        },
        Klb = function() {
            M5.apply(this, arguments)
        },
        Llb = function() {
            N5.apply(this, arguments)
        },
        Mlb = function() {
            N5.apply(this, arguments)
        },
        Nlb = function() {
            N5.apply(this, arguments)
        },
        Olb = function() {
            N5.apply(this, arguments)
        },
        Plb = function() {
            N5.apply(this, arguments)
        },
        Qlb = function() {
            N5.apply(this, arguments)
        },
        Rlb = function() {
            N5.apply(this, arguments)
        },
        Slb = function() {
            N5.apply(this,
                arguments)
        },
        Tlb = function() {
            N5.apply(this, arguments)
        },
        Ulb = function() {
            N5.apply(this, arguments)
        },
        Vlb = function() {
            N5.apply(this, arguments)
        },
        Wlb = function() {
            N5.apply(this, arguments)
        },
        Xlb = function() {
            N5.apply(this, arguments)
        },
        Ylb = function() {
            N5.apply(this, arguments)
        },
        Zlb = function() {
            N5.apply(this, arguments)
        },
        $lb = function() {
            N5.apply(this, arguments)
        },
        amb = function() {
            N5.apply(this, arguments)
        },
        bmb = function() {
            N5.apply(this, arguments)
        },
        cmb = function() {
            N5.apply(this, arguments)
        },
        dmb = function() {
            N5.apply(this, arguments)
        },
        emb = function() {
            N5.apply(this, arguments)
        },
        fmb = function() {
            N5.apply(this, arguments)
        },
        gmb = function() {
            N5.apply(this, arguments)
        },
        hmb = function() {
            N5.apply(this, arguments)
        },
        imb = function() {
            N5.apply(this, arguments)
        },
        jmb = function() {
            N5.apply(this, arguments)
        },
        kmb = function() {
            N5.apply(this, arguments)
        },
        lmb = function(a) {
            return g.St((0, g.ecb)(), a)
        },
        O5 = function(a) {
            this.token = a
        },
        mmb = function(a) {
            a = a.key || a.id;
            if (!a) throw Error("Entity key is missing");
            return a
        },
        nmb = function() {
            if (P5) return P5();
            var a = {};
            P5 = g.bu("PersistentEntityStoreDb", {
                Gs: (a.EntityStore = {
                    Sn: 1
                }, a.EntityAssociationStore = {
                    Sn: 2
                }, a),
                shared: !1,
                upgrade: function(b, c) {
                    c(1) && g.Kt(g.Et(b, "EntityStore", {
                        keyPath: "key"
                    }), "entityType", "entityType");
                    c(2) && (b = g.Et(b, "EntityAssociationStore", {
                        keyPath: ["parentEntityKey", "childEntityKey"]
                    }), g.Kt(b, "byParentEntityKey", "parentEntityKey"), g.Kt(b, "byChildEntityKey", "childEntityKey"))
                },
                version: 3
            });
            return P5()
        },
        omb = function(a) {
            return g.St(nmb(), a)
        },
        Q5 = function(a, b) {
            b = b === void 0 ? {} : b;
            g.Us.call(this, g.mcb[a], Object.assign({}, {
                name: "PESEncoderError",
                type: a
            }, b));
            this.type = a;
            this.level = "WARNING";
            Object.setPrototypeOf(this, Q5.prototype)
        },
        pmb = function(a) {
            return new Q5("WRONG_DATA_TYPE", {
                F8: a
            })
        },
        qmb = function(a) {
            return a instanceof Error ? new Q5("UNKNOWN_ENCODE_ERROR", {
                ZS: a.message
            }) : new Q5("UNKNOWN_ENCODE_ERROR")
        },
        rmb = function(a) {
            return a instanceof Error ? new Q5("UNKNOWN_DECODE_ERROR", {
                ZS: a.message
            }) : new Q5("UNKNOWN_DECODE_ERROR")
        },
        smb = function(a, b) {
            a = a instanceof Q5 ? a : b(a);
            g.Hw(a);
            throw a;
        },
        tmb = function() {},
        umb = function(a, b, c) {
            try {
                return a.C(b, c)
            } catch (d) {
                smb(d, qmb)
            }
        },
        vmb = function(a) {
            a = (new TextEncoder).encode(a).subarray(0, 16);
            var b = new Uint8Array(16);
            b.set(a);
            return b
        },
        R5 = function(a) {
            this.j = a
        },
        xmb = function(a) {
            var b = wmb[a];
            if (b) return b;
            g.Iw(new g.Us("Entity model not found.", {
                entityType: a
            }))
        },
        ymb = function(a, b) {
            this.j = a;
            this.B = b;
            this.C = {}
        },
        Amb = function(a, b) {
            a: {
                a = zmb(a.B, b.version);
                try {
                    var c = a.B(b.data, b.key);
                    break a
                } catch (d) {
                    smb(d, rmb)
                }
                c = void 0
            }
            return c
        },
        S5 = function(a, b, c) {
            return a.j.objectStore("EntityStore").get(b).then(function(d) {
                if (d) {
                    if (c && d.entityType !== c) throw Error("Incorrect entity type");
                    return Amb(a, d)
                }
            })
        },
        T5 = function(a, b, c) {
            return c ? (c = c.map(function(d) {
                return S5(a, d, b)
            }), g.zt.all(c)) : a.j.objectStore("EntityStore").index("entityType").getAll(IDBKeyRange.only(b)).then(function(d) {
                return d.map(function(e) {
                    return Amb(a, e)
                })
            })
        },
        V5 = function(a, b, c) {
            var d = mmb(b),
                e = zmb(a.B, 1),
                f = Object.assign({}, b);
            return a.j.objectStore("EntityStore").get(d).then(function(h) {
                if (h) {
                    if (h.entityType !== c) throw Error("Incorrect entity type");
                    f.entityMetadata || (h = Amb(a, h), f.entityMetadata = h.entityMetadata)
                }
            }).then(function() {
                var h = {
                    key: d,
                    entityType: c,
                    data: umb(e, f, d),
                    version: 1
                };
                return g.zt.all([g.Ht(a.j.objectStore("EntityStore"), h), Bmb(a, f, c)])
            }).then(function() {
                U5(a, d, c);
                return d
            })
        },
        Cmb = function(a, b, c) {
            b = b.map(function(d) {
                return V5(a, d, c)
            });
            return g.zt.all(b)
        },
        W5 = function(a, b, c) {
            if (c == null ? 0 : c.Yw) {
                var d = new Set;
                return Dmb(a, b, d).then(function() {
                    for (var f = [], h = g.w(d), l = h.next(); !l.done; l = h.next()) f.push(W5(a, l.value));
                    return g.zt.all(f).then(function() {})
                })
            }
            var e = g.FK(b).entityType;
            return g.zt.all([a.j.objectStore("EntityStore").delete(b), Emb(a, b)]).then(function() {
                U5(a, b, e)
            })
        },
        Fmb = function(a, b) {
            return g.Ot(a.j.objectStore("EntityStore").index("entityType"), {
                query: IDBKeyRange.only(b)
            }, function(c) {
                return g.zt.all([c.delete(),
                    Emb(a, c.cursor.primaryKey)
                ]).then(function() {
                    U5(a, c.cursor.primaryKey, b);
                    return g.Mt(c)
                })
            })
        },
        Gmb = function(a, b, c, d) {
            var e = zmb(a.B, 1);
            return S5(a, b, d).then(function(f) {
                if (f) {
                    f = g.YJ(f, c);
                    var h = {
                        key: b,
                        entityType: d,
                        data: umb(e, f, b),
                        version: 1
                    };
                    return g.zt.all([g.Ht(a.j.objectStore("EntityStore"), h), Bmb(a, f, d)])
                }
            }).then(function() {
                U5(a, b, d);
                return b
            })
        },
        U5 = function(a, b, c) {
            var d = a.C[c];
            d || (d = new Set, a.C[c] = d);
            d.add(b)
        },
        Hmb = function(a, b, c) {
            var d = mmb(b);
            c = xmb(c);
            if (!c) return g.zt.resolve([]);
            c = new c(b);
            a = a.j.objectStore("EntityAssociationStore");
            b = [];
            c = g.w(c.B());
            for (var e = c.next(); !e.done; e = c.next()) b.push(g.Ht(a, {
                parentEntityKey: d,
                childEntityKey: e.value
            }));
            return g.zt.all(b).then(function(f) {
                return f.map(function(h) {
                    return h[1]
                })
            })
        },
        Emb = function(a, b) {
            return a.j.objectStore("EntityAssociationStore").index("byParentEntityKey").delete(IDBKeyRange.only(b))
        },
        Bmb = function(a, b, c) {
            var d = mmb(b);
            return Emb(a, d).then(function() {
                return Hmb(a, b, c)
            })
        },
        Dmb = function(a, b, c) {
            if (c.has(b)) return g.zt.resolve(void 0);
            c.add(b);
            return Imb(a, b).then(function(d) {
                return a.j.objectStore("EntityAssociationStore").index("byParentEntityKey").delete(IDBKeyRange.only(b)).then(function() {
                    return d
                })
            }).then(function(d) {
                var e = g.zt.resolve(void 0);
                d = g.w(d);
                for (var f = d.next(), h = {}; !f.done; h = {
                        j1: void 0
                    }, f = d.next()) h.j1 = f.value, e = e.then(function(l) {
                    return function() {
                        return Dmb(a, l.j1, c)
                    }
                }(h));
                return e
            }).then(function() {})
        },
        Imb = function(a, b) {
            var c = a.j.objectStore("EntityAssociationStore");
            return c.index("byParentEntityKey").getAll(IDBKeyRange.only(b)).then(function(d) {
                var e = [];
                d = g.w(d);
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, e.push(c.index("byChildEntityKey").getAll(f.childEntityKey));
                return g.zt.all(e)
            }).then(function(d) {
                var e = [];
                d = g.w(d);
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, f.length === 1 && e.push(f[0].childEntityKey);
                return e
            })
        },
        X5 = function() {},
        Jmb = function() {
            this.j = {};
            this.j[0] = new X5;
            if (!g.tr("aes_pes_encoder_killswitch")) {
                var a = this.j;
                try {
                    var b = g.Vs();
                    var c = vmb(b);
                    var d = new R5(new g.UJ(c), new g.TJ(c))
                } catch (e) {
                    throw a = e instanceof Error ? new Q5("KEY_CREATION_FAILED", {
                        ZS: e.message
                    }) : new Q5("KEY_CREATION_FAILED"), g.Hw(a), a;
                }
                a[1] = d
            }
        },
        zmb = function(a, b) {
            b = b === void 0 ? 0 : b;
            a = a.j[b];
            if (!a) throw b = new Q5("INVALID_ENCODER_VERSION", {
                F8: b
            }), g.Hw(b), b;
            return a
        },
        Y5 = function(a, b) {
            g.O.call(this);
            this.token = a;
            this.j = b;
            this.observers = [];
            a = new g.La.BroadcastChannel("PERSISTENT_ENTITY_STORE_SYNC:" + g.Vs());
            a.onmessage = this.B.bind(this);
            this.channel = a
        },
        Z5 = function(a, b, c) {
            var d, e, f, h;
            return g.J(function(l) {
                if (l.j == 1) return g.F(l, omb(a.token), 2);
                if (l.j != 3) return d = l.B, g.F(l, g.Gt(d, ["EntityStore", "EntityAssociationStore"], b, function(m) {
                    e = new ymb(m, a.j);
                    return c(e)
                }), 3);
                f = l.B;
                e && (h = e.C, Object.keys(h).length > 0 && (a.channel.postMessage(h), Kmb(a, h)));
                return l.return(f)
            })
        },
        Lmb = function(a, b) {
            a.observers.push(b);
            return function() {
                var c = a.observers.indexOf(b);
                c >= 0 && a.observers.splice(c, 1)
            }
        },
        $5 = function(a, b, c) {
            return Z5(a, {
                mode: "readwrite",
                Pb: !0
            }, function(d) {
                return V5(d, b, c)
            })
        },
        Mmb = function(a, b) {
            return Z5(a, {
                mode: "readwrite",
                Pb: !0
            }, function(c) {
                return Cmb(c, b, "offlineOrchestrationActionWrapperEntity")
            })
        },
        Nmb = function(a, b) {
            return Z5(a, {
                mode: "readwrite",
                Pb: !0
            }, function(c) {
                return W5(c, b)
            })
        },
        Omb = function(a) {
            return Z5(a, {
                mode: "readwrite",
                Pb: !0
            }, function(b) {
                return Fmb(b, "videoPlaybackPositionEntity")
            })
        },
        a6 = function(a, b, c) {
            return Z5(a, {
                mode: "readonly",
                Pb: !0
            }, function(d) {
                return S5(d, b, c)
            })
        },
        b6 = function(a, b, c) {
            return Z5(a, {
                mode: "readonly",
                Pb: !0
            }, function(d) {
                return T5(d, b, c)
            })
        },
        Kmb = function(a, b) {
            a = g.w(a.observers);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, c(b)
        },
        Pmb = function() {
            var a, b, c;
            return g.J(function(d) {
                if (d.j == 1) return g.wa(d, 2), g.F(d, g.$t(), 4);
                if (d.j != 2) {
                    a = d.B;
                    if (!a || !g.Ws() || typeof g.La.BroadcastChannel === "undefined") return d.return();
                    b = new Jmb;
                    return d.return(new Y5(a, b))
                }
                c = g.ya(d);
                c instanceof Error && g.Hw(c);
                return d.return()
            })
        },
        c6 = function() {
            Qmb || (Qmb = Pmb());
            return Qmb
        },
        Rmb = function(a) {
            var b;
            a = (b = a.options) == null ? void 0 : b.persistenceOption;
            return a === "ENTITY_PERSISTENCE_OPTION_PERSIST" || a === "ENTITY_PERSISTENCE_OPTION_INMEMORY_AND_PERSIST"
        },
        Smb = function(a) {
            var b;
            return g.J(function(c) {
                return c.j == 1 ? g.F(c, c6(), 2) : (b = c.B) ? g.F(c, Z5(b, "readwrite", function(d) {
                    for (var e = {}, f = g.w(a), h = f.next(), l = {}; !h.done; l = {
                            Kk: void 0,
                            HG: void 0
                        }, h = f.next()) l.Kk = h.value, l.Kk.entityKey && Rmb(l.Kk) && (l.HG = g.tg(l.Kk.payload), h = void 0, l.Kk.type === "ENTITY_MUTATION_TYPE_REPLACE" && (h = function(m) {
                            return function() {
                                return V5(d, m.Kk.payload[m.HG], m.HG)
                            }
                        }(l)), l.Kk.type === "ENTITY_MUTATION_TYPE_DELETE" && (h = function(m) {
                            return function() {
                                return W5(d, m.Kk.entityKey)
                            }
                        }(l)), l.Kk.type === "ENTITY_MUTATION_TYPE_UPDATE" &&
                        (h = function(m) {
                            return function() {
                                return Gmb(d, m.Kk.entityKey, m.Kk.payload[m.HG], m.HG)
                            }
                        }(l)), h && (e[l.Kk.entityKey] = e[l.Kk.entityKey] ? e[l.Kk.entityKey].then(h) : h()));
                    return g.zt.all(Object.values(e))
                }), 0) : c.return()
            })
        },
        Tmb = function(a) {
            var b;
            return g.J(function(c) {
                if (c.j == 1) {
                    b = a.mutations;
                    if (!b || b.length <= 0) return c.return();
                    if (g.EQ) {
                        var d = {
                            type: "ENTITY_LOADED"
                        };
                        b !== void 0 && (d.payload = b);
                        g.EQ.dispatch(d)
                    }
                    return g.F(c, Smb(b), 2)
                }
                b.length = 0;
                g.va(c)
            })
        },
        Umb = function(a) {
            return a !== void 0
        },
        Vmb = function(a) {
            var b = g.WP();
            b = Object.assign({}, b);
            a = Object.assign({}, a);
            for (var c in b) a[c] ? (b[c] !== 4 && (b[c] = a[c]), delete a[c]) : b[c] !== 2 && (b[c] = 4);
            Object.assign(b, a);
            g.wKa(b);
            JSON.stringify(b);
            return b
        },
        Wmb = function(a) {
            var b, c;
            return g.J(function(d) {
                if (d.j == 1) return g.F(d, g.$t(), 2);
                if (d.j != 3) return (b = d.B) ? g.F(d, g.ZP(b), 3) : d.return();
                c = d.B;
                return d.return(g.Gt(c, ["index", "media", "captions"], {
                    mode: "readwrite",
                    Pb: !0
                }, function(e) {
                    var f = IDBKeyRange.bound(a + "|", a + "~");
                    e = [e.objectStore("index").delete(f), e.objectStore("media").delete(f), e.objectStore("captions").delete(f)];
                    return g.zt.all(e).then(function() {})
                }))
            })
        },
        Xmb = function() {
            var a, b;
            return g.J(function(c) {
                if (c.j == 1) return g.F(c, g.$t(), 2);
                if (c.j != 3) {
                    a = c.B;
                    if (!a) throw g.wt("rvdfd");
                    return g.F(c, g.ZP(a), 3)
                }
                b = c.B;
                return c.return(g.Gt(b, ["index", "media"], {
                    mode: "readwrite",
                    Pb: !0
                }, function(d) {
                    var e = {};
                    return g.Lt(d.objectStore("index"), {}, function(f) {
                        var h = f.cursor.key.match(/^([\w\-_]+)\|(a|v)$/),
                            l = g.zt.resolve(void 0);
                        if (h) {
                            var m = h[1];
                            h = h[2];
                            e[m] = e[m] || {};
                            var n;
                            e[m][h] = g.BKa((n = f.getValue()) == null ? void 0 : n.fmts)
                        } else l = f.delete().then(function() {});
                        return g.zt.all([g.Mt(f), l]).then(function(p) {
                            return g.w(p).next().value
                        })
                    }).then(function() {
                        for (var f = {}, h = g.w(Object.keys(e)), l = h.next(); !l.done; l = h.next()) {
                            l = l.value;
                            var m = e[l].v;
                            f[l] = e[l].a && m ? 1 : 2
                        }
                        var n = Vmb(f);
                        return g.Doa(d.objectStore("media"), {}, function(p) {
                            var q = p.cursor.key.match(g.FKa);
                            q && f[q[1]] || d.objectStore("media").delete(p.cursor.key);
                            return g.uoa(p)
                        }).then(function() {
                            return n
                        })
                    })
                }))
            })
        },
        Ymb = function(a, b) {
            var c, d;
            return g.J(function(e) {
                if (e.j == 1) return g.F(e, g.$t(), 2);
                if (e.j != 3) {
                    c = e.B;
                    if (!c) throw g.wt("wct");
                    return g.F(e, g.ZP(c), 3)
                }
                d = e.B;
                return g.F(e, g.Gt(d, ["captions"], {
                    mode: "readwrite",
                    Pb: !0
                }, function(f) {
                    var h = [];
                    f = f.objectStore("captions");
                    for (var l = 0; l < b.length; l++) {
                        var m = g.Ht(f, b[l], a + "|" + b[l].metadata.vss_id);
                        h.push(m)
                    }
                    return g.zt.all(h)
                }), 0)
            })
        },
        Zmb = function(a) {
            var b, c, d;
            return g.J(function(e) {
                if (e.j == 1) return b = IDBKeyRange.bound(a + "|", a + "~"), g.F(e, g.$t(), 2);
                if (e.j != 3) {
                    c = e.B;
                    if (!c) throw g.wt("gactfv");
                    return g.F(e, g.ZP(c), 3)
                }
                d = e.B;
                return e.return(d.getAll("captions", b))
            })
        },
        $mb = function(a) {
            return g.J(function(b) {
                g.YP(a, 0);
                return b.return(Wmb(a))
            })
        },
        anb = function(a) {
            return {
                context: g.Yy(),
                videoIds: a
            }
        },
        bnb = function(a) {
            return {
                context: g.Yy(),
                playlistIds: a
            }
        },
        cnb = function(a) {
            return {
                context: g.Yy(),
                offlinePlaylistSyncChecks: a
            }
        },
        dnb = function() {
            this.j = new Map
        },
        fnb = function() {
            enb || (enb = new dnb);
            return enb
        },
        gnb = function(a, b) {
            return {
                eventType: {
                    flowEventNamespace: "FLOW_EVENT_NAMESPACE_OFFLINE_ORCHESTRATION",
                    flowEventType: a
                },
                metadata: b,
                statusCode: void 0,
                csn: void 0,
                can: void 0
            }
        },
        hnb = function(a, b, c) {
            if (!c) {
                var d = d === void 0 ? !1 : d;
                c = a.j.get("FLOW_TYPE_OFFLINE_ORCHESTRATION");
                if (!c || d) c = g.vv(16), a.j.set("FLOW_TYPE_OFFLINE_ORCHESTRATION", c)
            }
            a = {
                flowNonce: c,
                flowType: "FLOW_TYPE_OFFLINE_ORCHESTRATION",
                flowEventType: b.eventType
            };
            b.metadata && (a.flowMetadata = b.metadata);
            b.statusCode !== void 0 && (a.flowEventStatus = b.statusCode);
            b.csn && (a.csn = b.csn);
            b.can && (a.can = b.can);
            g.jt("flowEvent", a, void 0)
        },
        inb = function(a) {
            var b, c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb, rb, Za, A, D, E;
            return g.J(function(I) {
                if (I.j == 1) return g.F(I, Z5(a, {
                    mode: "readonly",
                    Pb: !0
                }, function(L) {
                    return T5(L, "playbackData").then(function(Y) {
                        var ha = Y.map(function(qa) {
                                return qa.transfer
                            }).filter(function(qa) {
                                return !!qa
                            }),
                            ca = Y.map(function(qa) {
                                return qa.offlineVideoPolicy
                            }).filter(function(qa) {
                                return !!qa
                            }),
                            K = Y.filter(function(qa) {
                                return !!qa.key
                            }).map(function(qa) {
                                return g.GK(g.FK(qa.key).entityId, "downloadStatusEntity")
                            });
                        ha = T5(L, "transfer", ha);
                        ca = T5(L, "offlineVideoPolicy", ca);
                        K = T5(L, "downloadStatusEntity", K);
                        var la = ha.then(function(qa) {
                            qa = qa.reduce(function(ia, Ka) {
                                (Ka == null ? 0 : Ka.offlineVideoStreams) && ia.push.apply(ia, g.x(Ka.offlineVideoStreams));
                                return ia
                            }, []).filter(function(ia) {
                                return !!ia
                            });
                            return T5(L, "offlineVideoStreams", qa)
                        });
                        return g.zt.all([ha, ca, la, K]).then(function(qa) {
                            var ia = g.w(qa);
                            qa = ia.next().value;
                            var Ka = ia.next().value;
                            var ob = ia.next().value;
                            ia = ia.next().value;
                            return [Y, qa, Ka, ob, ia]
                        })
                    })
                }), 2);
                if (I.j != 3) return b = I.B, g.F(I, Z5(a, {
                    mode: "readonly",
                    Pb: !0
                }, function(L) {
                    return T5(L, "mainDownloadsListEntity").then(function(Y) {
                        var ha, ca;
                        return (ca = (ha = Y[0]) == null ? void 0 : ha.downloads) != null ? ca : []
                    })
                }), 3);
                c = I.B;
                d = g.w(b);
                e = d.next().value;
                f = d.next().value;
                h = d.next().value;
                l = d.next().value;
                m = d.next().value;
                n = e;
                p = f;
                q = h;
                r = l;
                t = m;
                u = {};
                y = {};
                B = {};
                C = {};
                G = {};
                H = [];
                N = g.w(p);
                for (M = N.next(); !M.done; M = N.next())(X = M.value) && (u[X.key] = X);
                W = g.w(q);
                for (fa = W.next(); !fa.done; fa = W.next())(pa = fa.value) && (y[pa.key] = pa);
                ba = g.w(t);
                for (R = ba.next(); !R.done; R = ba.next())(V = R.value) && (B[V.key] = V);
                v = g.w(r);
                for (U = v.next(); !U.done; U = v.next())(bb = U.value) && (C[bb.key] = bb);
                yb = g.w(c);
                for (lb = yb.next(); !lb.done; lb = yb.next()) Ea = lb.value, cb =
                    void 0, G[(cb = Ea.videoItem) != null ? cb : ""] = !0, Ea.videoItem && (Za = rb = void 0, A = (Za = (rb = g.FK(Ea.videoItem)) == null ? void 0 : rb.entityId) != null ? Za : "", H.push({
                        externalVideoId: A
                    }));
                D = n.filter(function(L) {
                    if (!L || !L.key) return !1;
                    L = g.FK(L.key).entityId;
                    L = g.GK(L, "downloadStatusEntity");
                    var Y;
                    return !(L && ((Y = B[L]) == null ? void 0 : Y.downloadState) === "DOWNLOAD_STATE_USER_DELETED")
                });
                E = D.map(function(L) {
                    var Y = u[L.transfer],
                        ha = [];
                    if (Y == null ? 0 : Y.offlineVideoStreams)
                        for (var ca = g.w(Y.offlineVideoStreams), K = ca.next(); !K.done; K = ca.next())(K = C[K.value]) && ha.push(K);
                    ca = y[L.offlineVideoPolicy];
                    K = G;
                    var la = L == null ? void 0 : L.playerResponseTimestamp,
                        qa = g.FK(ca.key).entityId;
                    L = g.GK(qa, "mainVideoEntity");
                    if (ca.action === "OFFLINE_VIDEO_POLICY_ACTION_DISABLE") {
                        var ia = "OFFLINE_VIDEO_STATE_DISABLED";
                        ca.expirationTimestamp && Number(ca.expirationTimestamp) < Date.now() / 1E3 && (ia = "OFFLINE_VIDEO_STATE_EXPIRED")
                    } else if (ca.action ===
                        "OFFLINE_VIDEO_POLICY_ACTION_DOWNLOAD_FAILED") ia = "OFFLINE_VIDEO_STATE_OFFLINE_FAILED";
                    else {
                        switch (Y == null ? void 0 : Y.transferState) {
                            case "TRANSFER_STATE_TRANSFER_IN_QUEUE":
                                ia = "OFFLINE_VIDEO_STATE_PENDING";
                                break;
                            case "TRANSFER_STATE_TRANSFERRING":
                                ia = "OFFLINE_VIDEO_STATE_TRANSFERRING";
                                break;
                            case "TRANSFER_STATE_PAUSED_BY_USER":
                                ia = "OFFLINE_VIDEO_STATE_PAUSED_TRANSFER";
                                break;
                            case "TRANSFER_STATE_FAILED":
                                ia = "OFFLINE_VIDEO_STATE_OFFLINE_FAILED";
                                break;
                            case "TRANSFER_STATE_COMPLETE":
                                ia = "OFFLINE_VIDEO_STATE_PLAYABLE";
                                break;
                            case "TRANSFER_STATE_WAITING_FOR_PLAYER_RESPONSE_REFRESH":
                                ia = "OFFLINE_VIDEO_STATE_STREAMS_OUT_OF_DATE";
                                break;
                            default:
                                ia = "OFFLINE_VIDEO_STATE_UNKNOWN"
                        }
                        if (ia === "OFFLINE_VIDEO_STATE_OFFLINE_FAILED") switch (Y == null ? void 0 : Y.failureReason) {
                            case "TRANSFER_FAILURE_REASON_EXTERNAL_FILESYSTEM_WRITE":
                            case "TRANSFER_FAILURE_REASON_FILESYSTEM_WRITE":
                                ia = "OFFLINE_VIDEO_STATE_OUT_OF_STORAGE_ERROR";
                                break;
                            case "TRANSFER_FAILURE_REASON_STREAM_MISSING":
                                ia = "OFFLINE_VIDEO_STATE_STREAMS_MISSING";
                                break;
                            case "TRANSFER_FAILURE_REASON_NETWORK":
                            case "TRANSFER_FAILURE_REASON_NETWORK_LOST":
                                ia =
                                    "OFFLINE_VIDEO_STATE_NETWORK_ERROR"
                        }
                    }
                    qa = {
                        id: qa,
                        videoState: ia
                    };
                    if (Y == null ? 0 : Y.cotn) qa.cotn = Y.cotn;
                    if (Y == null ? 0 : Y.maximumDownloadQuality) qa.selectedVideoQuality = Y == null ? void 0 : Y.maximumDownloadQuality;
                    if (Y == null ? 0 : Y.lastProgressTimeMs) qa.lastProgressTimeMs = Y.lastProgressTimeMs;
                    la && (qa.playerResponseSavedTimeMs = String(Number(la) * 1E3));
                    Y = String;
                    la = 0;
                    ha = g.w(ha);
                    for (ia = ha.next(); !ia.done; ia = ha.next())
                        if (ia = ia.value, ia.streamsProgress) {
                            ia = g.w(ia.streamsProgress);
                            for (var Ka = ia.next(); !Ka.done; Ka = ia.next()) {
                                var ob =
                                    void 0;
                                la += Number((ob = Ka.value.numBytesDownloaded) != null ? ob : 0)
                            }
                        }
                    qa.downloadedBytes = Y(la);
                    qa.selectedOfflineMode = K[L] ? "OFFLINE_MODE_TYPE_AUTO_OFFLINE" : "OFFLINE_NOW";
                    ca.action === "OFFLINE_VIDEO_POLICY_ACTION_DISABLE" && (qa.offlinePlaybackDisabledReason = ca.offlinePlaybackDisabledReason);
                    return qa
                });
                return I.return({
                    offlineVideos: E,
                    additionalOfflineClientState: {
                        mainAppAdditionalOfflineClientState: {
                            smartDownloadVideos: H
                        }
                    }
                })
            })
        },
        jnb = function() {
            this.locks = navigator.locks
        },
        knb = function() {
            try {
                var a = g.Na("ytglobal.locks_");
                if (a) return a;
                var b;
                if (b = navigator) {
                    var c = navigator;
                    b = "locks" in c && !!c.locks
                }
                if (b) return g.La.localStorage && g.La.localStorage.getItem("noop"), a = new jnb, g.Ma("ytglobal.locks_", a), a
            } catch (d) {}
        },
        d6 = function() {},
        lnb = function() {},
        mnb = function(a) {
            if (a.includes(":")) throw Error("Invalid user cache name: " + a);
            return a + ":" + g.Vs("CacheStorage get")
        },
        nnb = function() {
            return g.J(function(a) {
                if (e6 !== void 0) return a.return(e6);
                e6 = new Promise(function(b) {
                    var c;
                    return g.J(function(d) {
                        switch (d.j) {
                            case 1:
                                return g.wa(d, 2), g.F(d, f6.open("test-only"), 4);
                            case 4:
                                return g.F(d, f6.delete("test-only"), 5);
                            case 5:
                                g.xa(d, 3);
                                break;
                            case 2:
                                if (c = g.ya(d), c instanceof Error && c.name === "SecurityError") return b(!1), d.return();
                            case 3:
                                b("caches" in window), g.va(d)
                        }
                    })
                });
                return a.return(e6)
            })
        },
        pnb = function() {
            return g.J(function(a) {
                if (a.j == 1) return g.F(a, nnb(), 2);
                if (!a.B) return a.return(void 0);
                onb || (onb = new lnb);
                return a.return(onb)
            })
        },
        g6 = function(a, b, c) {
            g.Iw(new g.Us("Woffle: " + a, c ? {
                cotn: c
            } : ""));
            b instanceof Error && g.Iw(b)
        },
        qnb = function(a) {
            var b;
            return g.J(function(c) {
                if (c.j == 1) return g.F(c, inb(a), 2);
                b = c.B;
                g.jt("offlineStateSnapshot", b);
                g.va(c)
            })
        },
        h6 = function(a) {
            g.O.call(this);
            var b = this;
            this.api = a;
            this.bd = {
                doa: function() {
                    return b.j
                },
                voa: function() {
                    return b.B
                }
            };
            typeof g.La.BroadcastChannel !== "undefined" && (this.j = new g.La.BroadcastChannel("PLAYER_OFFLINE_ERROR_SYNC:" + g.Vs()), this.j.onmessage = this.C.bind(this), this.B = new g.La.BroadcastChannel("PLAYER_OFFLINE_PAUSE_SYNC:" + g.Vs()), this.B.onmessage = this.D.bind(this))
        },
        i6 = function(a, b) {
            a.api.gb("onOfflineOperationFailure", b);
            var c;
            (c = a.j) == null || c.postMessage(b)
        },
        rnb = function(a, b, c, d) {
            var e = this;
            this.Z = a;
            this.Y = b;
            this.visibility = c;
            this.L = d;
            this.G = this.N = this.K = this.C = this.j = !1;
            this.D = new g.Zo(function() {
                e.HM()
            });
            this.bd = {
                UY: function() {
                    return e.B
                },
                HM: function() {
                    e.HM()
                },
                Coa: function() {
                    return e.D
                }
            };
            this.visibility.subscribe("visibilitystatechange", function() {
                e.Nf()
            })
        },
        snb = function(a) {
            if (!a.C && !a.j) {
                var b = knb();
                if (b) {
                    a.C = !0;
                    var c = g.Vs("OfflineLockManager");
                    b.request("woffle_orchestration_leader:" + c, {}, function() {
                        var d, e, f, h;
                        return g.J(function(l) {
                            switch (l.j) {
                                case 1:
                                    return g.wa(l, 2), a.B = new g.oj, a.j = !0, a.C = !1, g.F(l, a.Z(), 4);
                                case 4:
                                    return g.F(l, a.B.promise, 5);
                                case 5:
                                    g.xa(l, 0);
                                    break;
                                case 2:
                                    d = g.ya(l), ((f = (e = a).L) == null ? 0 : f.call(e, "wo_relinquish_leadership_on_lock_request_error")) || a.HM(), d instanceof Error && (h = d, h.args = [{
                                        name: "WoLockManagerError",
                                        iM: d.name
                                    }], g.Hw(h)), g.va(l)
                            }
                        })
                    })
                }
            }
        },
        tnb = function(a) {
            a.j && (a.G = !0, j6(a))
        },
        unb = function(a, b) {
            a.j && (a.K = b, j6(a))
        },
        vnb = function(a, b) {
            a.j && (a.N = b, j6(a))
        },
        j6 = function(a) {
            a.N && a.K && a.G && a.visibility.isBackground() ? g.$o(a.D, 6E4) : a.D.stop()
        },
        k6 = function(a) {
            var b;
            a.offlineDeleteReason = (b = a.offlineDeleteReason) != null ? b : "OFFLINE_DELETE_REASON_UNKNOWN";
            var c;
            a.offlineModeType = (c = a.offlineModeType) != null ? c : "OFFLINE_NOW";
            g.jt("offlineDeleteEvent", a)
        },
        l6 = function(a, b) {
            var c = b.videoId;
            var d = b.lm;
            b = b.offlineModeType;
            a.encryptedVideoId = c;
            a.cotn = d == null ? void 0 : d.cotn;
            a.offlineabilityFormatType = d == null ? void 0 : d.maximumDownloadQuality;
            var e;
            a.isRefresh = (e = d == null ? void 0 : d.isRefresh) != null ? e : !1;
            var f;
            a.softErrorCount = (f = d == null ? void 0 : d.transferRetryCount) != null ? f : 0;
            a.offlineModeType = b != null ? b : "OFFLINE_NOW";
            (a.transferStatusType === "TRANSFER_STATUS_TYPE_UNKNOWN" && a.statusType === "UNKNOWN_STATUS_TYPE" || !a.transferStatusType && !a.statusType) && g.Iw(Error("Woffle unknown transfer status"));
            g.jt("offlineTransferStatusChanged", a)
        },
        wnb = function(a, b, c, d) {
            d = {
                transferStatusType: "TRANSFER_STATUS_TYPE_PROCESSING",
                statusType: "OFFLINING_STARTED",
                transferFirstStarted: !!d
            };
            b && c && (b = Math.floor(b / 1024).toFixed(), c = Math.floor(c / 1024).toFixed(), d.alreadyDownloadedKbytes = b, d.totalFetchedKbytes = b, d.totalContentKbytes = c);
            l6(d, a)
        },
        xnb = function(a) {
            l6({
                transferStatusType: "TRANSFER_STATUS_TYPE_DEQUEUED_BY_USER_PAUSE",
                statusType: "SUSPENDED"
            }, a)
        },
        ynb = function(a) {
            switch (a) {
                case "TRANSFER_FAILURE_REASON_FILESYSTEM_WRITE":
                case "TRANSFER_FAILURE_REASON_EXTERNAL_FILESYSTEM_WRITE":
                    return "OFFLINE_DATABASE_ERROR";
                case "TRANSFER_FAILURE_REASON_PLAYABILITY":
                    return "NOT_PLAYABLE";
                case "TRANSFER_FAILURE_REASON_TOO_MANY_RETRIES":
                    return "TOO_MANY_RETRIES";
                case "TRANSFER_FAILURE_REASON_INTERNAL":
                    return "OFFLINE_DOWNLOAD_CONTROLLER_ERROR";
                case "TRANSFER_FAILURE_REASON_STREAM_MISSING":
                    return "STREAM_VERIFICATION_FAILED";
                case "TRANSFER_FAILURE_REASON_SERVER":
                case "TRANSFER_FAILURE_REASON_SERVER_PROPERTY_MISSING":
                    return "OFFLINE_REQUEST_FAILURE";
                case "TRANSFER_FAILURE_REASON_NETWORK":
                    return "OFFLINE_NETWORK_ERROR";
                default:
                    return "UNKNOWN_FAILURE_REASON"
            }
        },
        m6 = function(a) {
            var b, c, d;
            return ((d = (b = a.actionMetadata) == null ? void 0 : (c = b.retryScheduleIntervalsInSeconds) == null ? void 0 : c.length) != null ? d : 0) > 0
        },
        n6 = function(a) {
            return a.actionType === "OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD" && !!a.entityKey
        },
        o6 = function(a) {
            return a.actionType === "OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH" && !!a.entityKey
        },
        p6 = function(a) {
            return a.actionType === "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE" && !!a.entityKey
        },
        znb = function(a) {
            return a.actionType === "OFFLINE_ORCHESTRATION_ACTION_TYPE_UPDATE" && !!a.entityKey
        },
        q6 = function(a, b, c, d, e) {
            e = e === void 0 ? !1 : e;
            var f, h, l, m, n, p;
            return g.J(function(q) {
                if (q.j == 1) return f = g.GK(a, b), h = g.GK(a, "downloadStatusEntity"), g.F(q, Z5(c, {
                    mode: "readonly",
                    Pb: !0
                }, function(r) {
                    return g.zt.all([S5(r, f, b), S5(r, h, "downloadStatusEntity")])
                }), 2);
                l = q.B;
                m = l.length ? l[0] : void 0;
                if (!m) return q.Fa(0);
                n = Anb;
                if (p = l.length > 1 ? l[1] : void 0) {
                    if (p.downloadState === "DOWNLOAD_STATE_USER_DELETED" && !e) return q.return();
                    p.downloadState = d
                } else p = {
                    key: h,
                    downloadState: d
                };
                g.Nw(m, n, p);
                return g.F(q, Z5(c, {
                    mode: "readwrite",
                    Pb: !0
                }, function(r) {
                    return g.zt.all([V5(r, m, b), V5(r, p, "downloadStatusEntity")])
                }), 0)
            })
        },
        r6 = function(a, b) {
            return a.actionType === b.actionType && a.entityKey === b.entityKey
        },
        s6 = function(a, b) {
            if (a && a.transferState !== "TRANSFER_STATE_COMPLETE" && a.transferState !==
                "TRANSFER_STATE_FAILED") {
                var c = g.FK(a.key).entityId;
                l6({
                    transferStatusType: "TRANSFER_STATUS_TYPE_TERMINATED_BY_USER",
                    statusType: "CANCELLED"
                }, {
                    videoId: c,
                    lm: a,
                    offlineModeType: b
                })
            }
        },
        t6 = function(a) {
            if (!a || !a.thumbnails) return [];
            var b = [];
            a = g.w(a.thumbnails);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, c.url && b.push(c.url);
            return b
        },
        Bnb = function(a, b, c) {
            c = c === void 0 ? [] : c;
            var d, e, f, h, l, m, n, p, q, r, t, u, y;
            return g.J(function(B) {
                if (B.j == 1) return c.length ? g.F(B, b6(a, b), 2) : B.return([]);
                d = B.B;
                e = new Set;
                f = g.w(d);
                for (h = f.next(); !h.done; h = f.next())
                    if (l = h.value, m = l.id || l.key) n = g.FK(m).entityId, e.add(n);
                p = [];
                q = g.w(c);
                for (r = q.next(); !r.done; r = q.next()) t = r.value, u = t.offlineVideoData, y = void 0, ((y = u) == null ? 0 : y.videoId) && !e.has(u.videoId) && p.push(t);
                return B.return(p)
            })
        },
        Cnb = function(a, b, c) {
            return new g.kQ(a, {
                cotn: b,
                raw_player_response: c,
                download_media: !0,
                start: Infinity,
                disable_watch_next: !0
            })
        },
        Dnb = function() {
            return {
                priority: 1,
                retryScheduleIntervalsInSeconds: [1, 2, 4]
            }
        },
        u6 = function(a, b, c, d, e, f, h, l, m, n, p) {
            this.entityType = a;
            this.actionId = b;
            this.action = c;
            this.parentActionId = d;
            this.rootActionId = e === void 0 ? b : e;
            this.childActionIds = f;
            this.prereqActionId = h;
            this.postreqActionIds = l;
            this.hasChildActionFailed = n;
            this.retryScheduleIndex = 0;
            this.j = p || Date.now();
            this.retryScheduleIndex = m || 0
        },
        v6 = function(a) {
            if (!a.key) throw Error("Entity key is required.");
            if (!a.actionProto) throw Error("OfflineOrchestrationAction is required.");
            var b = g.FK(a.key),
                c = g.FK(a.actionProto.entityKey);
            return new u6(c.entityType, b.entityId, a.actionProto, a.parentActionId, a.rootActionId, a.childActionIds, a.prereqActionId, a.postreqActionIds, a.retryScheduleIndex, a.hasChildActionFailed, Number(a.enqueueTimeSec) * 1E3)
        },
        w6 = function(a) {
            return {
                key: g.GK(a.actionId, "offlineOrchestrationActionWrapperEntity"),
                actionProto: a.action,
                parentActionId: a.parentActionId,
                rootActionId: a.rootActionId,
                childActionIds: a.childActionIds,
                prereqActionId: a.prereqActionId,
                postreqActionIds: a.postreqActionIds,
                retryScheduleIndex: a.retryScheduleIndex,
                hasChildActionFailed: a.hasChildActionFailed,
                enqueueTimeSec: (a.j / 1E3).toFixed()
            }
        },
        Enb = function() {
            var a;
            return g.J(function(b) {
                return b.j == 1 ? g.F(b, pnb(), 2) : (a = b.B) ? b.return(a.delete("yt-player-local-img")) : b.return(!0)
            })
        },
        x6 = function(a) {
            var b, c;
            return g.J(function(d) {
                if (d.j == 1) return g.F(d, pnb(), 2);
                if (d.j != 3) {
                    b = d.B;
                    if (!b) throw Error("Cache API not supported");
                    return a.length ? g.F(d, b.open("yt-player-local-img"), 3) : d.return()
                }
                c = d.B;
                return g.F(d, Promise.all(a.map(function(e) {
                    return c.delete(e)
                })), 0)
            })
        },
        y6 = function(a) {
            var b, c;
            return g.J(function(d) {
                if (d.j == 1) return g.F(d, pnb(), 2);
                if (d.j != 3) {
                    b = d.B;
                    if (!b) throw Error("Cache API not supported");
                    return a.length ? g.F(d, b.open("yt-player-local-img"), 3) : d.return()
                }
                c = d.B;
                return g.F(d, c.addAll(a), 0)
            })
        },
        z6 = function(a, b, c, d, e) {
            var f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb;
            return g.J(function(rb) {
                switch (rb.j) {
                    case 1:
                        return f = g.GK(a, "mainVideoEntity"), h = g.GK(a, "ytMainChannelEntity"), l = g.GK(a, "transfer"), m = g.GK(a, "videoDownloadContextEntity"), g.F(rb, Z5(b, {
                            mode: "readonly",
                            Pb: !0
                        }, function(Za) {
                            return g.zt.all([S5(Za, f, "mainVideoEntity"), S5(Za, h, "ytMainChannelEntity"), S5(Za, l, "transfer"), S5(Za, m, "videoDownloadContextEntity"), T5(Za, "ytMainChannelEntity"), T5(Za, "offlineOrchestrationActionWrapperEntity")])
                        }), 2);
                    case 2:
                        n = rb.B;
                        p = g.w(n);
                        q = p.next().value;
                        r = p.next().value;
                        t = p.next().value;
                        u = p.next().value;
                        y = p.next().value;
                        B = p.next().value;
                        C = q;
                        G = r;
                        H = t;
                        N = u;
                        M = y;
                        X = B;
                        if (!C && !G) {
                            rb.Fa(3);
                            break
                        }
                        W = C ? t6(C.thumbnail) : [];
                        if (!G) {
                            fa = [];
                            rb.Fa(4);
                            break
                        }
                        return g.F(rb, Fnb(G, M), 5);
                    case 5:
                        fa = rb.B;
                    case 4:
                        return pa = fa, g.F(rb, x6(W.concat(pa)), 3);
                    case 3:
                        ba = [];
                        R = g.GK(a, "downloadStatusEntity");
                        V = g.w(X);
                        for (v = V.next(); !v.done; v = V.next()) U = v.value, bb = g.FK(U.key).entityId, yb = v6(U), lb = g.FK(yb.action.entityKey).entityId, bb !== a && lb !== a || r6(c,
                            U.actionProto) || ba.push(U.key);
                        return g.F(rb, Z5(b, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(Za) {
                            var A = ba.map(function(D) {
                                return W5(Za, D)
                            });
                            A.push(W5(Za, f, {
                                Yw: !0
                            }));
                            A.push(W5(Za, R, {
                                Yw: !0
                            }));
                            return g.zt.all(A)
                        }), 7);
                    case 7:
                        cb = (Ea = N) == null ? void 0 : Ea.offlineModeType, e && (k6(e), e.offlineModeType && (cb = e.offlineModeType)), s6(H, cb), i6(d, {
                            entityKey: f,
                            failureReason: "OFFLINE_OPERATION_FAILURE_REASON_VIDEO_DELETED"
                        }), g.va(rb)
                }
            })
        },
        Inb = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb, rb, Za, A, D, E, I, L, Y, ha, ca, K, la, qa, ia, Ka, ob, Mb, qc;
            return g.J(function(Ta) {
                switch (Ta.j) {
                    case 1:
                        return e = g.GK(a, "mainPlaylistEntity"), f = g.GK(a, "ytMainChannelEntity"), g.F(Ta, Z5(b, {
                            mode: "readonly",
                            Pb: !0
                        }, function(Oc) {
                            return g.zt.all([S5(Oc, e, "mainPlaylistEntity"), S5(Oc, f, "ytMainChannelEntity"), T5(Oc, "mainPlaylistEntity"), T5(Oc, "mainDownloadsListEntity"), T5(Oc, "ytMainChannelEntity"), T5(Oc, "offlineOrchestrationActionWrapperEntity")])
                        }), 2);
                    case 2:
                        h = Ta.B;
                        l = g.w(h);
                        m = l.next().value;
                        n = l.next().value;
                        p = l.next().value;
                        q = l.next().value;
                        r = l.next().value;
                        t = l.next().value;
                        u = m;
                        y = n;
                        B = p;
                        C = q;
                        G = r;
                        H = t;
                        if (!u && !y) {
                            Ta.Fa(3);
                            break
                        }
                        N = u ? Gnb(u) : [];
                        if (!y) {
                            M = [];
                            Ta.Fa(4);
                            break
                        }
                        return g.F(Ta, Fnb(y, G), 5);
                    case 5:
                        M = Ta.B;
                    case 4:
                        return X = M, g.F(Ta, x6(N.concat(X)), 3);
                    case 3:
                        W = [];
                        fa = new Map;
                        if (!u) {
                            Ta.Fa(7);
                            break
                        }
                        return g.F(Ta, Hnb(u, B, C), 8);
                    case 8:
                        W = Ta.B;
                        pa = g.w(W);
                        for (ba = pa.next(); !ba.done; ba = pa.next()) R = ba.value, fa.set(R, {
                            videoId: R,
                            playlistId: a,
                            offlineDeleteReason: "OFFLINE_DELETE_REASON_PARENT_LIST_DELETE"
                        });
                        return g.F(Ta, Z5(b, {
                            mode: "readonly",
                            Pb: !0
                        }, function(Oc) {
                            return g.zt.all([T5(Oc, "transfer"), T5(Oc, "videoDownloadContextEntity")])
                        }), 9);
                    case 9:
                        V = Ta.B;
                        v = g.w(V);
                        U = v.next().value;
                        bb = v.next().value;
                        yb = U;
                        lb = bb;
                        Ea = g.w(yb);
                        for (cb = Ea.next(); !cb.done; cb = Ea.next()) rb = cb.value, Za = g.FK(rb.key).entityId, (A = fa.get(Za)) && rb && (A.cotn = rb.cotn);
                        D = g.w(lb);
                        for (E = D.next(); !E.done; E = D.next()) I = E.value, L = g.FK(I.key).entityId, (Y = fa.get(L)) && I && (Y.offlineModeType = I.offlineModeType);
                    case 7:
                        ha = [];
                        ca = g.w(H);
                        for (K = ca.next(); !K.done; K = ca.next()) la = K.value, qa = g.FK(la.key).entityId, ia = v6(la), qa !== a && ia.rootActionId !== a || r6(c, la.actionProto) || ha.push(la.key);
                        Ka =
                            g.GK(a, "mainPlaylistEntity");
                        return g.F(Ta, Z5(b, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(Oc) {
                            var he = ha.map(function(Me) {
                                return W5(Oc, Me)
                            });
                            he.push(W5(Oc, Ka, {
                                Yw: !0
                            }));
                            return g.zt.all(he)
                        }), 10);
                    case 10:
                        if (!u) {
                            Ta.Fa(0);
                            break
                        }
                        W.reverse();
                        if (!W) {
                            Ta.Fa(0);
                            break
                        }
                        ob = g.w(W);
                        Mb = ob.next();
                    case 13:
                        if (Mb.done) {
                            Ta.Fa(0);
                            break
                        }
                        qc = Mb.value;
                        return g.F(Ta, z6(qc, b, c, d, fa.get(qc)), 14);
                    case 14:
                        Mb = ob.next(), Ta.Fa(13)
                }
            })
        },
        Knb = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q, r;
            return g.J(function(t) {
                if (t.j == 1) return e = g.GK("DOWNLOADS_LIST_ENTITY_ID_MANUAL_DOWNLOADS", "mainDownloadsListEntity"), f = new Map, g.F(t, Z5(a, {
                    mode: "readwrite",
                    Pb: !0
                }, function(u) {
                    var y = T5(u, "transfer"),
                        B = T5(u, "offlineOrchestrationActionWrapperEntity"),
                        C = T5(u, "videoDownloadContextEntity"),
                        G = S5(u, e, "mainDownloadsListEntity");
                    return g.zt.all([y, B, C, G]).then(function(H) {
                        H = g.w(H);
                        var N = H.next().value;
                        var M = H.next().value;
                        var X = H.next().value;
                        var W = H.next().value;
                        H = Jnb.map(function(pa) {
                            return Fmb(u, pa)
                        });
                        M = g.w(M);
                        for (var fa = M.next(); !fa.done; fa = M.next()) fa = fa.value, r6(b, fa.actionProto) || H.push(W5(u, fa.key, {
                            Yw: !0
                        }));
                        W && (W.downloads = [], H.push(V5(u, W, "mainDownloadsListEntity")));
                        if (X)
                            for (X = g.w(X), W = X.next(); !W.done; W = X.next()) W = W.value, M = g.FK(W.key).entityId, M = g.GK(M, "transfer"), f.set(M, W.offlineModeType);
                        return g.zt.all(H).then(function() {
                            return N
                        })
                    })
                }), 2);
                h = t.B;
                l = g.w(h);
                for (m = l.next(); !m.done; m = l.next()) n = m.value, s6(n, f.get(n.key)), p = g.FK(n.key).entityId, q = {
                    videoId: p,
                    offlineDeleteReason: d,
                    cotn: n.cotn,
                    offlineModeType: f.get(n.key)
                }, k6(q), r = g.GK(p, "mainVideoEntity"), i6(c, {
                    entityKey: r,
                    failureReason: "OFFLINE_OPERATION_FAILURE_REASON_VIDEO_DELETED"
                });
                return g.F(t, Enb(), 0)
            })
        },
        Gnb = function(a, b) {
            var c = [];
            if (a.thumbnailStyleData) {
                a = g.w(a.thumbnailStyleData);
                for (var d = a.next(); !d.done; d = a.next()) {
                    var e = void 0,
                        f = void 0,
                        h = void 0;
                    c = c.concat(t6((e = d.value) == null ? void 0 : (f = e.value) == null ? void 0 : (h = f.collageThumbnail) == null ? void 0 : h.coverThumbnail))
                }
            }
            b = t6(b);
            return c.concat(b)
        },
        Hnb = function(a, b, c) {
            var d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa;
            return g.J(function(ba) {
                d = [];
                e = new Set;
                if (c.length)
                    for (f = g.w(c), h = f.next(); !h.done; h = f.next())
                        if (l = h.value, m = void 0, (m = l.downloads) == null ? 0 : m.length)
                            for (n = g.w(l.downloads), p = n.next(); !p.done; p = n.next()) q = p.value, q.videoItem && (r = g.FK(q.videoItem).entityId, e.add(r));
                if (a.videos) {
                    t = g.w(a.videos);
                    for (u = t.next(); !u.done; u = t.next()) y = u.value, B = JSON.parse(g.FK(y).entityId), B.videoId && !e.has(B.videoId) && d.push(B.videoId);
                    C = g.w(b);
                    for (G = C.next(); !G.done; G = C.next())
                        if (H = G.value, H.key !== a.key && (N = H.videos))
                            for (M =
                                g.w(N), X = M.next(); !X.done; X = M.next()) W = X.value, fa = JSON.parse(g.FK(W).entityId), fa.videoId && (pa = d.indexOf(fa.videoId), pa !== -1 && d.splice(pa, 1))
                }
                return ba.return(d)
            })
        },
        Fnb = function(a, b) {
            var c, d, e, f, h, l, m, n;
            return g.J(function(p) {
                c = t6(a.avatar);
                d = g.w(b);
                for (e = d.next(); !e.done; e = d.next())
                    if (f = e.value, f.id !== a.id)
                        for (h = g.w(t6(f.avatar)), l = h.next(); !l.done; l = h.next()) m = l.value, n = c.indexOf(m), n !== -1 && c.splice(n, 1);
                return p.return(c)
            })
        },
        Lnb = function(a) {
            var b;
            return g.J(function(c) {
                b = g.Q(a.frameworkUpdates, A6);
                return a.frameworkUpdates && b ? g.F(c, Tmb(b), 0) : c.return()
            })
        },
        Onb = function(a) {
            var b;
            if ((b = a.onResponseReceivedActions) != null && b.length) {
                var c;
                a = (c = g.Q(g.Q(a.onResponseReceivedActions[0], Mnb), Nnb)) == null ? void 0 : c.actions;
                if (a != null && a.length) return a
            }
        },
        Pnb = function(a) {
            var b, c, d;
            return g.J(function(e) {
                if (e.j == 1) return a ? g.F(e, a6(a, B6, "mainDownloadsListEntity"), 2) : e.return([]);
                b = e.B;
                return ((c = b) == null ? 0 : (d = c.downloads) == null ? 0 : d.length) ? e.return(b.downloads.map(function(f) {
                    var h;
                    return (h = f.videoItem) != null ? h : ""
                })) : e.return([])
            })
        },
        Rnb = function(a, b) {
            var c;
            return g.J(function(d) {
                return d.j == 1 ? g.F(d, Qnb(a, b), 2) : (c = d.B) ? g.F(d, Z5(a, {
                    mode: "readwrite",
                    Pb: !0
                }, function(e) {
                    var f = [V5(e, c.mainDownloadsLibraryEntity, "mainDownloadsLibraryEntity")];
                    c.mainDownloadsListEntity && f.push(V5(e, c.mainDownloadsListEntity, "mainDownloadsListEntity"));
                    return g.zt.all(f)
                }), 0) : d.Fa(0)
            })
        },
        Qnb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H;
            return g.J(function(N) {
                if (N.j == 1) return c = g.GK("main_downloads_library_id", "mainDownloadsLibraryEntity"), d = g.GK("DOWNLOADS_LIST_ENTITY_ID_MANUAL_DOWNLOADS", "mainDownloadsListEntity"), g.F(N, Z5(a, {
                    mode: "readonly",
                    Pb: !0
                }, function(M) {
                    return g.zt.all([S5(M, c, "mainDownloadsLibraryEntity"), S5(M, d, "mainDownloadsListEntity")])
                }), 2);
                e = N.B;
                f = g.w(e);
                h = f.next().value;
                l = f.next().value;
                m = h;
                n = l;
                m || (m = {
                    id: c
                });
                p = g.w(b);
                for (q = p.next(); !q.done; q = p.next())
                    if (r = q.value, r === B6) {
                        if (m.smartDownloadsList) return N.return();
                        m.smartDownloadsList = r
                    } else if (t = g.FK(r).entityType, u = {}, t === "mainPlaylistEntity" ? u.playlistItem = r : t === "mainVideoEntity" && (u.videoItem = r), !g.zg(u)) {
                    y = void 0;
                    if ((y = n) == null ? 0 : y.downloads) {
                        B = !1;
                        C = g.w(n.downloads);
                        for (G = C.next(); !G.done; G = C.next())
                            if (H = G.value, H.playlistItem === r || H.videoItem === r) {
                                B = !0;
                                break
                            }
                        B || n.downloads.push(u)
                    } else n = {
                        id: d,
                        downloads: [u]
                    };
                    m.downloadsList = d
                }
                return N.return({
                    mainDownloadsLibraryEntity: m,
                    mainDownloadsListEntity: n
                })
            })
        },
        Snb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B;
            return g.J(function(C) {
                if (C.j == 1) return c = g.GK("main_downloads_library_id", "mainDownloadsLibraryEntity"), d = g.GK("DOWNLOADS_LIST_ENTITY_ID_MANUAL_DOWNLOADS", "mainDownloadsListEntity"), g.F(C, Z5(a, {
                    mode: "readonly",
                    Pb: !0
                }, function(G) {
                    return g.zt.all([S5(G, c, "mainDownloadsLibraryEntity"), S5(G, d, "mainDownloadsListEntity"), S5(G, B6, "mainDownloadsListEntity")])
                }), 2);
                e = C.B;
                f = g.w(e);
                h = f.next().value;
                l = f.next().value;
                m = f.next().value;
                n = h;
                p = l;
                q = m;
                if (!n) return C.Fa(0);
                if (b === B6 && ((r = q) == null ? 0 : r.downloads)) q.downloads = [];
                else if ((t = p) == null ? 0 : t.downloads)
                    for (u = g.FK(b).entityType, y = 0; y < p.downloads.length; y++)
                        if (B = p.downloads[y], u === "mainVideoEntity" && B.videoItem === b) {
                            p.downloads.splice(y, 1);
                            break
                        } else if (u === "mainPlaylistEntity" && B.playlistItem === b) {
                    p.downloads.splice(y, 1);
                    break
                }
                return g.F(C, Z5(a, {
                    mode: "readwrite",
                    Pb: !0
                }, function(G) {
                    var H = [V5(G, n, "mainDownloadsLibraryEntity")];
                    p && H.push(V5(G, p, "mainDownloadsListEntity"));
                    q && H.push(V5(G, q, "mainDownloadsListEntity"));
                    return g.zt.all(H)
                }), 0)
            })
        },
        C6 = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r;
            return g.J(function(t) {
                if (t.j == 1) return c = g.GK(b, "transfer"), d = g.GK(b, "videoDownloadContextEntity"), g.F(t, Z5(a, {
                    mode: "readonly",
                    Pb: !0
                }, function(u) {
                    return g.zt.all([S5(u, c, "transfer"), S5(u, d, "videoDownloadContextEntity")])
                }), 2);
                e = t.B;
                f = g.w(e);
                h = f.next().value;
                l = f.next().value;
                m = h;
                n = l;
                r = {
                    videoId: b,
                    cotn: (p = m) == null ? void 0 : p.cotn,
                    offlineModeType: (q = n) == null ? void 0 : q.offlineModeType
                };
                return t.return(r)
            })
        },
        D6 = function(a, b, c, d, e) {
            var f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa;
            return g.J(function(pa) {
                switch (pa.j) {
                    case 1:
                        return f = g.GK(a, "musicTrack"), h = g.GK(a, "transfer"), g.F(pa, Z5(b, {
                            mode: "readonly",
                            Pb: !0
                        }, function(ba) {
                            return g.zt.all([S5(ba, f, "musicTrack"), S5(ba, h, "transfer"), T5(ba, "musicTrack"), T5(ba, "offlineOrchestrationActionWrapperEntity")])
                        }), 2);
                    case 2:
                        l = pa.B;
                        m = g.w(l);
                        n = m.next().value;
                        p = m.next().value;
                        q = m.next().value;
                        r = m.next().value;
                        t = n;
                        u = p;
                        y = q;
                        B = r;
                        if (!t) {
                            pa.Fa(3);
                            break
                        }
                        return g.F(pa, Tnb(t, y), 4);
                    case 4:
                        return C = pa.B, g.F(pa, x6(C), 3);
                    case 3:
                        G = [];
                        H = g.w(B);
                        for (N = H.next(); !N.done; N = H.next()) M = N.value, X = g.FK(M.key).entityId, W = v6(M), fa = g.FK(W.action.entityKey).entityId, X !== a && fa !== a || r6(c, M.actionProto) || G.push(M.key);
                        return g.F(pa, Z5(b, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(ba) {
                            var R = G.map(function(V) {
                                return W5(ba, V)
                            });
                            R.push(W5(ba, f, {
                                Yw: !0
                            }));
                            return g.zt.all(R)
                        }), 6);
                    case 6:
                        s6(u), e && k6(e), i6(d, {
                            entityKey: f,
                            failureReason: "OFFLINE_OPERATION_FAILURE_REASON_VIDEO_DELETED"
                        }), g.va(pa)
                }
            })
        },
        E6 = function(a, b, c, d, e) {
            var f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb, rb, Za, A, D, E;
            return g.J(function(I) {
                switch (I.j) {
                    case 1:
                        return f = g.GK(a, b), h = g.GK("music_downloads_library_id", "musicDownloadsLibraryEntity"), g.F(I, Z5(c, {
                            mode: "readonly",
                            Pb: !0
                        }, function(L) {
                            return g.zt.all([S5(L, f, b), S5(L, h, "musicDownloadsLibraryEntity"), T5(L, b), T5(L, "offlineOrchestrationActionWrapperEntity")])
                        }), 2);
                    case 2:
                        l = I.B;
                        m = g.w(l);
                        n = m.next().value;
                        p = m.next().value;
                        q = m.next().value;
                        r = m.next().value;
                        t = n;
                        u = p;
                        y = q;
                        B = r;
                        if (!t) {
                            I.Fa(3);
                            break
                        }
                        return g.F(I, Tnb(t, y), 4);
                    case 4:
                        return C = I.B, g.F(I, x6(C), 3);
                    case 3:
                        G = [];
                        H = new Map;
                        if (!t) {
                            I.Fa(6);
                            break
                        }
                        return g.F(I, Unb(t, y, u), 7);
                    case 7:
                        G = I.B;
                        N = g.w(G);
                        for (M = N.next(); !M.done; M = N.next()) X = M.value, W = g.FK(X).entityId, H.set(W, {
                            videoId: W,
                            playlistId: a,
                            offlineDeleteReason: "OFFLINE_DELETE_REASON_PARENT_LIST_DELETE"
                        });
                        return g.F(I, b6(c, "transfer"), 8);
                    case 8:
                        for (fa = I.B, pa = g.w(fa),
                            ba = pa.next(); !ba.done; ba = pa.next()) R = ba.value, V = g.FK(R.key).entityId, (v = H.get(V)) && R && (v.cotn = R.cotn);
                    case 6:
                        U = [];
                        bb = g.w(B);
                        for (yb = bb.next(); !yb.done; yb = bb.next()) lb = yb.value, Ea = g.FK(lb.key).entityId, cb = v6(lb), Ea !== a && cb.rootActionId !== a || r6(d, lb.actionProto) || U.push(lb.key);
                        rb = g.GK(a, b);
                        return g.F(I, Z5(c, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(L) {
                            var Y = U.map(function(ha) {
                                return W5(L, ha)
                            });
                            Y.push(W5(L, rb, {
                                Yw: !0
                            }));
                            return g.zt.all(Y)
                        }), 9);
                    case 9:
                        if (!t) {
                            I.Fa(0);
                            break
                        }
                        G.reverse();
                        if (!G.length) {
                            I.Fa(0);
                            break
                        }
                        Za = g.w(G);
                        A = Za.next();
                    case 12:
                        if (A.done) {
                            I.Fa(0);
                            break
                        }
                        D = A.value;
                        E = g.FK(D).entityId;
                        if (!E) {
                            I.Fa(13);
                            break
                        }
                        return g.F(I, D6(E, c, d, e, H.get(E)), 13);
                    case 13:
                        A = Za.next(), I.Fa(12)
                }
            })
        },
        F6 = function(a, b, c) {
            var d, e, f, h, l, m, n;
            return g.J(function(p) {
                if (p.j == 1) return g.F(p, Z5(a, {
                    mode: "readwrite",
                    Pb: !0
                }, function(q) {
                    var r = T5(q, "transfer"),
                        t = T5(q, "offlineOrchestrationActionWrapperEntity");
                    return g.zt.all([r, t]).then(function(u) {
                        u = g.w(u);
                        var y = u.next().value;
                        var B = u.next().value;
                        u = Vnb.map(function(N) {
                            return Fmb(q, N)
                        });
                        B = g.w(B);
                        for (var C = B.next(); !C.done; C = B.next()) {
                            C = C.value;
                            var G = g.FK(C.actionProto.entityKey).entityType === "musicTrack",
                                H = C.actionProto.actionType === "OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD";
                            r6(b, C.actionProto) || G && (!G || H) || u.push(W5(q, C.key, {
                                Yw: !0
                            }))
                        }
                        return g.zt.all(u).then(function() {
                            return y
                        })
                    })
                }), 2);
                d = p.B;
                e = g.w(d);
                for (f = e.next(); !f.done; f = e.next()) h = f.value, s6(h), l = g.FK(h.key).entityId, m = {
                    videoId: l,
                    offlineDeleteReason: void 0,
                    cotn: h.cotn
                }, k6(m), n = g.GK(l, "musicTrack"), i6(c, {
                    entityKey: n,
                    failureReason: "OFFLINE_OPERATION_FAILURE_REASON_VIDEO_DELETED"
                });
                return g.F(p, Enb(), 0)
            })
        },
        Wnb = function(a) {
            for (var b, c = g.w(a.additionalMetadatas), d = c.next(); !d.done; d = c.next()) d = d.value, d.offlineMusicVideoData && (b = d.offlineMusicVideoData);
            var e, f, h, l, m;
            return {
                id: g.GK(a.videoId, "musicTrack"),
                videoId: a.videoId,
                title: a.title,
                thumbnailDetails: a.thumbnail,
                lengthMs: String(Number(a.lengthSeconds) * 1E3),
                albumTitle: (e = b) == null ? void 0 : e.releaseTitle,
                musicVideoType: (f = b) == null ? void 0 : f.musicVideoType,
                contentRating: {
                    explicitType: (h = b) == null ? void 0 : h.explicitType
                },
                artistNames: ((l = b) == null ? void 0 : l.byline) || ((m = b) == null ? void 0 : m.channelName),
                downloadMetadata: g.GK(a.videoId, "musicTrackDownloadMetadataEntity")
            }
        },
        Unb = function(a, b, c) {
            var d, e, f, h, l, m,
                n, p, q, r, t, u, y, B, C, G, H, N;
            return g.J(function(M) {
                d = [];
                e = new Set;
                if ((f = c) == null ? 0 : (h = f.downloadedTracks) == null ? 0 : h.length)
                    for (l = g.w(c.downloadedTracks), m = l.next(); !m.done; m = l.next()) n = m.value, e.add(n);
                if (a.tracks) {
                    p = g.w(a.tracks);
                    for (q = p.next(); !q.done; q = p.next()) r = q.value, e.has(r) || d.push(r);
                    t = g.w(b);
                    for (u = t.next(); !u.done; u = t.next())
                        if (y = u.value, y.id !== a.id && (B = y.tracks))
                            for (C = g.w(B), G = C.next(); !G.done; G = C.next()) H = G.value, N = d.indexOf(H), N !== -1 && d.splice(N, 1)
                }
                return M.return(d)
            })
        },
        Tnb = function(a, b) {
            var c, d, e, f, h, l, m, n;
            return g.J(function(p) {
                c = t6(a.thumbnailDetails);
                d = g.w(b);
                for (e = d.next(); !e.done; e = d.next())
                    if (f = e.value, f.id !== a.id)
                        for (h = g.w(t6(f.thumbnailDetails)), l = h.next(); !l.done; l = h.next()) m = l.value, n = c.indexOf(m), n !== -1 && c.splice(n, 1);
                return p.return(c)
            })
        },
        Xnb = function(a, b) {
            var c, d, e, f, h, l, m, n, p;
            return g.J(function(q) {
                if (q.j == 1) return c = g.GK("music_downloads_library_id", "musicDownloadsLibraryEntity"), g.F(q, a6(a, c, "musicDownloadsLibraryEntity"), 2);
                (d = q.B) || (d = {
                    id: c
                });
                e = g.FK(b).entityType;
                e === "musicTrack" ? (f = d.downloadedTracks) != null && f.includes(b) || (d.downloadedTracks = ((h = d.downloadedTracks) != null ? h : []).concat(b)) : e === "musicPlaylist" ? (l = d.downloadedPlaylists) != null && l.includes(b) || (d.downloadedPlaylists = ((m = d.downloadedPlaylists) != null ? m : []).concat(b)) : e !== "musicAlbumRelease" || (n = d.downloadedAlbumReleases) !=
                    null && n.includes(b) || (d.downloadedAlbumReleases = ((p = d.downloadedAlbumReleases) != null ? p : []).concat(b));
                return g.F(q, $5(a, d, "musicDownloadsLibraryEntity"), 0)
            })
        },
        Ynb = function(a, b) {
            var c, d, e, f, h, l, m;
            return g.J(function(n) {
                if (n.j == 1) return c = g.GK("music_downloads_library_id", "musicDownloadsLibraryEntity"), g.F(n, a6(a, c, "musicDownloadsLibraryEntity"), 2);
                d = n.B;
                if (!d) return n.Fa(0);
                e = g.FK(b).entityType;
                e === "musicTrack" ? f = d.downloadedTracks : e === "musicPlaylist" && (f = d.downloadedPlaylists);
                if ((h = f) == null ? 0 : h.length)
                    for (l = 0; l < f.length; l++)
                        if (m = f[l], m === b) {
                            f.splice(l, 1);
                            break
                        }
                return g.F(n, $5(a, d, "musicDownloadsLibraryEntity"), 0)
            })
        },
        Znb = function(a) {
            var b = a.videos;
            a = [];
            var c = [];
            if (b) {
                b = g.w(b);
                for (var d = b.next(); !d.done; d = b.next()) {
                    var e = d.value.offlineVideoData.videoId;
                    d = g.GK(e, "musicTrack");
                    e = g.GK(e, "musicTrackDownloadMetadataEntity");
                    a.push(d);
                    c.push(e)
                }
            }
            return {
                y3: a,
                x3: c
            }
        },
        G6 = function(a, b, c) {
            b = {
                track: Wnb(b)
            };
            c && (b.playlistId = c);
            if (a = g.Q(a.actionMetadata, $nb)) b.maximumDownloadQuality = a.maximumDownloadQuality;
            return {
                musicTrackEntityActionMetadata: b
            }
        },
        bob = function(a) {
            var b, c, d, e, f, h, l, m;
            return g.J(function(n) {
                switch (n.j) {
                    case 1:
                        return b = g.rA(), c = anb(a), d = g.bz(aob), g.wa(n, 2), f = {
                            Qr: !0
                        }, g.F(n, g.gA(b, c, d, void 0, f), 4);
                    case 4:
                        e = n.B;
                        g.xa(n, 3);
                        break;
                    case 2:
                        h = g.ya(n);
                        if (h instanceof g.oA) throw l = "GetOffline network manager error: " + h.message, g6(l, h), Error(l);
                        g6("GetOffline fetch request error", h);
                        throw Error("GetOffline fetch request error");
                    case 3:
                        m = H6(e);
                        if (!e) throw g6("Network request failed"), Error("Network request failed");
                        if (m !== void 0) I6(m);
                        else if (!e.videos || !e.videos.length) throw g6("No data"),
                            Error("No data");
                        return n.return(e.videos.map(function(p) {
                            return p.offlineVideoData
                        }))
                }
            })
        },
        cob = function(a) {
            var b, c, d, e, f, h, l, m;
            return g.J(function(n) {
                switch (n.j) {
                    case 1:
                        return b = g.rA(), c = bnb(a), d = g.bz(aob), g.wa(n, 2), f = {
                            Qr: !0
                        }, g.F(n, g.gA(b, c, d, void 0, f), 4);
                    case 4:
                        e = n.B;
                        g.xa(n, 3);
                        break;
                    case 2:
                        h = g.ya(n);
                        if (h instanceof g.oA) throw l = "GetOffline network manager error for playlist: " + h.message, g6(l, h), Error(l);
                        g6("GetOffline fetch request error for playlist", h);
                        throw Error("GetOffline fetch request error for playlist");
                    case 3:
                        m = H6(e);
                        if (!e) throw g6("Network request failed for playlist"), Error("Network request failed for playlist");
                        if (m !== void 0) I6(m, "playlist");
                        else if (!e.playlists || !e.playlists.length) throw g6("No data for playlist"), Error("No data for playlist");
                        return n.return(e.playlists.map(function(p) {
                            return p.offlinePlaylistData
                        }))
                }
            })
        },
        eob = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb;
            return g.J(function(Ea) {
                switch (Ea.j) {
                    case 1:
                        return g.F(Ea, c6(), 2);
                    case 2:
                        e = Ea.B;
                        if (!e) return Ea.return([]);
                        f = [];
                        if ((h = d) == null ? 0 : h.length) {
                            f = d;
                            Ea.Fa(3);
                            break
                        }
                        return g.F(Ea, b6(e, "mainPlaylistEntity"), 4);
                    case 4:
                        f = Ea.B;
                    case 3:
                        if (!f.length) return Ea.return([]);
                        l = [];
                        m = Date.now() / 1E3;
                        n = g.w(f);
                        p = n.next();
                    case 5:
                        if (p.done) return l.length ? g.F(Ea, dob(l), 10) : Ea.return([]);
                        q = p.value;
                        if (!q.downloadState) {
                            r = void 0;
                            Ea.Fa(8);
                            break
                        }
                        return g.F(Ea, a6(e, q.downloadState, "mainPlaylistDownloadStateEntity"), 9);
                    case 9:
                        r =
                            Ea.B;
                    case 8:
                        t = r;
                        u = void 0;
                        B = (y = (u = q) == null ? void 0 : u.entityMetadata) && y.nextAutoRefreshIntervalSeconds ? Number(y.nextAutoRefreshIntervalSeconds) : NaN;
                        C = Number.isNaN(B) ? a : B;
                        H = G = void 0;
                        N = ((G = t) == null ? 0 : G.lastSyncedTimestampMillis) ? Number((H = t) == null ? void 0 : H.lastSyncedTimestampMillis) / 1E3 : 0;
                        X = M = void 0;
                        W = ((M = t) == null ? 0 : M.addedTimestampMillis) ? Number((X = t) == null ? void 0 : X.addedTimestampMillis) / 1E3 : 0;
                        if (c || !y || N + C <= m) {
                            fa = [];
                            pa = void 0;
                            if ((pa = q.videos) == null ? 0 : pa.length)
                                for (ba = g.w(q.videos), R = ba.next(); !R.done; R =
                                    ba.next()) V = R.value, v = JSON.parse(g.FK(V).entityId), v.videoId && fa.push(v.videoId);
                            U = "0";
                            y && (bb = void 0, U = String(Number((bb = y.offlineLastModifiedTimestampSeconds) != null ? bb : 0).toFixed()));
                            yb = {
                                playlistId: q.playlistId,
                                videoIds: fa,
                                offlineLastModifiedTimestamp: U,
                                autoSync: b,
                                offlineDateAddedTimestamp: String(W.toFixed())
                            };
                            l.push(yb)
                        }
                        p = n.next();
                        Ea.Fa(5);
                        break;
                    case 10:
                        return lb = Ea.B, Ea.return(lb)
                }
            })
        },
        fob = function() {
            var a, b, c, d, e;
            return g.J(function(f) {
                if (f.j == 1) return g.F(f, c6(), 2);
                if (f.j != 3) return (a = f.B) ? g.F(f, b6(a, "refresh"), 3) : f.return(!1);
                b = f.B;
                if ((c = b[0]) == null || !c.refreshTime) return f.return(!1);
                d = Number(b[0].refreshTime);
                e = Date.now() / 1E3;
                return f.return(isFinite(d) && e >= d)
            })
        },
        hob = function(a, b) {
            var c, d, e;
            return g.J(function(f) {
                switch (f.j) {
                    case 1:
                        return g.wa(f, 2), g.F(f, gob(a, b), 4);
                    case 4:
                        return d = f.B, g.F(f, Lnb(d), 5);
                    case 5:
                        c = Onb(d);
                        g.xa(f, 3);
                        break;
                    case 2:
                        e = g.ya(f), g6("getAndProcessSmartDownloadsResponse request or processing error", e);
                    case 3:
                        return f.return(c)
                }
            })
        },
        iob = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb;
            return g.J(function(Ea) {
                switch (Ea.j) {
                    case 1:
                        return g.F(Ea, c6(), 2);
                    case 2:
                        e = Ea.B;
                        if (!e) return Ea.return([]);
                        f = [];
                        if ((h = d) == null ? 0 : h.length) {
                            f = d;
                            Ea.Fa(3);
                            break
                        }
                        return g.F(Ea, b6(e, "musicPlaylist"), 4);
                    case 4:
                        f = Ea.B;
                    case 3:
                        if (!f.length) return Ea.return([]);
                        l = [];
                        m = Date.now() / 1E3;
                        n = g.w(f);
                        p = n.next();
                    case 5:
                        if (p.done) return l.length ? g.F(Ea, dob(l), 10) : Ea.return([]);
                        q = p.value;
                        r = void 0;
                        u = (t = (r = q) == null ? void 0 : r.entityMetadata) && t.nextAutoRefreshIntervalSeconds ? Number(t.nextAutoRefreshIntervalSeconds) : NaN;
                        y =
                            Number.isNaN(u) ? a : u;
                        C = B = 0;
                        G = "DOWNLOAD_SYNC_STATE_UNKNOWN";
                        if (!q.downloadMetadata) {
                            Ea.Fa(8);
                            break
                        }
                        return g.F(Ea, a6(e, q.downloadMetadata, "musicPlaylistDownloadMetadataEntity"), 9);
                    case 9:
                        H = Ea.B, M = N = void 0, B = Number((M = (N = H) == null ? void 0 : N.addedTimestampMillis) != null ? M : "0") / 1E3, W = X = void 0, C = Number((W = (X = H) == null ? void 0 : X.lastModifiedTimestampMillis) != null ? W : "0") / 1E3, pa = fa = void 0, G = (pa = (fa = H) == null ? void 0 : fa.syncState) != null ? pa : "DOWNLOAD_SYNC_STATE_UNKNOWN";
                    case 8:
                        ba = void 0;
                        if (c || G !== "DOWNLOAD_SYNC_STATE_UP_TO_DATE" ||
                            !t || Number((ba = t.lastSyncedTimestampSeconds) != null ? ba : 0) + y <= m) {
                            R = [];
                            V = void 0;
                            if ((V = q.tracks) == null ? 0 : V.length)
                                for (v = g.w(q.tracks), U = v.next(); !U.done; U = v.next()) bb = U.value, R.push(g.FK(bb).entityId);
                            yb = {
                                playlistId: q.playlistId,
                                videoIds: R,
                                offlineLastModifiedTimestamp: String(C.toFixed()),
                                autoSync: b,
                                offlineDateAddedTimestamp: String(B.toFixed())
                            };
                            l.push(yb)
                        }
                        p = n.next();
                        Ea.Fa(5);
                        break;
                    case 10:
                        return lb = Ea.B, Ea.return(lb)
                }
            })
        },
        gob = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q;
            return g.J(function(r) {
                switch (r.j) {
                    case 1:
                        return c = g.rA(), g.F(r, c6(), 2);
                    case 2:
                        d = r.B;
                        if (!d) {
                            r.Fa(3);
                            break
                        }
                        return g.F(r, inb(d), 4);
                    case 4:
                        e = r.B;
                    case 3:
                        var t = e;
                        f = {
                            context: g.Yy(),
                            browseId: "FEdownloads",
                            browseRequestSupportedMetadata: {
                                downloadsBrowseParams: {
                                    offlineFeatureSettingState: {
                                        isSdEnabled: a
                                    },
                                    offlineClientState: t,
                                    clientStateRequestData: {
                                        preferredFormatType: b
                                    }
                                }
                            }
                        };
                        h = g.bz(job);
                        g.wa(r, 5);
                        m = {
                            Qr: !0
                        };
                        return g.F(r, g.gA(c, f, h, void 0, m), 7);
                    case 7:
                        l = r.B;
                        g.xa(r, 6);
                        break;
                    case 5:
                        n = g.ya(r);
                        if (n instanceof g.oA) throw p =
                            "DPS network manager error for smart downloads: " + n.message, g6(p, n), Error(p);
                        g6("DPS fetch request error for smart downloads", n);
                        throw Error("DPS fetch request error for smart downloads");
                    case 6:
                        q = H6(l);
                        if (l) q !== void 0 && I6(q, "smart downloads");
                        else throw g6("Network request failed for smart downloads"), Error("Network request failed for smart downloads");
                        return r.return(l)
                }
            })
        },
        lob = function(a, b) {
            var c, d, e, f, h, l, m, n;
            return g.J(function(p) {
                switch (p.j) {
                    case 1:
                        return c = g.rA(), d = {
                            context: g.Yy(),
                            videoPlaybackPositionEntities: a,
                            lastSyncTimestampUsec: b
                        }, e = g.bz(kob), g.wa(p, 2), h = {
                            Qr: !0
                        }, g.F(p, g.gA(c, d, e, void 0, h), 4);
                    case 4:
                        f = p.B;
                        g.xa(p, 3);
                        break;
                    case 2:
                        l = g.ya(p);
                        if (l instanceof g.oA) throw m = "VPPS network manager error: " + l.message, g6(m, l), Error(m);
                        g6("VPPS fetch request error", l);
                        throw Error("VPPS fetch request error");
                    case 3:
                        n = H6(f);
                        if (f) n !== void 0 && I6(n, "position sync");
                        else throw g6("Network request failed for position sync"),
                            Error("Network request failed for position sync");
                        return p.return(f)
                }
            })
        },
        nob = function(a, b, c) {
            var d, e, f, h, l, m, n, p;
            return g.J(function(q) {
                switch (q.j) {
                    case 1:
                        d = g.rA();
                        var r = c.refreshData,
                            t = c.isEnqueuedForExpiredStreamUrlRefetch,
                            u = c.e4,
                            y = c.offlineSourceData,
                            B = {
                                entityKey: a
                            };
                        r && (B.refreshData = r);
                        t && (B.isExpiredStreamUrlRefetch = t);
                        u && (B.downloadParameters = u);
                        y && (B.offlineSourceData = y);
                        e = {
                            context: g.rR(b),
                            signatureTimestamp: 19969,
                            videos: [B]
                        };
                        f = g.bz(mob);
                        g.wa(q, 2);
                        l = {
                            Qr: !0
                        };
                        return g.F(q, g.gA(d, e, f, void 0, l), 4);
                    case 4:
                        h = q.B;
                        g.xa(q, 3);
                        break;
                    case 2:
                        m = g.ya(q);
                        if (m instanceof g.oA) throw n = "GetPDE network manager error: " +
                            m.message, g6(n, m), Error(n);
                        g6("GetPDE fetch request error", m);
                        throw Error("GetPDE fetch request error");
                    case 3:
                        p = H6(h);
                        if (h) p !== void 0 && I6(p, "PDE");
                        else throw g6("Network request failed for PDE"), Error("Network request failed for PDE");
                        return q.return(h)
                }
            })
        },
        H6 = function(a) {
            var b;
            return (b = a.errorMetadata) == null ? void 0 : b.status
        },
        I6 = function(a, b) {
            b = b ? " for " + b : "";
            if (a === 0) throw a = "Empty response body" + b, g6(a), Error(a);
            a = "Response with error" + b;
            g6(a);
            throw Error(a);
        },
        dob = function(a) {
            var b, c, d, e, f, h, l, m;
            return g.J(function(n) {
                switch (n.j) {
                    case 1:
                        return b = g.rA(), c = cnb(a), d = g.bz(oob), g.wa(n, 2), f = {
                            Qr: !0
                        }, g.F(n, g.gA(b, c, d, void 0, f), 4);
                    case 4:
                        e = n.B;
                        g.xa(n, 3);
                        break;
                    case 2:
                        h = g.ya(n);
                        if (h instanceof g.oA) throw l = "offlinePlaylistSyncCheck network manager error: " + h.message, g6(l, h), Error(l);
                        g6("offlinePlaylistSyncCheck fetch request error", h);
                        throw Error("offlinePlaylistSyncCheck fetch request error");
                    case 3:
                        m = H6(e);
                        if (!e) throw g6("Network request failed for playlist sync"), Error("Network request failed for playlist sync");
                        if (m !== void 0) I6(m, "playlist sync");
                        else if (!e.offlinePlaylistSyncCheckDatas || !e.offlinePlaylistSyncCheckDatas.length) throw g6("No data for playlist sync"), Error("No data for playlist sync");
                        return n.return(e.offlinePlaylistSyncCheckDatas.map(function(p) {
                            return p.offlinePlaylistSyncCheckData
                        }))
                }
            })
        },
        J6 = function(a) {
            this.j = a
        },
        pob = function(a, b) {
            var c, d, e, f, h, l;
            return g.J(function(m) {
                switch (m.j) {
                    case 1:
                        c = new Map, d = g.w(b), e = d.next();
                    case 2:
                        if (e.done) {
                            m.Fa(4);
                            break
                        }
                        f = e.value;
                        h = c;
                        l = h.set;
                        return g.F(m, a.B(f), 5);
                    case 5:
                        l.call(h, f, m.B);
                        e = d.next();
                        m.Fa(2);
                        break;
                    case 4:
                        return m.return(c)
                }
            })
        },
        K6 = function(a, b, c, d, e, f) {
            b = g.GK(b, c);
            d = Object.assign({}, f, {
                priority: d,
                retryScheduleIntervalsInSeconds: e
            });
            return {
                actionType: a,
                entityKey: b,
                actionMetadata: d
            }
        },
        L6 = function(a, b, c, d, e, f) {
            this.status = a;
            this.j = b;
            this.D = c;
            this.B = d;
            this.C = e;
            this.downloadState = f
        },
        qob = function(a, b, c) {
            this.j = a;
            this.X = b;
            this.C = c
        },
        tob = function(a, b) {
            var c, d, e, f, h, l, m, n, p;
            return g.J(function(q) {
                switch (q.j) {
                    case 1:
                        return c = b.entityKey, e = (d = g.Q(b.actionMetadata, M6)) == null ? void 0 : d.isEnqueuedForExpiredStreamUrlRefetch, g.wa(q, 2), f = void 0, g.F(q, rob(a, b), 4);
                    case 4:
                        f = q.B;
                        g.wa(q, 5);
                        var r = (r = g.Q(b.actionMetadata, M6)) ? {
                            maximumDownloadQuality: r.maximumDownloadQuality
                        } : void 0;
                        return g.F(q, nob(c, a.X, {
                            isEnqueuedForExpiredStreamUrlRefetch: e,
                            e4: r,
                            offlineSourceData: f
                        }), 7);
                    case 7:
                        h = q.B;
                        g.xa(q, 6, 2);
                        break;
                    case 5:
                        return g.ya(q, 2), l = m6(b) ? "OFFLINE_ORCHESTRATION_FAILURE_REASON_RECOVERABLE_NETWORK_ERROR" :
                            "OFFLINE_ORCHESTRATION_FAILURE_REASON_UNRECOVERABLE_NETWORK_ERROR", g6("PDE handleAdd error"), q.return(N6(b, !1, void 0, "OFFLINE_OPERATION_FAILURE_REASON_NETWORK_REQUEST_FAILED", l, "DOWNLOAD_STATE_FAILED"));
                    case 6:
                        return g.F(q, sob(a, h, b), 8);
                    case 8:
                        return q.return(N6(b, !0, h.orchestrationActions));
                    case 2:
                        return m = g.ya(q), n = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", p = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", m instanceof g.qt && m.type === "QUOTA_EXCEEDED" && (n = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED",
                            p = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), g6("PDE handleAdd error"), q.return(N6(b, !1, void 0, n, p, "DOWNLOAD_STATE_FAILED"))
                }
            })
        },
        uob = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N;
            return g.J(function(M) {
                switch (M.j) {
                    case 1:
                        return c = b.entityKey, g.F(M, Z5(a.j, {
                            mode: "readonly",
                            Pb: !0
                        }, function(X) {
                            var W = S5(X, c, "playbackData"),
                                fa = S5(X, g.GK(g.FK(b.entityKey).entityId, "offlineVideoPolicy"), "offlineVideoPolicy");
                            X = S5(X, g.GK(g.FK(b.entityKey).entityId, "transfer"), "transfer");
                            return g.zt.all([W, fa, X])
                        }), 2);
                    case 2:
                        d = M.B;
                        e = g.w(d);
                        f = e.next().value;
                        h = e.next().value;
                        l = e.next().value;
                        m = f;
                        n = h;
                        p = l;
                        if (!m || !n) return M.return(N6(b, !0));
                        q = {
                            lastPlayerResponseTimestampSeconds: m.playerResponseTimestamp,
                            offlineToken: n.offlineToken
                        };
                        r = {};
                        if ((t = p) == null ? 0 : t.maximumDownloadQuality) r.maximumDownloadQuality = p.maximumDownloadQuality;
                        g.wa(M, 3);
                        u = void 0;
                        return g.F(M, rob(a, b), 5);
                    case 5:
                        return u = M.B, g.wa(M, 6), g.F(M, nob(c, a.X, {
                            refreshData: q,
                            e4: r,
                            offlineSourceData: u
                        }), 8);
                    case 8:
                        y = M.B;
                        g.xa(M, 7, 3);
                        break;
                    case 6:
                        return g.ya(M, 3),
                            B = m6(b) ? "OFFLINE_ORCHESTRATION_FAILURE_REASON_RECOVERABLE_NETWORK_ERROR" : "OFFLINE_ORCHESTRATION_FAILURE_REASON_UNRECOVERABLE_NETWORK_ERROR", g6("PDE handleRefresh error"), M.return(N6(b, !1, void 0, "OFFLINE_OPERATION_FAILURE_REASON_NETWORK_REQUEST_FAILED", B, "DOWNLOAD_STATE_FAILED"));
                    case 7:
                        return g.F(M, sob(a, y, b), 9);
                    case 9:
                        return M.return(N6(b, !0, y.orchestrationActions));
                    case 3:
                        return C = g.ya(M), G = "PDE handleRefresh error", C instanceof Error && (G = "PDE handleRefresh error: " + C.message), H = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN",
                            N = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", C instanceof g.qt && C.type === "QUOTA_EXCEEDED" && (H = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", N = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), g6(G), M.return(N6(b, !1, void 0, H, N, "DOWNLOAD_STATE_FAILED"))
                }
            })
        },
        rob = function(a, b) {
            var c, d, e, f;
            return g.J(function(h) {
                if (h.j == 1) return c = g.FK(b.entityKey).entityId, d = g.GK(c, "videoDownloadContextEntity"), g.F(h, a6(a.j, d, "videoDownloadContextEntity"), 2);
                e = h.B;
                return (f = e) != null && f.offlineModeType ? h.return({
                    offlineModeType: e.offlineModeType
                }) : h.return(void 0)
            })
        },
        sob = function(a, b, c) {
            var d, e, f, h, l;
            return g.J(function(m) {
                if (m.j == 1) {
                    if (!b.frameworkUpdates || !g.Q(b.frameworkUpdates, A6)) return m.return();
                    if (!(g.Q(b.frameworkUpdates, A6).mutations && g.Q(b.frameworkUpdates, A6).mutations.length > 0 && g.Q(b.frameworkUpdates, A6).mutations[0].type === "ENTITY_MUTATION_TYPE_DELETE")) return m.Fa(2);
                    d = g.FK(g.Q(b.frameworkUpdates, A6).mutations[0].entityKey).entityId;
                    return g.F(m, C6(a.j, d), 3)
                }
                if (m.j != 2) {
                    e = m.B;
                    f = g.Q(c.actionMetadata, M6);
                    if (l = (h = f) == null ? void 0 : h.playlistId) e.playlistId = l;
                    e.offlineDeleteReason = "OFFLINE_DELETE_REASON_UNKNOWN";
                    return g.qP(a.X) ? g.F(m, z6(d, a.j, c, a.C, e), 2) : g.Ly(a.X) ? g.F(m, D6(d, a.j, c, a.C), 2) : m.Fa(2)
                }
                return g.F(m, Tmb(g.Q(b.frameworkUpdates, A6)), 0)
            })
        },
        N6 = function(a, b, c, d, e, f) {
            return new L6(b ? "OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS" : "OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", m6(a), c, d, e, f)
        },
        vob = function(a, b) {
            this.j = a;
            this.X = b
        },
        wob = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r;
            return g.J(function(t) {
                switch (t.j) {
                    case 1:
                        return c = m6(b), g.F(t, b6(a.j, "videoPlaybackPositionEntity"), 2);
                    case 2:
                        return d = t.B, g.wa(t, 3), g.F(t, O5.getInstance(), 5);
                    case 5:
                        e = t.B;
                        if (!e) throw Error("prefStorage is undefined");
                        return g.F(t, e.get("psi"), 6);
                    case 6:
                        return f = t.B, m = (l = (h = f) == null ? void 0 : h.FR) != null ? l : "0", g.F(t, lob(d, m), 7);
                    case 7:
                        return n = t.B, p = {
                            isPaused: n.watchHistoryPaused,
                            FR: n.syncTimestampUsec
                        }, g.F(t, e.set("psi", p), 8);
                    case 8:
                        if (p.isPaused) {
                            t.Fa(9);
                            break
                        }
                        return g.F(t, Tmb(g.Q(n.frameworkUpdates,
                            A6)), 9);
                    case 9:
                        g.xa(t, 4);
                        break;
                    case 3:
                        return q = g.ya(t), r = "PPE handleRefresh error: " + (q instanceof Error ? q.message : "unknown error"), g6(r), t.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 4:
                        return t.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c))
                }
            })
        },
        yob = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q;
            return g.J(function(r) {
                switch (r.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey).entityId, g.F(r, a6(a.j, b.entityKey, "videoPlaybackPositionEntity"), 2);
                    case 2:
                        e = r.B;
                        if (!e || d !== e.videoId) return r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        g.wa(r, 3);
                        return g.F(r, O5.getInstance(), 5);
                    case 5:
                        f = r.B;
                        if (!f) throw Error("prefStorage is undefined");
                        return g.F(r, f.get("psi"), 6);
                    case 6:
                        h = r.B;
                        l = g.Q(b.actionMetadata, xob);
                        if (((m = h) == null ? void 0 : m.isPaused) !== !1 || (n = l) == null || !n.lastPlaybackPositionSeconds ||
                            ((p = l) == null ? void 0 : p.lastPlaybackPositionSeconds) === ((q = e) == null ? void 0 : q.lastPlaybackPositionSeconds)) {
                            r.Fa(7);
                            break
                        }
                        e.lastPlaybackPositionSeconds = l.lastPlaybackPositionSeconds;
                        return g.F(r, $5(a.j, e, "videoPlaybackPositionEntity"), 7);
                    case 7:
                        g.xa(r, 4);
                        break;
                    case 3:
                        return g.ya(r), r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 4:
                        return r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c))
                }
            })
        },
        zob = function(a, b) {
            var c, d, e;
            return g.J(function(f) {
                switch (f.j) {
                    case 1:
                        c = m6(b);
                        g.wa(f, 2);
                        d = g.FK(b.entityKey).entityId;
                        if (d === "!*$_ALL_ENTITIES_!*$") return g.F(f, Omb(a.j), 5);
                        e = g.GK(d, "videoPlaybackPositionEntity");
                        return g.F(f, Nmb(a.j, e), 5);
                    case 5:
                        g.xa(f, 3);
                        break;
                    case 2:
                        return g.ya(f), f.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 3:
                        return f.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c))
                }
            })
        },
        Aob = function(a, b) {
            this.api = a;
            this.j = b;
            this.logger = new g.ET("woffle");
            this.B = !1;
            this.bd = {
                lQ: this.lQ
            };
            this.logger.debug("Initialized OfflineMediaManager")
        },
        Bob = function(a) {
            return g.J(function(b) {
                return b.return($mb(a))
            })
        },
        Cob = function(a) {
            var b;
            return g.J(function(c) {
                if (c.j == 1) return g.F(c, g.CKa(a), 2);
                b = c.B;
                return c.return(b.filter(function(d) {
                    return !!d.url
                }).map(function(d) {
                    return d.url
                }))
            })
        },
        O6 = function(a, b) {
            var c = g.XP(b);
            if (c === 1 || c === 0) return Promise.resolve();
            (c = Dob(a, b)) && c.stopVideo();
            a.C = 0;
            return Bob(b)
        },
        P6 = function(a, b, c, d) {
            c = c === void 0 ? !1 : c;
            d = d === void 0 ? !0 : d;
            var e = typeof b === "string" ? b : b.videoDetails.videoId;
            g.XP(e) === 2 && ((b = Dob(a, e)) ? b.stopVideo() : a.logger.info(function() {
                return "Corresponding player for " + e + " not found. Pausing anyway"
            }), g.YP(e, 2), a.C = 2, c ? Eob(a.j) : d && Fob(a.j))
        },
        Dob = function(a, b) {
            var c;
            return ((c = a.player) == null ? void 0 : c.getVideoData().videoId) === b ? a.player : null
        },
        Gob = function(a, b, c) {
            b.getPlayerResponse();
            g.YP(b.videoId, 2);
            a.C = 2;
            a.B = !1;
            var d;
            (d = a.player) == null || d.dispose();
            a.player = a.api.nA(9, b);
            b = {};
            g.hx(a.player, (b.localmediachange = a.XL, b.signatureexpired = a.CS, b.statechange = a.jba, b), a);
            var e = a.lQ(c);
            g.cYa(a.player, g.uL(e, e, !0, "m"), !1);
            a.logger.debug(function() {
                return "Starting headless playback with quality: " + e
            });
            g.OW(a.player, !1)
        },
        Hob = function(a, b) {
            this.j = a;
            this.X = b
        },
        Job = function(a, b) {
            var c, d;
            return g.J(function(e) {
                switch (e.j) {
                    case 1:
                        return c = m6(b), g.F(e, a6(a.j, b.entityKey, "transfer"), 2);
                    case 2:
                        if (d = e.B) return e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        g.wa(e, 3);
                        return g.F(e, Iob(a, b), 5);
                    case 5:
                        g.xa(e, 4);
                        break;
                    case 3:
                        return g.ya(e), e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 4:
                        return e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c))
                }
            })
        },
        Kob = function(a, b) {
            var c, d;
            return g.J(function(e) {
                switch (e.j) {
                    case 1:
                        return c = m6(b), g.F(e, a6(a.j, b.entityKey, "transfer"), 2);
                    case 2:
                        d = e.B;
                        if (!d || d.transferState !== "TRANSFER_STATE_COMPLETE") return e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        g.wa(e, 3);
                        return g.F(e, Iob(a, b, !0), 5);
                    case 5:
                        g.xa(e, 4);
                        break;
                    case 3:
                        return g.ya(e), e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 4:
                        return e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c))
                }
            })
        },
        Lob = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q;
            return g.J(function(r) {
                switch (r.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey).entityId, g.F(r, Z5(a.j, {
                            mode: "readonly",
                            Pb: !0
                        }, function(t) {
                            var u = S5(t, b.entityKey, "transfer");
                            t = S5(t, g.GK(d, "videoDownloadContextEntity"), "videoDownloadContextEntity");
                            return g.zt.all([u, t])
                        }), 2);
                    case 2:
                        e = r.B;
                        f = g.w(e);
                        h = f.next().value;
                        l = f.next().value;
                        m = h;
                        n = l;
                        if (!m || m.transferState !== "TRANSFER_STATE_WAITING_FOR_PLAYER_RESPONSE_REFRESH") return r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        g.wa(r, 3);
                        m.transferState = "TRANSFER_STATE_TRANSFER_IN_QUEUE";
                        return g.F(r, $5(a.j, m, "transfer"), 5);
                    case 5:
                        p = g.FK(m.key).entityId;
                        l6({
                            transferStatusType: "TRANSFER_STATUS_TYPE_REENQUEUED_BY_PLAYER_RESPONSE_REFRESH"
                        }, {
                            videoId: p,
                            lm: m,
                            offlineModeType: (q = n) == null ? void 0 : q.offlineModeType
                        });
                        g.xa(r,
                            4);
                        break;
                    case 3:
                        return g.ya(r), r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 4:
                        return r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c))
                }
            })
        },
        Iob = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            var d, e, f, h, l, m, n, p, q, r, t, u, y, B, C;
            return g.J(function(G) {
                switch (G.j) {
                    case 1:
                        return d = g.Q(b.actionMetadata, Mob), e = g.FK(b.entityKey).entityId, f = g.GK(e, "downloadStatusEntity"), g.F(G, Z5(a.j, {
                            mode: "readonly",
                            Pb: !0
                        }, function(H) {
                            var N = S5(H, f, "downloadStatusEntity");
                            H = S5(H, g.GK(e, "videoDownloadContextEntity"), "videoDownloadContextEntity");
                            return g.zt.all([N, H])
                        }), 2);
                    case 2:
                        return h = G.B, l = g.w(h), m = l.next().value, n = l.next().value, p = m, q = n, r = "TRANSFER_STATE_TRANSFER_IN_QUEUE", ((t = p) == null ? void 0 : t.downloadState) === "DOWNLOAD_STATE_USER_DELETED" && (r = "TRANSFER_STATE_PAUSED_BY_USER"), B = {
                            key: b.entityKey,
                            transferState: r,
                            cotn: g.vv(16),
                            enqueuedTimestampMs: Date.now().toString(),
                            maximumDownloadQuality: (u = d) == null ? void 0 : u.maximumDownloadQuality,
                            preferredAudioTrack: (y = d) == null ? void 0 : y.preferredAudioTrack,
                            transferRetryCount: 0,
                            isRefresh: c,
                            hasLoggedFirstStarted: !1
                        }, g.F(G, Z5(a.j, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(H) {
                            var N = [];
                            c && N.push(W5(H, g.GK(e, "offlineVideoStreams")));
                            N.push(V5(H, B, "transfer"));
                            return g.zt.all(N)
                        }), 3);
                    case 3:
                        if (!a.X.L("html5_refresh_offline_media_bytes") || !c) {
                            G.Fa(4);
                            break
                        }
                        return g.F(G, Bob(e), 4);
                    case 4:
                        l6({
                            transferStatusType: "TRANSFER_STATUS_TYPE_ENQUEUED",
                            statusType: "ADDED_TO_QUEUE"
                        }, {
                            videoId: e,
                            lm: B,
                            offlineModeType: (C = q) == null ? void 0 : C.offlineModeType
                        }), g.va(G)
                }
            })
        },
        Oob = function(a, b, c, d) {
            if (!a.action.entityKey) throw Error("entityKey is missing.");
            var e = g.FK(a.action.entityKey);
            e = {
                entityType: e.J8,
                entityId: e.entityId,
                offlineOrchestrationActionType: a.action.actionType,
                orchestrationAction: {
                    orchestrationActionId: a.actionId
                }
            };
            b && (e.offlineOrchestrationActionResult = b.status, e.isRetryable = c ? !1 : b.j, b.C && (e.offlineOrchestrationFailureReason = Nob(b.C, e.isRetryable)));
            var f, h;
            if ((f = a.action.actionMetadata) == null ? 0 : (h = f.offlineLoggingData) == null ? 0 : h.offlineModeType) e.offlineModeType = a.action.actionMetadata.offlineLoggingData.offlineModeType;
            d && (e.additionalOrchestrationActions =
                d.map(function(l) {
                    return {
                        orchestrationActionId: l.actionId
                    }
                }));
            return e
        },
        Nob = function(a, b) {
            return a !== "OFFLINE_ORCHESTRATION_FAILURE_REASON_RECOVERABLE_NETWORK_ERROR" || b ? a === "OFFLINE_ORCHESTRATION_FAILURE_REASON_UNRECOVERABLE_NETWORK_ERROR" && b ? "OFFLINE_ORCHESTRATION_FAILURE_REASON_RECOVERABLE_NETWORK_ERROR" : a : "OFFLINE_ORCHESTRATION_FAILURE_REASON_UNRECOVERABLE_NETWORK_ERROR"
        },
        Pob = function(a, b) {
            var c = {
                offlineOrchestrationContext: Oob(a)
            };
            b = gnb(b, c);
            hnb(fnb(), b, a.rootActionId)
        },
        Qob = function(a, b, c, d) {
            d = d === void 0 ? [] : d;
            b = {
                offlineOrchestrationContext: Oob(a, b, c, d)
            };
            b = gnb(3, b);
            hnb(fnb(), b, a.rootActionId)
        },
        Rob = function() {
            this.actions = []
        },
        Sob = function(a, b) {
            b = g.w(b);
            for (var c = b.next(); !c.done; c = b.next()) c = c.value, Pob(c, 1), a.actions.push(c);
            a.actions.sort(a.j)
        },
        Tob = function(a, b) {
            if (b)
                for (var c = 0; c < a.actions.length; c++)
                    if (b === "!*$_ALL_ENTITIES_!*$" && a.actions[c].actionId !== b || b !== "!*$_ALL_ENTITIES_!*$" && a.actions[c].rootActionId === b && a.actions[c].actionId !== b) a.actions.splice(c, 1), c--
        },
        Uob = function(a, b) {
            a = g.w(a.actions);
            for (var c = a.next(); !c.done; c = a.next())
                if (c.value.actionId === b) return !0;
            return !1
        },
        Q6 = function(a, b, c, d, e) {
            g.O.call(this);
            var f = this;
            this.B = a;
            this.Ba = b;
            this.oa = c;
            this.N = d;
            this.X = e;
            this.j = new Rob;
            this.K = new g.Yu;
            this.C = new g.Zo(function() {
                f.retry()
            });
            this.Z = NaN;
            this.G = !1;
            this.bd = {
                Aoa: function() {
                    return f.j
                },
                XY: function() {
                    return f.K
                },
                Foa: function() {
                    return f.C
                },
                retry: function() {
                    return f.retry()
                }
            };
            g.P(this, this.C);
            this.Y = Lmb(this.B, this.qa.bind(this))
        },
        Xob = function(a, b, c, d, e) {
            var f;
            return g.J(function(h) {
                if (h.j == 1) return f = new Q6(a, b, c, d, e), g.F(h, Vob(f), 2);
                Wob(f);
                return h.return(f)
            })
        },
        Wob = function(a) {
            var b = a.j.actions[0];
            return a.D ? ((b == null ? void 0 : b.action.actionType) === "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE" && a.D[0].action.actionType !== "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE" && (a.G = !0), Promise.resolve()) : Yob(a)
        },
        Yob = function(a) {
            var b, c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C;
            return g.J(function(G) {
                switch (G.j) {
                    case 1:
                        if (a.D) throw Error("Already processing an action");
                        if (a.Ja()) return G.return();
                        b = a.j.actions.shift();
                        unb(a.oa, !b);
                        if (b === void 0) return G.return();
                        b.action.actionType === "OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH" && b.actionId === "DOWNLOADS_LIST_ENTITY_ID_SMART_DOWNLOADS" && Tob(a.j, b.actionId);
                        c = "";
                        b.action.actionType === "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE" && b.rootActionId === b.actionId && (c = b.actionId);
                        d = [b];
                        a.D = d;
                        if (e = a.Ba[b.entityType]) {
                            G.Fa(2);
                            break
                        }
                        a.D =
                            void 0;
                        return g.F(G, Yob(a), 3);
                    case 3:
                        return G.return();
                    case 2:
                        f = g.w(d);
                        for (h = f.next(); !h.done; h = f.next()) l = h.value, Pob(l, 2);
                        g.wa(G, 4, 5);
                        return g.F(G, pob(e, d.map(function(H) {
                            return H.action
                        })), 7);
                    case 7:
                        m = G.B, n = g.w(d), p = n.next();
                    case 8:
                        if (p.done) {
                            G.Fa(10);
                            break
                        }
                        q = p.value;
                        r = m.get(q.action);
                        return g.F(G, Zob(a, q, r), 9);
                    case 9:
                        p = n.next();
                        G.Fa(8);
                        break;
                    case 10:
                        Tob(a.j, c);
                    case 5:
                        g.za(G);
                        a.D = void 0;
                        g.Aa(G, 6);
                        break;
                    case 4:
                        return t = g.ya(G), g6("Orchestration error", t), g.wa(G, 12), g.F(G, $ob(a, d), 14);
                    case 14:
                        g.xa(G, 5);
                        break;
                    case 12:
                        u = g.ya(G);
                        g6("Orchestration retry error", u);
                        y = g.w(d);
                        for (B = y.next(); !B.done; B = y.next()) C = B.value, C.retryScheduleIndex < 3 && Sob(a.j, [C]);
                        G.Fa(5);
                        break;
                    case 6:
                        return g.F(G, Yob(a),
                            0)
                }
            })
        },
        Zob = function(a, b, c) {
            var d, e, f, h, l, m, n, p, q, r, t, u;
            return g.J(function(y) {
                switch (y.j) {
                    case 1:
                        d = b.retryScheduleIndex + 2 === 3;
                        if (c.status === "OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS") {
                            y.Fa(2);
                            break
                        }
                        if (c.status !== "OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE") {
                            y.Fa(0);
                            break
                        }
                        Qob(b, c, d);
                        if (c.j && b.retryScheduleIndex + 1 < 3) return g.F(y, $ob(a, [b]), 0);
                        f = ((e = c) == null ? 0 : e.B) ? c.B : "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN";
                        h = {
                            entityKey: b.action.entityKey,
                            failureReason: f
                        };
                        l = void 0;
                        g.qP(a.X) ? l = "mainVideoDownloadStateEntity" : g.Ly(a.X) && (l = "musicTrackDownloadMetadataEntity");
                        if (!l || !c.downloadState) {
                            y.Fa(7);
                            break
                        }
                        m = g.FK(b.action.entityKey).entityId;
                        return g.F(y, q6(m, l, a.B, c.downloadState), 7);
                    case 7:
                        i6(a.N, h);
                        if (c.downloadState === "DOWNLOAD_STATE_FAILED" && a.X.L("html5_auto_retry_failed_pde_actions")) {
                            y.Fa(0);
                            break
                        }
                        g6("Orchestration result is not retryable, deleting action");
                        return g.F(y, Nmb(a.B, w6(b).key), 0);
                    case 2:
                        n = void 0;
                        try {
                            n = (p = c.D) == null ? void 0 : p.map(function(B) {
                                return a.createAction(B, b)
                            })
                        } catch (B) {
                            return Qob(b, c, d), q = {
                                entityKey: b.action.entityKey,
                                failureReason: "OFFLINE_OPERATION_FAILURE_REASON_UNSUPPORTED_ENTITY_FAILED"
                            }, i6(a.N, q), g6("Orchestration subactions creation error", B), y.return()
                        }
                        Qob(b, c, d, n);
                        if (!n) {
                            y.Fa(12);
                            break
                        }
                        r = n.map(function(B) {
                            return w6(B)
                        });
                        t = 0;
                    case 13:
                        if (!(t < n.length) || a.G) {
                            y.Fa(15);
                            break
                        }
                        return g.F(y, Z5(a.B, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(B) {
                            var C = [];
                            C.push(Cmb(B, r.slice(t, t + 10), "offlineOrchestrationActionWrapperEntity"));
                            return g.zt.all(C)
                        }), 16);
                    case 16:
                        t += 10;
                        y.Fa(13);
                        break;
                    case 15:
                        if (a.G) return a.G = !1, y.return();
                    case 12:
                        return u = w6(b), g.F(y, Nmb(a.B, u.key), 17);
                    case 17:
                        Pob(b, 4), g.va(y)
                }
            })
        },
        dpb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t;
            return g.J(function(u) {
                c = [];
                d = Infinity;
                e = 4E3;
                f = g.w(b);
                for (h = f.next(); !h.done; h = f.next()) l = h.value, m = Number(l.enqueueTimeSec), n = apb(m), p = l.retryScheduleIndex, q = p != null && p > 0, n > 0 && q ? (d = Math.min(d, m), e = Math.min(n, e)) : c.push(l);
                isFinite(d) && (!a.C.isActive() || d < a.Z) && (a.Z = d, a.C.start(e));
                a.K.ph() || (r = c.length, c = c.filter(function(y) {
                    var B;
                    y = ((B = y.actionProto) == null ? void 0 : B.actionType) || "OFFLINE_ORCHESTRATION_ACTION_TYPE_UNKNOWN";
                    return !bpb.includes(y)
                }), t = c.length < r, !a.C.isActive() && t && a.C.start(1));
                c.length > 0 && cpb(a, c);
                return g.F(u, Wob(a), 0)
            })
        },
        fpb = function(a) {
            var b, c, d, e, f, h, l;
            return g.J(function(m) {
                if (m.j == 1) return g.F(m, epb(a), 2);
                b = m.B;
                c = [];
                d = g.w(b);
                for (e = d.next(); !e.done; e = d.next()) f = e.value, h = g.FK(f.key), l = h.entityId, Uob(a.j, l) || c.push(f);
                return g.F(m, dpb(a, c), 0)
            })
        },
        apb = function(a) {
            a = a * 1E3 - Date.now();
            return a > 4E3 ? 4E3 : a
        },
        $ob = function(a, b) {
            var c, d, e;
            return g.J(function(f) {
                c = g.w(b);
                for (d = c.next(); !d.done; d = c.next()) {
                    e = d.value;
                    var h = void 0,
                        l = void 0,
                        m = ((l = e.action) == null ? void 0 : (h = l.actionMetadata) == null ? void 0 : h.retryScheduleIntervalsInSeconds) || [1, 2, 4];
                    h = 1;
                    e.retryScheduleIndex < m.length && (h = m[e.retryScheduleIndex]);
                    e.j = h * 1E3 + Date.now();
                    e.retryScheduleIndex++
                }
                return g.F(f, gpb(a, b), 0)
            })
        },
        Vob = function(a) {
            var b;
            return g.J(function(c) {
                if (c.j == 1) return g.F(c, b6(a.B, "offlineOrchestrationActionWrapperEntity"), 2);
                b = c.B;
                return g.F(c, dpb(a, b), 0)
            })
        },
        cpb = function(a, b) {
            b.length !== 0 && b.forEach(function(c) {
                c = v6(c);
                c.retryScheduleIndex < 3 && Sob(a.j, [c])
            })
        },
        epb = function(a, b) {
            var c;
            return g.J(function(d) {
                if (d.j == 1) return g.F(d, b6(a.B, "offlineOrchestrationActionWrapperEntity", b), 2);
                c = d.B;
                return d.return(c.filter(Umb))
            })
        },
        gpb = function(a, b) {
            if (b.length === 0) return Promise.resolve([]);
            b = b.map(function(c) {
                return w6(c)
            });
            return Mmb(a.B, b)
        },
        hpb = function() {
            this.j = void 0
        },
        jpb = function(a, b) {
            var c, d, e, f, h;
            return g.J(function(l) {
                c = b.videoId;
                d = b.U();
                e = !0;
                if (b.captionTracks.length) f = Jkb(b), a.j = new g.ZX(d, b, f);
                else if (b.ze) h = g.ULa(b), a.j = new g.$X(d, b.ze, c, h, b.Kn, b.eventId), e = b.Kn;
                else return l.return();
                return l.return(new Promise(function(m) {
                    var n;
                    (n = a.j) == null || n.sB(function() {
                        return g.J(function(p) {
                            if (p.j == 1) return g.F(p, ipb(a, c, e), 2);
                            m();
                            g.va(p)
                        })
                    })
                }))
            })
        },
        ipb = function(a, b, c) {
            c = c === void 0 ? !0 : c;
            var d, e, f, h, l, m, n, p;
            return g.J(function(q) {
                switch (q.j) {
                    case 1:
                        if (!a.j) return q.return();
                        d = [];
                        e = g.WX(a.j.B, c);
                        f = [];
                        for (h = {
                                ZA: 0
                            }; h.ZA < e.length; h = {
                                ZA: h.ZA
                            }, h.ZA++) l = e[h.ZA], m = a.j.Ax(l, "json3"), n = g.Cr(m, {
                            withCredentials: !0,
                            format: "RAW"
                        }, 3, 500).then(function(r) {
                            return function(t) {
                                t = {
                                    metadata: g.JP(e[r.ZA]),
                                    trackData: t.xhr.responseText
                                };
                                f.push(t)
                            }
                        }(h)).bl(function(r) {
                            g6("Caption fetch error", r)
                        }), d.push(n);
                        return g.F(q, Kkb(d), 2);
                    case 2:
                        return g.wa(q, 3), g.F(q, Ymb(b, f), 5);
                    case 5:
                        g.xa(q, 0);
                        break;
                    case 3:
                        p = g.ya(q), g6("Caption DB transaction error", p), g.va(q)
                }
            })
        },
        kpb = function(a) {
            var b;
            return g.J(function(c) {
                if (c.j == 1) return g.F(c, Zmb(a), 2);
                b = c.B;
                return c.return(!!b && b.length > 0)
            })
        },
        R6 = function(a) {
            g.O.call(this);
            this.j = a;
            this.B = Lmb(this.j, this.C.bind(this))
        },
        lpb = function(a, b) {
            var c, d, e, f, h, l, m;
            return g.J(function(n) {
                switch (n.j) {
                    case 1:
                        if (b.length === 0) return n.return([]);
                        c = b.map(function(p) {
                            return g.GK(p, "transfer")
                        });
                        return g.F(n, b6(a.j, "transfer", c), 2);
                    case 2:
                        d = n.B;
                        e = d.filter(Umb).map(function(p) {
                            return g.FK(p.key).entityId
                        });
                        f = b.filter(function(p) {
                            return e.indexOf(p) === -1
                        });
                        if (f.length === 0) return n.return([]);
                        h = g.w(f);
                        l = h.next();
                    case 3:
                        if (l.done) {
                            n.Fa(5);
                            break
                        }
                        m = l.value;
                        return g.F(n, Bob(m), 4);
                    case 4:
                        l = h.next();
                        n.Fa(3);
                        break;
                    case 5:
                        return n.return(f)
                }
            })
        },
        opb = function(a, b, c, d, e, f) {
            var h, l, m;
            return g.J(function(n) {
                h = "STREAM_TYPE_UNKNOWN";
                c.video && c.audio ? (h = "STREAM_TYPE_AUDIO_AND_VIDEO", g6("unexpected stream type")) : c.video && !c.audio ? h = "STREAM_TYPE_VIDEO" : !c.video && c.audio && (h = "STREAM_TYPE_AUDIO");
                l = g.GK(b, "offlineVideoStreams");
                m = {
                    numBytesDownloaded: e.toFixed(),
                    numTotalBytes: f.toFixed(),
                    streamType: h,
                    streamState: "DOWNLOAD_STREAM_STATE_IN_PROGRESS",
                    formatStreamBytes: JSON.stringify(d),
                    itag: h === "STREAM_TYPE_AUDIO_AND_VIDEO" ? Number(c.itag) : void 0
                };
                return g.F(n, Z5(a, {
                        mode: "readwrite",
                        Pb: !0
                    },
                    function(p) {
                        var q = S5(p, l, "offlineVideoStreams"),
                            r = S5(p, g.GK(b, "transfer"), "transfer");
                        return g.zt.all([q, r]).then(function(t) {
                            t = g.w(t);
                            var u = t.next().value;
                            t = t.next().value;
                            if (!t) return W5(p, l).then(function() {});
                            var y = mpb(u);
                            u = npb(u, d, m, l);
                            var B = V5(p, u, "offlineVideoStreams");
                            mpb(u) > y && (t.lastProgressTimeMs = Date.now().toString());
                            y = [B];
                            t.offlineVideoStreams || (t.offlineVideoStreams = []);
                            t.offlineVideoStreams.indexOf(l) === -1 && (t.offlineVideoStreams.push(l), y.push(V5(p, t, "transfer")));
                            return g.zt.all(y)
                        })
                    }), 0)
            })
        },
        ppb = function(a, b) {
            var c, d, e, f, h;
            return g.J(function(l) {
                if (l.j == 1) return c = g.GK(b, "offlineVideoStreams"), g.F(l, a6(a, c, "offlineVideoStreams"), 2);
                d = l.B;
                if (!d || !d.streamsProgress) return l.return();
                e = g.w(d.streamsProgress);
                for (f = e.next(); !f.done; f = e.next()) h = f.value, h.streamState = "DOWNLOAD_STREAM_STATE_COMPLETE", h.numTotalBytes !== h.numBytesDownloaded && (h.numBytesDownloaded = h.numTotalBytes);
                return g.F(l, $5(a, d, "offlineVideoStreams"), 0)
            })
        },
        npb = function(a, b, c, d) {
            if (a && a.streamsProgress) {
                d = a;
                a: {
                    b = b.itag + ";" + b.xtags;
                    for (var e = a.streamsProgress, f = 0; f < e.length; f++) {
                        var h = JSON.parse(e[f].formatStreamBytes);
                        if (h.itag + ";" + h.xtags === b) {
                            e[f] = c;
                            c = e;
                            break a
                        }
                    }
                    e.push(c);c = e
                }
                d.streamsProgress = c
            } else a = {
                key: d,
                streamsProgress: [c]
            };
            return a
        },
        mpb = function(a) {
            if (a == null ? 0 : a.streamsProgress) {
                var b = 0;
                a = a.streamsProgress;
                for (var c = 0; c < a.length; c++) {
                    var d = a[c];
                    isNaN(Number(d.numBytesDownloaded)) ? g6("stream progress bytes number invalid") : b += Number(d.numBytesDownloaded)
                }
                return b
            }
            return 0
        },
        qpb = function(a, b, c, d) {
            g.O.call(this);
            var e = this;
            this.B = a;
            this.api = b;
            this.Ua = c;
            this.qa = d;
            this.K = new g.Yu;
            this.D = new g.Zo(function() {
                e.j && e.j.transferState === "TRANSFER_STATE_TRANSFERRING" && e.K.ph() && ((e.j.transferRetryCount || 0) < 3 ? P6(e.N, e.G, !1, !1) : O6(e.N, e.G.videoDetails.videoId), e.Jy("TRANSFER_FAILURE_REASON_TIMEOUT_NO_PROGRESS"))
            });
            this.oa = this.Ga = 0;
            this.Va = g.nC(this.api.U().experiments, "html5_transfer_processing_logs_interval");
            this.Z = !1;
            this.Qa = new g.DE(this);
            this.Y = !1;
            this.bd = {
                Joa: function() {
                    return e.D
                },
                soa: function() {
                    return e.qa
                },
                XY: function() {
                    return e.K
                }
            };
            this.Ba = Lmb(this.B, this.u5.bind(this));
            this.N = new Aob(b, this);
            this.Xa = new hpb;
            this.Da = new R6(this.B);
            this.Ma = this.K.listen("publicytnetworkstatus-online", this.KH.bind(this));
            this.Ka = this.K.listen("publicytnetworkstatus-offline", this.rda.bind(this));
            this.Y = this.api.U().L("html5_less_transfer_processing_logs");
            g.P(this, this.Qa);
            this.Qa.T(b, "offlinetransferpause", this.sda);
            g.qP(this.api.U()) ? this.C = "mainVideoDownloadStateEntity" : g.Ly(this.api.U()) && (this.C = "musicTrackDownloadMetadataEntity")
        },
        rpb = function(a) {
            return g.J(function(b) {
                if (b.j ==
                    1) b = g.F(b, Xmb(), 2);
                else {
                    var c = a.Da;
                    var d = g.WP();
                    d = Object.keys(d);
                    c = lpb(c, d);
                    b = g.F(b, c, 0)
                }
                return b
            })
        },
        T6 = function(a, b) {
            b = b === void 0 ? !1 : b;
            var c;
            return g.J(function(d) {
                if (d.j == 1) {
                    if (a.j) throw Error("Already downloading a video");
                    a.oa = 0;
                    a.Z = !1;
                    return g.F(d, spb(a), 2)
                }
                return d.j != 4 ? (c = d.B, vnb(a.Ua, !c), c && a.K.ph() ? b ? g.F(d, new Promise(function(e) {
                    g.or(e, 1E3)
                }), 4) : d.Fa(4) : (!c && a.j && S6(a), d.Fa(0))) : g.F(d, tpb(a, c), 0)
            })
        },
        upb = function(a) {
            return g.J(function(b) {
                if (b.j == 1) return a.G ? g.F(b, O6(a.N, a.G.videoDetails.videoId), 3) : b.Fa(0);
                S6(a);
                g.va(b)
            })
        },
        vpb = function(a, b) {
            var c, d, e;
            return g.J(function(f) {
                switch (f.j) {
                    case 1:
                        return g.wa(f, 2), (c = !!b.captionTracks.length || !!b.ze) ? g.F(f, kpb(b.videoId), 4) : f.return();
                    case 4:
                        return (d = f.B) ? f.return() : g.F(f, jpb(a.Xa, b), 5);
                    case 5:
                        g.xa(f, 0);
                        break;
                    case 2:
                        e = g.ya(f), g6("Caption downloading error", e, b.cotn), g.va(f)
                }
            })
        },
        tpb = function(a, b) {
            var c, d, e, f, h, l;
            return g.J(function(m) {
                switch (m.j) {
                    case 1:
                        if (a.Z) return m.return();
                        a.Z = !0;
                        a.j = b;
                        c = g.FK(a.j.key);
                        d = c.entityId;
                        e = void 0;
                        if (a.j.transferState === "TRANSFER_STATE_TRANSFERRING") return g.F(m, U6(a, d), 7);
                        if (a.j.transferState !== "TRANSFER_STATE_TRANSFER_IN_QUEUE" || a.j.transferRetryCount || a.j.hasLoggedFirstStarted) {
                            m.Fa(3);
                            break
                        }
                        return g.F(m, U6(a, d), 5);
                    case 5:
                        return e = m.B, a.j.hasLoggedFirstStarted = !0, g.F(m, wpb(a), 6);
                    case 6:
                        wnb({
                            videoId: d,
                            lm: a.j,
                            offlineModeType: e
                        }, void 0, void 0, !0);
                        m.Fa(3);
                        break;
                    case 7:
                        e = m.B,
                            l6({
                                transferStatusType: "TRANSFER_STATUS_TYPE_RESUME_PROCESSING",
                                statusType: "OFFLINING_RETRIED"
                            }, {
                                videoId: d,
                                lm: a.j,
                                offlineModeType: e
                            });
                    case 3:
                        return g.F(m, xpb(a), 8);
                    case 8:
                        return f = null, g.wa(m, 9), g.F(m, ypb(a, b), 11);
                    case 11:
                        f = m.B;
                        a.G = f;
                        g.xa(m, 10);
                        break;
                    case 9:
                        return h = g.ya(m), g6("error getting player response", h, b.cotn), g.F(m, a.Jy("TRANSFER_FAILURE_REASON_SERVER_PROPERTY_MISSING"), 12);
                    case 12:
                        return m.return();
                    case 10:
                        return l = Cnb(a.api.U(), b.cotn, f), g.F(m, vpb(a, l), 13);
                    case 13:
                        return g.F(m, Cob(l.videoId),
                            14);
                    case 14:
                        l.Wv = m.B, Gob(a.N, l, b.maximumDownloadQuality), a.D.start(108E5), g.va(m)
                }
            })
        },
        spb = function(a) {
            var b, c;
            return g.J(function(d) {
                if (d.j == 1) return g.F(d, b6(a.B, "transfer"), 2);
                b = d.B;
                c = b.filter(zpb).sort(Apb);
                return c.length === 0 ? d.return() : d.return(c[0])
            })
        },
        xpb = function(a) {
            var b, c, d;
            return g.J(function(e) {
                if (e.j == 1) {
                    if (!a.j) return V6(a, "onTransferStart"), e.return();
                    a.D.start(108E5);
                    return g.F(e, W6(a, "TRANSFER_STATE_TRANSFERRING"), 2)
                }
                b = a.j;
                return (d = ((c = b) == null ? 0 : c.key) ? g.FK(b.key).entityId : "") && a.C ? g.F(e, q6(d, a.C, a.B, "DOWNLOAD_STATE_DOWNLOAD_IN_PROGRESS"), 0) : e.Fa(0)
            })
        },
        Eob = function(a) {
            var b, c, d, e;
            g.J(function(f) {
                switch (f.j) {
                    case 1:
                        if (!a.j) {
                            V6(a, "onTransferPausedByUser");
                            f.Fa(2);
                            break
                        }
                        b = a.j;
                        a.D.stop();
                        return g.F(f, W6(a, "TRANSFER_STATE_PAUSED_BY_USER"), 3);
                    case 3:
                        d = ((c = b) == null ? 0 : c.key) ? g.FK(b.key).entityId : "";
                        if (!d || !a.C) {
                            f.Fa(4);
                            break
                        }
                        return g.F(f, q6(d, a.C, a.B, "DOWNLOAD_STATE_PAUSED"), 4);
                    case 4:
                        return g.F(f, U6(a, d), 6);
                    case 6:
                        e = f.B, xnb({
                            videoId: d,
                            lm: b,
                            offlineModeType: e
                        });
                    case 2:
                        S6(a), T6(a), g.va(f)
                }
            })
        },
        Fob = function(a) {
            var b, c, d;
            g.J(function(e) {
                if (e.j == 1) {
                    if (!a.j) return V6(a, "onTransferPausedByNetwork"), e.return();
                    a.D.stop();
                    return g.F(e, W6(a, "TRANSFER_STATE_TRANSFER_IN_QUEUE"), 2)
                }
                if (e.j != 3) return b = a.j, (d = ((c = b) == null ? 0 : c.key) ? g.FK(b.key).entityId : "") && a.C ? g.F(e, q6(d, a.C, a.B, "DOWNLOAD_STATE_PAUSED"), 3) : e.Fa(3);
                S6(a);
                g.va(e)
            })
        },
        Bpb = function(a) {
            var b, c, d, e, f;
            g.J(function(h) {
                switch (h.j) {
                    case 1:
                        if (!a.j) return V6(a, "onTransferComplete"), h.return();
                        b = a.j;
                        a.D.stop();
                        if (!b || !a.G) {
                            h.Fa(2);
                            break
                        }
                        c = Cnb(a.api.U(), b.cotn, a.G);
                        return g.F(h, vpb(a, c), 2);
                    case 2:
                        return g.F(h, W6(a, "TRANSFER_STATE_COMPLETE", "DOWNLOAD_STREAM_STATE_COMPLETE"), 4);
                    case 4:
                        e = ((d = b) == null ? 0 : d.key) ? g.FK(b.key).entityId : "";
                        if (!e || !a.C) {
                            h.Fa(5);
                            break
                        }
                        return g.F(h, q6(e, a.C, a.B, "DOWNLOAD_STATE_COMPLETE"), 5);
                    case 5:
                        return g.F(h, ppb(a.B, e), 7);
                    case 7:
                        return g.F(h, U6(a, e), 8);
                    case 8:
                        f = h.B, l6({
                            transferStatusType: "TRANSFER_STATUS_TYPE_COMPLETED",
                            statusType: "SUCCESS"
                        }, {
                            videoId: e,
                            lm: b,
                            offlineModeType: f
                        }), S6(a), T6(a), g.va(h)
                }
            })
        },
        Cpb = function(a, b, c) {
            var d, e;
            g.J(function(f) {
                switch (f.j) {
                    case 1:
                        if (!a.j) return V6(a, "onTransferProgress: " + b), f.return();
                        if (a.j.transferState === "TRANSFER_STATE_TRANSFERRING") {
                            f.Fa(2);
                            break
                        }
                        return g.F(f, xpb(a), 2);
                    case 2:
                        d = Date.now();
                        if (!(d - a.Ga > 1E3)) {
                            f.Fa(4);
                            break
                        }
                        a.Ga = d;
                        return g.F(f, opb(a.B, c.videoId, c.B, c.WP, c.bytesDownloaded, c.j), 5);
                    case 5:
                        if (a.Y && !(a.Y && d - a.oa > a.Va)) {
                            f.Fa(4);
                            break
                        }
                        a.oa = d;
                        return g.F(f, U6(a, b), 7);
                    case 7:
                        e = f.B, wnb({
                            videoId: b,
                            lm: a.j,
                            offlineModeType: e
                        }, c.bytesDownloaded, c.j);
                    case 4:
                        a.D.start(108E5), g.va(f)
                }
            })
        },
        Dpb = function(a) {
            var b = (a.j.transferRetryCount || 0) < 3;
            b && (a = a.j, a.transferRetryCount = (a.transferRetryCount || 0) + 1);
            return b
        },
        Epb = function(a, b) {
            b = b === void 0 ? "TRANSFER_FAILURE_REASON_UNKNOWN" : b;
            var c, d, e, f;
            return g.J(function(h) {
                if (h.j == 1) return a.j || V6(a, "setTransferToFailed: " + b), c = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", b === "TRANSFER_FAILURE_REASON_NETWORK" ? c = "OFFLINE_OPERATION_FAILURE_REASON_NETWORK_REQUEST_FAILED" : b === "TRANSFER_FAILURE_REASON_FILESYSTEM_WRITE" && (c = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED"), g.F(h, W6(a, "TRANSFER_STATE_FAILED", "DOWNLOAD_STREAM_STATE_ERROR_STREAMS_MISSING", b), 2);
                if (h.j != 3) return i6(a.qa, {
                        entityKey: (d = a.j) == null ? void 0 : d.key,
                        failureReason: c
                    }),
                    e = a.j ? g.FK(a.j.key).entityId : "", g.F(h, U6(a, e), 3);
                f = h.B;
                var l = {
                        videoId: e,
                        lm: a.j,
                        offlineModeType: f
                    },
                    m = b,
                    n = {
                        transferStatusType: "TRANSFER_STATUS_TYPE_TERMINATED_WITH_FAILURE",
                        statusType: "FAILED"
                    };
                m && (n.transferFailureReason = m, n.failureReason = ynb(m));
                l6(n, l);
                g.va(h)
            })
        },
        W6 = function(a, b, c, d) {
            var e;
            return g.J(function(f) {
                if (f.j == 1) {
                    if (!a.j) return V6(a, "saveTransferState: " + b), f.return();
                    a.j.transferState = b;
                    a.j.failureReason = d;
                    g.wa(f, 2);
                    return g.F(f, wpb(a, function(h) {
                            return c ? T5(h, "offlineVideoStreams", a.j.offlineVideoStreams).then(function(l) {
                                for (var m = g.w(l), n = m.next(); !n.done; n = m.next())
                                    if ((n = n.value) && n.streamsProgress) {
                                        n = g.w(n.streamsProgress);
                                        for (var p = n.next(); !p.done; p = n.next()) p.value.streamState = c
                                    }
                                return Cmb(h, l.filter(function(q) {
                                    return !!q
                                }), "offlineVideoStreams")
                            }) : g.zt.resolve(void 0)
                        }),
                        4)
                }
                if (f.j != 2) return g.xa(f, 0);
                e = g.ya(f);
                return e instanceof g.qt && e.type === "QUOTA_EXCEEDED" ? g.F(f, a.Jy("TRANSFER_FAILURE_REASON_FILESYSTEM_WRITE"), 0) : f.Fa(0)
            })
        },
        wpb = function(a, b) {
            var c;
            return g.J(function(d) {
                if (!a.j) return d.return();
                c = a.j;
                return g.F(d, Z5(a.B, {
                    mode: "readwrite",
                    Pb: !0
                }, function(e) {
                    var f = [V5(e, c, "transfer")];
                    b && f.push(b(e));
                    return g.zt.all(f)
                }), 0)
            })
        },
        S6 = function(a) {
            a.j = void 0;
            a.G = void 0;
            a.D.stop()
        },
        ypb = function(a, b) {
            var c, d, e, f, h;
            return g.J(function(l) {
                if (l.j == 1) return c = g.FK(b.key), d = c.entityId, e = g.GK(d, "playbackData"), g.F(l, a6(a.B, e, "playbackData"), 2);
                f = l.B;
                if ((h = f) == null ? 0 : h.playerResponseJson) return l.return(JSON.parse(f.playerResponseJson));
                throw Error("No PlayerResponse found");
            })
        },
        V6 = function(a, b) {
            a.api.ma("woffle", {
                mcte: b
            });
            g6("missing current transfer entity.")
        },
        U6 = function(a, b) {
            var c, d, e;
            return g.J(function(f) {
                if (f.j == 1) return g.F(f, a6(a.B, g.GK(b, "videoDownloadContextEntity"), "videoDownloadContextEntity"), 2);
                c = f.B;
                return f.return((e = (d = c) == null ? void 0 : d.offlineModeType) != null ? e : void 0)
            })
        },
        zpb = function(a) {
            return Fpb[a.transferState] !== void 0
        },
        Apb = function(a, b) {
            var c = Fpb[a.transferState],
                d = Fpb[b.transferState];
            return c !== d ? c - d : Number(a.enqueuedTimestampMs) - Number(b.enqueuedTimestampMs)
        },
        X6 = function(a, b) {
            var c = this;
            this.X = a;
            this.api = b;
            this.K = new g.Yu;
            this.G = new g.oj;
            this.bd = {
                UY: function() {
                    return c.C.bd.UY()
                },
                XY: function() {
                    return c.K
                },
                toa: function() {
                    return c.C
                },
                qR: function() {
                    return c.qR()
                },
                CU: function() {
                    return c.CU()
                },
                GU: function() {
                    return c.GU()
                },
                PT: function() {
                    return c.PT()
                },
                LT: function() {
                    return c.LT()
                },
                kN: function(d) {
                    return c.kN(d)
                }
            };
            this.C = new rnb(function() {
                return Gpb(c)
            }, function() {
                c.GU()
            }, this.api.dj(), this.api.L.bind(this.api));
            this.j = new h6(this.api);
            snb(this.C)
        },
        Gpb = function(a) {
            return g.J(function(b) {
                a.api.gb("onOrchestrationBecameLeader");
                return g.F(b, a.CU(), 0)
            })
        },
        Ipb = function(a) {
            var b, c;
            return g.J(function(d) {
                if (d.j == 1) return g.F(d, c6(), 2);
                if (d.j != 3) {
                    b = d.B;
                    if (!b) return g6("PES is undefined"), d.return();
                    a.B = new qpb(b, a.api, a.C, a.j);
                    c = a.DF(b);
                    return g.F(d, Xob(b, c, a.C, a.j, a.X), 3)
                }
                a.N = d.B;
                return g.F(d, Hpb(a), 0)
            })
        },
        Hpb = function(a) {
            var b;
            return g.J(function(c) {
                switch (c.j) {
                    case 1:
                        if (!a.B) return g6("transferManager is undefined"), c.return();
                        if (a.B.j) {
                            c.Fa(2);
                            break
                        }
                        return g.F(c, T6(a.B), 2);
                    case 2:
                        if (!a.X.L("woffle_enable_main_downloads_library")) {
                            c.Fa(4);
                            break
                        }
                        return g.F(c, a.Z_(), 4);
                    case 4:
                        if (!a.X.L("html5_offline_playback_position_sync")) {
                            c.Fa(6);
                            break
                        }
                        return g.F(c, a.AX(), 7);
                    case 7:
                        return g.F(c, a.kN(864E5), 6);
                    case 6:
                        return g.F(c, a.refreshAllStaleEntities(43200, !0), 9);
                    case 9:
                        return g.F(c, a.hP(), 10);
                    case 10:
                        if (!a.X.L("html5_retry_downloads_for_expiration")) {
                            c.Fa(11);
                            break
                        }
                        return g.F(c, a.LT(), 11);
                    case 11:
                        return a.Z = g.pr(function() {
                            a.refreshAllStaleEntities(43200, !0);
                            a.hP()
                        }, 9E5), a.X.L("html5_offline_playback_position_sync") && a.setUpPositionSyncInterval(), g.Zs(g.at(), function() {
                            return a.PT()
                        }), g.F(c, c6(), 13);
                    case 13:
                        return b = c.B, g.F(c, qnb(b), 14);
                    case 14:
                        tnb(a.C), g.va(c)
                }
            })
        },
        Jpb = function() {
            var a, b, c, d, e, f;
            return g.J(function(h) {
                switch (h.j) {
                    case 1:
                        return g.F(h, c6(), 2);
                    case 2:
                        a = h.B;
                        if (!a) return h.return([]);
                        b = Date.now() / 1E3;
                        return g.F(h, b6(a, "offlineVideoPolicy"), 3);
                    case 3:
                        c = h.B, d = g.w(c), e = d.next();
                    case 4:
                        if (e.done) {
                            h.Fa(6);
                            break
                        }
                        f = e.value;
                        if (!(f.expirationTimestamp && Number(f.expirationTimestamp) < b)) {
                            h.Fa(5);
                            break
                        }
                        f.action = "OFFLINE_VIDEO_POLICY_ACTION_DISABLE";
                        f.offlinePlaybackDisabledReason = "OFFLINE_PLAYBACK_DISABLED_REASON_CLIENT_OFFLINE_CONTENT_EXPIRED";
                        return g.F(h, $5(a, f, "offlineVideoPolicy"), 5);
                    case 5:
                        e = d.next();
                        h.Fa(4);
                        break;
                    case 6:
                        return h.return(c.map(function(l) {
                            return l.key
                        }))
                }
            })
        },
        Y6 = function(a, b, c, d, e) {
            var f, h, l;
            return g.J(function(m) {
                if (m.j == 1) return g.F(m, c6(), 2);
                f = m.B;
                if (!f) return m.return([]);
                h = b.map(function(n) {
                    var p = g.GK(n, c);
                    p = {
                        actionType: d,
                        entityKey: p,
                        actionMetadata: Object.assign({}, Dnb(), e)
                    };
                    d !== "OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH" && (p.actionMetadata.priority = 0);
                    n = new u6(c, n, p);
                    return w6(n)
                });
                l = Mmb(f, h);
                snb(a.C);
                return m.return(l)
            })
        },
        Kpb = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q;
            return g.J(function(r) {
                switch (r.j) {
                    case 1:
                        e = [], f = g.w(b), h = f.next();
                    case 2:
                        if (h.done) {
                            r.Fa(4);
                            break
                        }
                        l = h.value;
                        if (l.upToDate || c && !l.shouldAutoSyncMetadata || !l.playlistId) {
                            r.Fa(3);
                            break
                        }
                        m = {};
                        switch (d) {
                            case "mainPlaylistEntity":
                                n = {
                                    nextAutoRefreshIntervalSeconds: l.checkInSeconds,
                                    autoSync: c
                                };
                                m = {
                                    mainPlaylistEntityActionMetadata: n
                                };
                                break;
                            case "musicPlaylist":
                                p = {
                                    autoSync: c
                                }, m = {
                                    musicPlaylistEntityActionMetadata: p
                                }
                        }
                        return g.F(r, Y6(a, [l.playlistId], d, "OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH", m), 6);
                    case 6:
                        (q =
                            r.B) && e.push.apply(e, g.x(q));
                    case 3:
                        h = f.next();
                        r.Fa(2);
                        break;
                    case 4:
                        return r.return(e)
                }
            })
        },
        Lpb = function(a, b) {
            var c;
            return g.J(function(d) {
                return b.length ? (c = Dnb(), g.Nw(c, M6, {
                    isEnqueuedForExpiredStreamUrlRefetch: !0
                }), a.api.ma("qrd", {
                    v: b.length
                }), d.return(Y6(a, b, "playbackData", "OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", c))) : d.return([])
            })
        },
        Mpb = function(a, b, c) {
            this.j = a;
            this.X = b;
            this.C = c
        },
        Ppb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G;
            return g.J(function(H) {
                switch (H.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey), e = d.entityId, f = [], g.wa(H, 2), g.F(H, Npb(a, e), 4);
                    case 4:
                        f = H.B;
                        if (!(a.X.L("woffle_enable_main_downloads_library") && ((h = f) == null ? 0 : h.length))) {
                            H.Fa(5);
                            break
                        }
                        return g.F(H, Rnb(a.j, [b.entityKey]), 5);
                    case 5:
                        g.xa(H, 3);
                        break;
                    case 2:
                        return l = g.ya(H), m = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", n = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", l instanceof g.qt && l.type === "QUOTA_EXCEEDED" ? (m = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED",
                            n = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE") : g6("Playlist add error"), H.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, m, n));
                    case 3:
                        p = [];
                        if (!a.X.L("html5_offline_prevent_redownload_downloaded_video")) {
                            H.Fa(7);
                            break
                        }
                        return g.F(H, Bnb(a.j, "mainVideoEntity", f), 8);
                    case 8:
                        f = H.B;
                    case 7:
                        if ((q = f) == null ? 0 : q.length)
                            for (r = g.w(f), t = r.next(); !t.done; t = r.next())
                                if (u = t.value, y = u.offlineVideoData, B = void 0, (B = y) == null ? 0 : B.videoId) C = void 0, G = Number(((C = b.actionMetadata) == null ? void 0 : C.priority) ||
                                    0) + 1, p.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", y.videoId, "mainVideoEntity", G, Z6, Opb(b, y, e)));
                        return H.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, p))
                }
            })
        },
        Rpb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb, rb, Za, A, D, E, I, L, Y, ha, ca, K, la, qa, ia, Ka, ob, Mb, qc, Ta, Oc, he, Me, Qg, Ne, Th, Pc, Ei, Rg, Uf, Fi, Dj, Lk, ed, Ej, Fj, fd, Uh, dc, Ao, Oq;
            return g.J(function(rc) {
                switch (rc.j) {
                    case 1:
                        return c = m6(b), d = b.entityKey, e = g.FK(d).entityId, f = [], h = !1, e === "!*$_ALL_ENTITIES_!*$" ? (h = !0, g.F(rc, b6(a.j, "mainPlaylistEntity"), 5)) : g.F(rc, a6(a.j, d, "mainPlaylistEntity"), 4);
                    case 4:
                        (l = rc.B) && f.push(l);
                        rc.Fa(3);
                        break;
                    case 5:
                        f = rc.B;
                    case 3:
                        if ((m = f) == null || !m.length) return rc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        n = g.Q(b.actionMetadata, Qpb);
                        q = (p = n) == null ? void 0 : p.nextAutoRefreshIntervalSeconds;
                        t = (r = n) == null ? void 0 : r.autoSync;
                        u = [];
                        B = y = !0;
                        C = !1;
                        if (!h && t === !1) {
                            rc.Fa(6);
                            break
                        }
                        g.wa(rc, 7);
                        return g.F(rc, eob(0, !!t, !0, f), 9);
                    case 9:
                        u = rc.B;
                        g.xa(rc, 8);
                        break;
                    case 7:
                        G = g.ya(rc);
                        if (!(G instanceof Error && G.message === "No data")) {
                            G instanceof Error && G.message === "Empty response body" && g6(G.message);
                            rc.Fa(8);
                            break
                        }
                        return e === "!*$_ALL_ENTITIES_!*$" ? g.F(rc, Knb(a.j, b, a.C, "OFFLINE_DELETE_REASON_UNAVAILABLE"), 8) : g.F(rc, Inb(e, a.j, b, a.C), 8);
                    case 8:
                        if (!u.length || !h && u[0].playlistId !== e) return rc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c));
                    case 6:
                        if (h) {
                            H = [];
                            N = g.w(u);
                            for (M = N.next(); !M.done; M = N.next()) X = M.value, X.upToDate || t && !X.shouldAutoSyncMetadata || !X.playlistId || (W = {
                                nextAutoRefreshIntervalSeconds: X.checkInSeconds,
                                autoSync: t
                            }, H.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH", X.playlistId, "mainPlaylistEntity", 0, Z6, {
                                mainPlaylistEntityActionMetadata: W
                            })));
                            return rc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, H))
                        }
                        u.length && (fa = u[0], C = !!fa.upToDate, t && (y = (pa = fa.shouldAutoSyncMetadata) != null ? pa : !0, B = (ba = fa.shouldAutoSyncVideos) !=
                            null ? ba : !0, fa.checkInSeconds && (q = fa.checkInSeconds)));
                        if (C || !y) return rc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        R = [];
                        V = f[0];
                        if (!V.downloadState) {
                            v = void 0;
                            rc.Fa(15);
                            break
                        }
                        return g.F(rc, a6(a.j, V.downloadState, "mainPlaylistDownloadStateEntity"), 16);
                    case 16:
                        v = rc.B;
                    case 15:
                        return U = v, yb = ((bb = U) == null ? 0 : bb.addedTimestampMillis) ? String(U.addedTimestampMillis) : void 0, g.wa(rc, 17), g.F(rc, Npb(a, e, yb, q), 19);
                    case 19:
                        R = rc.B;
                        g.xa(rc, 18);
                        break;
                    case 17:
                        lb = g.ya(rc);
                        if (!(lb instanceof Error &&
                                lb.message === "No data for playlist")) {
                            if (lb instanceof Error && lb.message === "Empty response body for playlist") g6(lb.message);
                            else return Ea = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", cb = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", lb instanceof g.qt && lb.type === "QUOTA_EXCEEDED" && (Ea = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", cb = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), rc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, Ea, cb));
                            rc.Fa(18);
                            break
                        }
                        return g.F(rc, Inb(e, a.j, b, a.C), 18);
                    case 18:
                        if (!B) return rc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        rb = [];
                        Za = new Map;
                        if ((A = R) == null ? 0 : A.length)
                            for (D = g.w(R), E = D.next(); !E.done; E = D.next()) I = E.value, L = I.offlineVideoData, Y = void 0, ((Y = L) == null ? 0 : Y.videoId) && Za.set(L.videoId, L);
                        ha = new Map;
                        ca = [];
                        if ((K = V) == null ? 0 : (la = K.videos) == null ? 0 : la.length)
                            for (qa = g.w(V.videos), ia = qa.next(); !ia.done; ia = qa.next())
                                if (Ka = ia.value, ob = JSON.parse(g.FK(Ka).entityId), Mb = ob.videoId) Za.has(Mb) ? (ha.set(Mb,
                                    Za.get(Mb)), Za.delete(Mb)) : ca.push(Mb);
                        Ta = Number(((qc = b.actionMetadata) == null ? void 0 : qc.priority) || 0) + 1;
                        Oc = g.w(Za.entries());
                        for (he = Oc.next(); !he.done; he = Oc.next()) Me = he.value, Qg = g.w(Me), Ne = Qg.next().value, Th = Qg.next().value, Pc = Ne, Ei = Th, rb.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", Pc, "mainVideoEntity", Ta, Z6, Opb(b, Ei, e)));
                        Rg = g.w(ha.entries());
                        for (Uf = Rg.next(); !Uf.done; Uf = Rg.next()) Fi = Uf.value, Dj = g.w(Fi), Lk = Dj.next().value, ed = Dj.next().value, Ej = Lk, Fj = ed, rb.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH",
                            Ej, "mainVideoEntity", Ta, Z6, Opb(b, Fj, e)));
                        fd = g.w(ca);
                        for (Uh = fd.next(); !Uh.done; Uh = fd.next()) dc = Uh.value, Ao = {
                            playlistId: e
                        }, Oq = {
                            offlineLoggingData: {
                                offlineDeleteReason: "OFFLINE_DELETE_REASON_PARENT_LIST_REFRESH"
                            },
                            mainVideoEntityActionMetadata: Ao
                        }, rb.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE", dc, "mainVideoEntity", 0, Z6, Oq));
                        return rc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, rb))
                }
            })
        },
        Spb = function(a, b) {
            var c, d, e, f;
            return g.J(function(h) {
                switch (h.j) {
                    case 1:
                        return c = m6(b), g.wa(h, 2), d = g.FK(b.entityKey).entityId, d === "!*$_ALL_ENTITIES_!*$" ? g.F(h, Knb(a.j, b, a.C, (e = b.actionMetadata) == null ? void 0 : (f = e.offlineLoggingData) == null ? void 0 : f.offlineDeleteReason), 5) : g.F(h, Inb(d, a.j, b, a.C), 6);
                    case 6:
                        if (!a.X.L("woffle_enable_main_downloads_library")) {
                            h.Fa(5);
                            break
                        }
                        return g.F(h, Snb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(h, 3);
                        break;
                    case 2:
                        return g.ya(h), h.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED",
                            "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 3:
                        return h.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c))
                }
            })
        },
        Npb = function(a, b, c, d) {
            var e, f, h, l, m, n, p;
            return g.J(function(q) {
                switch (q.j) {
                    case 1:
                        return g.F(q, cob([b]), 2);
                    case 2:
                        return e = q.B, g.F(q, Tpb(a, e[0], c, d), 3);
                    case 3:
                        return f = q.B, h = f.mainPlaylistEntity, l = f.Ada, n = Gnb(h, (m = l) == null ? void 0 : m.avatar), g.wa(q, 4), g.F(q, y6(n), 6);
                    case 6:
                        g.xa(q, 5);
                        break;
                    case 4:
                        p = g.ya(q), p instanceof Error && p.message === "Failed to fetch" && g6(p.message);
                    case 5:
                        return q.return(e[0].videos)
                }
            })
        },
        Tpb = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N;
            return g.J(function(M) {
                switch (M.j) {
                    case 1:
                        e = Date.now().toString();
                        c || (c = e);
                        f = b.videos;
                        h = b.playlistId;
                        l = [];
                        m = [];
                        if (f)
                            for (n = g.w(f), p = n.next(); !p.done; p = n.next()) {
                                q = p.value;
                                r = q.offlineVideoData;
                                if (!r || !r.videoId) throw g6("Invalid offlineVideoData for playlist"), Error("Invalid offlineVideoData for playlist");
                                t = r.videoId;
                                u = {
                                    videoId: t,
                                    playlistId: h
                                };
                                y = {
                                    id: g.GK(JSON.stringify(u), "mainPlaylistVideoEntity"),
                                    video: g.GK(t, "mainVideoEntity")
                                };
                                l.push(y);
                                m.push(y.id)
                            }
                        C = {
                            key: g.GK(h, "mainPlaylistDownloadStateEntity"),
                            addedTimestampMillis: c,
                            lastSyncedTimestampMillis: e
                        };
                        G = {
                            key: g.GK(h, "mainPlaylistEntity"),
                            playlistId: h,
                            videos: m,
                            title: b.title,
                            thumbnailStyleData: Upb(b),
                            visibility: Vpb(b),
                            downloadState: C.key
                        };
                        b.channel && (H = b.channel.offlineChannelData, B = Wpb(g.GK(h, "ytMainChannelEntity"), H), G.channelOwner = B.id);
                        ((N = G) == null ? 0 : N.entityMetadata) ? (G.entityMetadata.offlineLastModifiedTimestampSeconds = b.lastModifiedTimestamp, d && (G.entityMetadata.nextAutoRefreshIntervalSeconds = String(d))) : G && (G.entityMetadata = {
                            nextAutoRefreshIntervalSeconds: d ?
                                String(d) : void 0,
                            offlineLastModifiedTimestampSeconds: b.lastModifiedTimestamp
                        });
                        g.wa(M, 2);
                        return g.F(M, Z5(a.j, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(X) {
                            var W = V5(X, G, "mainPlaylistEntity"),
                                fa = V5(X, C, "mainPlaylistDownloadStateEntity");
                            W = [W, fa];
                            fa = g.w(l);
                            for (var pa = fa.next(); !pa.done; pa = fa.next()) W.push(V5(X, pa.value, "mainPlaylistVideoEntity"));
                            B && W.push(V5(X, B, "ytMainChannelEntity"));
                            return g.zt.all(W)
                        }), 4);
                    case 4:
                        g.xa(M, 3);
                        break;
                    case 2:
                        throw g.ya(M), g6("PES failure for playlist"), Error("PES failure for playlist");
                    case 3:
                        return M.return({
                            mainPlaylistEntity: G,
                            Ada: B,
                            Fpa: l
                        })
                }
            })
        },
        Wpb = function(a, b) {
            return {
                id: a,
                channelId: b.channelId,
                title: b.title,
                avatar: b.thumbnail
            }
        },
        Upb = function(a) {
            var b = [],
                c = a.videos;
            c && c.length > 0 && b.push({
                key: Number("PLAYLIST_THUMBNAIL_STYLE_FIRST_VIDEO"),
                value: {
                    collageThumbnail: {
                        coverThumbnail: c[0].offlineVideoData.thumbnail
                    }
                }
            });
            if ((a = a.additionalMetadadatas) && a.length > 0)
                for (a = g.w(a), c = a.next(); !c.done; c = a.next()) {
                    var d = c.value.offlineBundleItemPlaylistData,
                        e = void 0;
                    c = (e = d) == null ? void 0 : e.style;
                    e = void 0;
                    d = {
                        collageThumbnail: {
                            coverThumbnail: (e = d) == null ? void 0 : e.coverThumbnail
                        }
                    };
                    switch (c) {
                        case "BUNDLE_ITEM_STYLE_UNSPECIFIED":
                            b.push({
                                key: Number("PLAYLIST_THUMBNAIL_STYLE_UNKNOWN"),
                                value: d
                            });
                            break;
                        case "BUNDLE_ITEM_STYLE_TWO_BY_TWO":
                            b.push({
                                key: Number("PLAYLIST_THUMBNAIL_STYLE_TWO_BY_TWO"),
                                value: d
                            });
                            break;
                        case "BUNDLE_ITEM_STYLE_ONE_AND_TWO_AVATAR":
                            b.push({
                                key: Number("PLAYLIST_THUMBNAIL_STYLE_ONE_AND_TWO_AVATAR"),
                                value: d
                            });
                            break;
                        case "BUNDLE_ITEM_STYLE_ONE_AND_TWO":
                            b.push({
                                key: Number("PLAYLIST_THUMBNAIL_STYLE_ONE_AND_TWO"),
                                value: d
                            })
                    }
                }
            return b
        },
        Vpb = function(a) {
            switch (a.privacy) {
                case "PRIVATE":
                    return "PLAYLIST_VISIBILITY_PRIVATE";
                case "PUBLIC":
                    return "PLAYLIST_VISIBILITY_PUBLIC";
                case "UNLISTED":
                    return "PLAYLIST_VISIBILITY_UNLISTED";
                default:
                    return "PLAYLIST_VISIBILITY_UNKNOWN"
            }
        },
        Opb = function(a, b, c) {
            b = {
                offlineVideoData: b,
                playlistId: c
            };
            if (a = g.Q(a.actionMetadata, Qpb)) b.maximumDownloadQuality = a.maximumDownloadQuality;
            return {
                mainVideoEntityActionMetadata: b
            }
        },
        Xpb = function(a, b, c) {
            this.j = a;
            this.X = b;
            this.C = c
        },
        $pb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u;
            return g.J(function(y) {
                switch (y.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey), e = d.entityId, f = g.Q(b.actionMetadata, $6), l = !((h = f) == null ? 0 : h.playlistId), g.wa(y, 2), g.F(y, Ypb(a, e, void 0, (m = f) == null ? void 0 : m.offlineVideoData, l), 4);
                    case 4:
                        g.xa(y, 3);
                        break;
                    case 2:
                        return n = g.ya(y), p = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", q = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", n instanceof g.qt && n.type === "QUOTA_EXCEEDED" && (p = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", q = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"),
                            y.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, p, q));
                    case 3:
                        r = 1;
                        r = Number(((t = b.actionMetadata) == null ? void 0 : t.priority) || 0) + 1;
                        var B = (B = g.Q(b.actionMetadata, $6)) ? {
                            playbackDataActionMetadata: {
                                maximumDownloadQuality: B.maximumDownloadQuality
                            }
                        } : void 0;
                        u = K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", e, "playbackData", r, Zpb, B);
                        return y.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, [u]))
                }
            })
        },
        aqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G;
            return g.J(function(H) {
                switch (H.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey), e = d.entityId, g.F(H, a6(a.j, b.entityKey, "mainVideoEntity"), 2);
                    case 2:
                        f = H.B;
                        if (!f) {
                            h = void 0;
                            H.Fa(3);
                            break
                        }
                        return g.F(H, a6(a.j, f.downloadState, "mainVideoDownloadStateEntity"), 4);
                    case 4:
                        h = H.B;
                    case 3:
                        l = h;
                        if (!f || !l) return H.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        g.wa(H, 5);
                        return g.F(H, Ypb(a, e, l.addedTimestampMillis, (n = g.Q(b.actionMetadata, $6)) == null ? void 0 : n.offlineVideoData), 7);
                    case 7:
                        p = 1;
                        p = Number(((q =
                            b.actionMetadata) == null ? void 0 : q.priority) || 0) + 1;
                        m = K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH", e, "playbackData", p, Zpb);
                        g.xa(H, 6);
                        break;
                    case 5:
                        r = g.ya(H);
                        if (!(r instanceof Error && r.message === "No data")) {
                            if (r instanceof Error && r.message === "Empty response body") g6(r.message);
                            else return t = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", u = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", r instanceof g.qt && r.type === "QUOTA_EXCEEDED" && (t = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED",
                                u = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), H.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, t, u));
                            H.Fa(6);
                            break
                        }
                        return g.F(H, C6(a.j, e), 9);
                    case 9:
                        y = H.B;
                        B = g.Q(b.actionMetadata, $6);
                        if (G = (C = B) == null ? void 0 : C.playlistId) y.playlistId = G;
                        y.offlineDeleteReason = "OFFLINE_DELETE_REASON_UNAVAILABLE";
                        return g.F(H, z6(e, a.j, b, a.C, y), 6);
                    case 6:
                        return H.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, m ? [m] : void 0))
                }
            })
        },
        bqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q;
            return g.J(function(r) {
                switch (r.j) {
                    case 1:
                        return c = m6(b), g.wa(r, 2), d = g.FK(b.entityKey).entityId, d === "!*$_ALL_ENTITIES_!*$" ? g.F(r, Knb(a.j, b, a.C, (p = b.actionMetadata) == null ? void 0 : (q = p.offlineLoggingData) == null ? void 0 : q.offlineDeleteReason), 5) : g.F(r, C6(a.j, d), 6);
                    case 6:
                        e = r.B;
                        f = g.Q(b.actionMetadata, $6);
                        if (l = (h = f) == null ? void 0 : h.playlistId) e.playlistId = l;
                        e.offlineDeleteReason = (m = b.actionMetadata) == null ? void 0 : (n = m.offlineLoggingData) == null ? void 0 : n.offlineDeleteReason;
                        return g.F(r, z6(d, a.j, b, a.C, e), 7);
                    case 7:
                        if (!a.X.L("woffle_enable_main_downloads_library")) {
                            r.Fa(5);
                            break
                        }
                        return g.F(r, Snb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(r, 3);
                        break;
                    case 2:
                        return g.ya(r), r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 3:
                        return r.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c))
                }
            })
        },
        Ypb = function(a, b, c, d, e) {
            var f, h, l, m, n, p;
            return g.J(function(q) {
                switch (q.j) {
                    case 1:
                        if (f = d) {
                            q.Fa(2);
                            break
                        }
                        return g.F(q, bob([b]), 3);
                    case 3:
                        h = q.B, f = h[0];
                    case 2:
                        return g.F(q, cqb(a, f, c, e), 4);
                    case 4:
                        l = q.B;
                        m = l.mainVideoEntity;
                        n = l.channelEntity;
                        g.wa(q, 5);
                        var r = t6(m.thumbnail),
                            t = t6(n.avatar);
                        return g.F(q, y6(r.concat(t)), 7);
                    case 7:
                        g.xa(q, 0);
                        break;
                    case 5:
                        p = g.ya(q), p instanceof Error && p.message === "Failed to fetch" && g6(p.message), g.va(q)
                }
            })
        },
        cqb = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q, r, t, u, y, B;
            return g.J(function(C) {
                switch (C.j) {
                    case 1:
                        c || (c = Date.now().toString());
                        f = (e = b.channel) == null ? void 0 : e.offlineChannelData;
                        h = {
                            id: g.GK(b.videoId, "ytMainChannelEntity"),
                            channelId: f.channelId,
                            title: f.title,
                            avatar: f.thumbnail
                        };
                        l = {
                            key: g.GK(b.videoId, "mainVideoDownloadStateEntity"),
                            playbackData: g.GK(b.videoId, "playbackData"),
                            addedTimestampMillis: c,
                            videoDownloadContextEntity: g.GK(b.videoId, "videoDownloadContextEntity")
                        };
                        m = {
                            key: g.GK(b.videoId, "videoPlaybackPositionEntity"),
                            videoId: b.videoId,
                            lastPlaybackPositionSeconds: "0"
                        };
                        a.X.L("html5_offline_playback_position_sync") && (n = {
                            playbackPosition: m.key
                        });
                        p = g.GK(b.videoId, "mainVideoEntity");
                        q = {
                            key: p,
                            videoId: b.videoId,
                            title: b.title,
                            thumbnail: b.thumbnail,
                            localizedStrings: {
                                viewCount: b.shortViewCountText
                            },
                            userState: n,
                            lengthSeconds: b.lengthSeconds ? Number(b.lengthSeconds) : void 0,
                            publishedTimestampMillis: b.publishedTimestamp ? (Number(b.publishedTimestamp) * 1E3).toString() : void 0,
                            formattedDescription: b.description,
                            owner: h.id,
                            downloadState: l.key
                        };
                        if (!a.X.L("woffle_enable_main_downloads_library") ||
                            !d) {
                            C.Fa(2);
                            break
                        }
                        return g.F(C, Qnb(a.j, [p]), 3);
                    case 3:
                        if (u = C.B) r = u.mainDownloadsLibraryEntity, t = u.mainDownloadsListEntity;
                    case 2:
                        return B = Anb, y = {
                            key: g.GK(b.videoId, "downloadStatusEntity"),
                            downloadState: "DOWNLOAD_STATE_PENDING_DOWNLOAD"
                        }, g.Nw(l, B, y), g.F(C, Z5(a.j, {
                            mode: "readwrite",
                            Pb: !0
                        }, function(G) {
                            var H = V5(G, h, "ytMainChannelEntity"),
                                N = V5(G, l, "mainVideoDownloadStateEntity"),
                                M = V5(G, q, "mainVideoEntity");
                            H = [H, N, M];
                            a.X.L("html5_offline_playback_position_sync") && (N = V5(G, m, "videoPlaybackPositionEntity"),
                                H.push(N));
                            r && (N = V5(G, r, "mainDownloadsLibraryEntity"), H.push(N));
                            t && (N = V5(G, t, "mainDownloadsListEntity"), H.push(N));
                            y && (G = V5(G, y, "downloadStatusEntity"), H.push(G));
                            return g.zt.all(H)
                        }), 4);
                    case 4:
                        return C.return({
                            mainVideoEntity: q,
                            channelEntity: h
                        })
                }
            })
        },
        dqb = function(a, b, c) {
            this.j = a;
            this.X = b;
            this.C = c
        },
        fqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V;
            return g.J(function(v) {
                switch (v.j) {
                    case 1:
                        return c = m6(b), d = [], g.F(v, O5.getInstance(), 2);
                    case 2:
                        e = v.B;
                        if (!e) {
                            v.Fa(3);
                            break
                        }
                        return g.F(v, e.get("sdois"), 4);
                    case 4:
                        return f = v.B, g.F(v, (l = e) == null ? void 0 : l.get("lmqf"), 5);
                    case 5:
                        h = v.B;
                    case 3:
                        g.wa(v, 6);
                        if (f === void 0) throw Error("prefStorage or opt-in state is undefined");
                        m = [];
                        if (f) {
                            v.Fa(8);
                            break
                        }
                        return g.F(v, Pnb(a.j), 9);
                    case 9:
                        m = v.B, m.reverse();
                    case 8:
                        if (!m.length) {
                            v.Fa(10);
                            break
                        }
                        n = g.w(m);
                        p = n.next();
                    case 11:
                        if (p.done) {
                            v.Fa(10);
                            break
                        }
                        q = p.value;
                        if (!q) {
                            v.Fa(12);
                            break
                        }
                        r = g.FK(q).entityId;
                        return g.F(v, C6(a.j, r), 14);
                    case 14:
                        return t = v.B, t.offlineDeleteReason = "OFFLINE_DELETE_REASON_PARENT_LIST_DELETE", g.F(v, z6(r, a.j, {
                            entityKey: q,
                            actionType: b.actionType
                        }, a.C, t), 12);
                    case 12:
                        p = n.next();
                        v.Fa(11);
                        break;
                    case 10:
                        return g.F(v, gob(f, (u = h) != null ? u : "SD"), 16);
                    case 16:
                        return y = v.B, g.F(v, Lnb(y), 17);
                    case 17:
                        B = Onb(y);
                        if (!a.X.L("woffle_enable_main_downloads_library")) {
                            v.Fa(18);
                            break
                        }
                        if (f) {
                            v.Fa(19);
                            break
                        }
                        return g.F(v, Snb(a.j, B6), 19);
                    case 19:
                        return g.F(v, Rnb(a.j, [B6]), 18);
                    case 18:
                        if ((C =
                                B) == null ? 0 : C.length)
                            for (G = g.w(B), H = G.next(); !H.done; H = G.next())
                                if (M = N = H.value, X = M.actionType, W = M.entityKey, fa = M.actionMetadata, X && W && fa && !g.Q(fa, eqb)) {
                                    X === "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE" && (fa.offlineLoggingData = {
                                        offlineDeleteReason: "OFFLINE_DELETE_REASON_PARENT_LIST_DELETE"
                                    });
                                    if (pa = g.Q(N.actionMetadata, $6)) pa.playlistId = "DOWNLOADS_LIST_ENTITY_ID_SMART_DOWNLOADS", N.actionMetadata = Object.assign({}, N.actionMetadata, {
                                        mainVideoEntityActionMetadata: pa
                                    });
                                    d.push(N)
                                }
                        g.xa(v, 7);
                        break;
                    case 6:
                        return ba =
                            g.ya(v), R = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", V = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", ba instanceof g.qt && ba.type === "QUOTA_EXCEEDED" && (R = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", V = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), v.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, R, V));
                    case 7:
                        return v.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, d))
                }
            })
        },
        gqb = function() {
            X6.apply(this, arguments);
            this.Y = "mainVideoEntity"
        },
        hqb = function(a, b, c) {
            b = b === void 0 ? 43200 : b;
            c = c === void 0 ? !0 : c;
            var d = d === void 0 ? !1 : d;
            var e, f, h;
            return g.J(function(l) {
                switch (l.j) {
                    case 1:
                        if (!a.K.ph()) return l.return([]);
                        e = [];
                        g.wa(l, 2);
                        return g.F(l, eob(b, c, d), 4);
                    case 4:
                        e = l.B;
                        g.xa(l, 3);
                        break;
                    case 2:
                        f = g.ya(l), f instanceof Error && f.message === "No data" || f instanceof Error && f.message === "Empty response body" && g6(f.message);
                    case 3:
                        return h = Kpb(a, e, c, "mainPlaylistEntity"), l.return(h)
                }
            })
        },
        iqb = function(a, b, c, d) {
            d = d === void 0 ? !1 : d;
            var e, f, h, l, m, n, p, q, r, t, u, y, B, C, G;
            return g.J(function(H) {
                switch (H.j) {
                    case 1:
                        return e = [], g.F(H, fob(), 2);
                    case 2:
                        return (f = H.B) || d ? g.F(H, hob(b, c), 3) : H.return([]);
                    case 3:
                        h = H.B;
                        if ((l = h) == null || !l.length) return H.return([]);
                        m = {
                            offlineDeleteReason: "OFFLINE_DELETE_REASON_PARENT_LIST_REFRESH"
                        };
                        n = g.w(h);
                        p = n.next();
                    case 4:
                        if (p.done) {
                            H.Fa(6);
                            break
                        }
                        r = q = p.value;
                        t = r.actionType;
                        u = r.entityKey;
                        y = r.actionMetadata;
                        if (!(t && u && y) || g.Q(y, eqb)) {
                            H.Fa(5);
                            break
                        }
                        t === "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE" && (y.offlineLoggingData =
                            m);
                        B = g.FK(u);
                        C = B.entityId;
                        return g.F(H, Y6(a, [C], "mainVideoEntity", t, y), 8);
                    case 8:
                        G = H.B, e = e.concat(G);
                    case 5:
                        p = n.next();
                        H.Fa(4);
                        break;
                    case 6:
                        return H.return(e)
                }
            })
        },
        jqb = function(a, b) {
            this.j = a;
            this.C = b
        },
        lqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C;
            return g.J(function(G) {
                switch (G.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey), e = d.entityId, f = [], g.wa(G, 2), g.F(G, kqb(a, e), 4);
                    case 4:
                        f = G.B;
                        if ((h = f) == null || !h.length) {
                            G.Fa(5);
                            break
                        }
                        return g.F(G, Xnb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(G, 3);
                        break;
                    case 2:
                        return l = g.ya(G), m = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", n = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", l instanceof g.qt && l.type === "QUOTA_EXCEEDED" && (m = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", n = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"),
                            G.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, m, n));
                    case 3:
                        return p = [], g.F(G, Bnb(a.j, "musicTrack", f), 7);
                    case 7:
                        f = G.B;
                        if (f.length)
                            for (q = g.w(f), r = q.next(); !r.done; r = q.next())
                                if (t = r.value, u = t.offlineVideoData, y = void 0, (y = u) == null ? 0 : y.videoId) B = void 0, C = Number(((B = b.actionMetadata) == null ? void 0 : B.priority) || 0) + 1, p.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", u.videoId, "musicTrack", C, a7, G6(b, u, e)));
                        return G.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, p))
                }
            })
        },
        mqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb, rb, Za, A, D, E, I, L, Y, ha, ca, K, la, qa, ia, Ka, ob, Mb, qc, Ta, Oc, he, Me, Qg, Ne, Th;
            return g.J(function(Pc) {
                switch (Pc.j) {
                    case 1:
                        return c = m6(b), d = b.entityKey, e = g.FK(d).entityId, f = [], h = !1, e === "!*$_ALL_ENTITIES_!*$" ? (h = !0, g.F(Pc, b6(a.j, "musicAlbumRelease"), 5)) : g.F(Pc, a6(a.j, d, "musicAlbumRelease"), 4);
                    case 4:
                        (l = Pc.B) && f.push(l);
                        Pc.Fa(3);
                        break;
                    case 5:
                        f = Pc.B;
                    case 3:
                        if ((m = f) == null || !m.length) return Pc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        if (h) {
                            n = [];
                            p = g.w(f);
                            for (q = p.next(); !q.done; q = p.next()) r = q.value, t = g.FK(r.id).entityId, n.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH",
                                t, "musicAlbumRelease", 0, a7));
                            return Pc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, n))
                        }
                        u = [];
                        y = f[0];
                        B = void 0;
                        if (!y.downloadMetadata) {
                            Pc.Fa(6);
                            break
                        }
                        return g.F(Pc, a6(a.j, y.downloadMetadata, "musicAlbumReleaseDownloadMetadataEntity"), 7);
                    case 7:
                        C = Pc.B, B = Number((H = (G = C) == null ? void 0 : G.addedTimestampMillis) != null ? H : "0") / 1E3;
                    case 6:
                        return g.wa(Pc, 8), g.F(Pc, kqb(a, e, (N = B) == null ? void 0 : N.toString()), 10);
                    case 10:
                        u = Pc.B;
                        g.xa(Pc, 9);
                        break;
                    case 8:
                        M = g.ya(Pc);
                        if (!(M instanceof Error && M.message ===
                                "No data")) {
                            if (M instanceof Error && M.message === "Empty response body") g6(M.message);
                            else return X = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", W = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", M instanceof g.qt && M.type === "QUOTA_EXCEEDED" && (X = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", W = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), Pc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, X, W));
                            Pc.Fa(9);
                            break
                        }
                        return g.F(Pc, E6(e, "musicAlbumRelease", a.j,
                            b, a.C), 9);
                    case 9:
                        fa = [];
                        pa = new Map;
                        if ((ba = u) == null ? 0 : ba.length)
                            for (R = g.w(u), V = R.next(); !V.done; V = R.next()) v = V.value, U = v.offlineVideoData, bb = void 0, ((bb = U) == null ? 0 : bb.videoId) && pa.set(U.videoId, U);
                        yb = new Map;
                        lb = [];
                        if ((Ea = y) == null ? 0 : (cb = Ea.tracks) == null ? 0 : cb.length)
                            for (rb = g.w(y.tracks), Za = rb.next(); !Za.done; Za = rb.next())
                                if (A = Za.value, D = g.FK(A).entityId) pa.has(D) ? (yb.set(D, pa.get(D)), pa.delete(D)) : lb.push(D);
                        I = Number(((E = b.actionMetadata) == null ? void 0 : E.priority) || 0) + 1;
                        L = g.w(pa.entries());
                        for (Y = L.next(); !Y.done; Y =
                            L.next()) ha = Y.value, ca = g.w(ha), K = ca.next().value, la = ca.next().value, qa = K, ia = la, fa.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", qa, "musicTrack", I, a7, G6(b, ia)));
                        Ka = g.w(yb.entries());
                        for (ob = Ka.next(); !ob.done; ob = Ka.next()) Mb = ob.value, qc = g.w(Mb), Ta = qc.next().value, Oc = qc.next().value, he = Ta, Me = Oc, fa.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH", he, "musicTrack", I, a7, G6(b, Me)));
                        Qg = g.w(lb);
                        for (Ne = Qg.next(); !Ne.done; Ne = Qg.next()) Th = Ne.value, fa.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE", Th,
                            "musicTrack", 0, a7));
                        return Pc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, fa))
                }
            })
        },
        nqb = function(a, b) {
            var c, d;
            return g.J(function(e) {
                switch (e.j) {
                    case 1:
                        return c = m6(b), g.wa(e, 2), d = g.FK(b.entityKey).entityId, d === "!*$_ALL_ENTITIES_!*$" ? g.F(e, F6(a.j, b, a.C), 5) : g.F(e, E6(d, "musicAlbumRelease", a.j, b, a.C), 6);
                    case 6:
                        return g.F(e, Ynb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(e, 3);
                        break;
                    case 2:
                        return g.ya(e), e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 3:
                        return e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c))
                }
            })
        },
        kqb = function(a, b, c) {
            var d, e, f;
            return g.J(function(h) {
                switch (h.j) {
                    case 1:
                        return g.F(h, cob([b]), 2);
                    case 2:
                        return d = h.B, g.F(h, oqb(a, d[0], c), 3);
                    case 3:
                        return e = h.B, f = t6(e.thumbnailDetails), g.F(h, y6(f), 4);
                    case 4:
                        return h.return(d[0].videos)
                }
            })
        },
        oqb = function(a, b, c) {
            var d, e, f, h, l, m, n, p, q, r, t, u, y, B;
            return g.J(function(C) {
                if (C.j == 1) {
                    d = b.additionalMetadadatas;
                    e = void 0;
                    if (d && d.length > 0)
                        for (f = g.w(d), h = f.next(); !h.done; h = f.next())
                            if (l = h.value, l.offlineMusicPlaylistData) {
                                e = l.offlineMusicPlaylistData;
                                break
                            }
                    m = b.playlistId;
                    n = Znb(b);
                    p = n.y3;
                    q = n.x3;
                    r = c ? (Number(c) * 1E3).toString() : Date.now().toString();
                    t = b.lastModifiedTimestamp ? (Number(b.lastModifiedTimestamp) * 1E3).toString() : "0";
                    u = {
                        id: g.GK(m, "musicAlbumReleaseDownloadMetadataEntity"),
                        trackDownloadMetadatas: q,
                        lastModifiedTimestampMillis: t,
                        addedTimestampMillis: r,
                        syncState: "DOWNLOAD_SYNC_STATE_UP_TO_DATE"
                    };
                    y = {
                        id: g.GK(m, "musicAlbumRelease"),
                        title: b.title,
                        audioPlaylistId: m,
                        trackCount: b.totalVideoCount,
                        tracks: p,
                        downloadMetadata: u.id
                    };
                    e && (y.thumbnailDetails = (B = e.albumHqThumbnail) != null ? B : e.albumArtistThumbnail, y.artistDisplayName = e.albumArtistDisplayName, y.releaseDate = e.albumReleaseDate, y.contentRating = {
                        explicitType: e.albumReleaseExplicitType
                    }, y.releaseType = e.albumReleaseType);
                    return g.F(C, Z5(a.j, {
                        mode: "readwrite",
                        Pb: !0
                    }, function(G) {
                        var H = V5(G, y, "musicAlbumRelease");
                        G = V5(G, u, "musicAlbumReleaseDownloadMetadataEntity");
                        return g.zt.all([H, G])
                    }), 2)
                }
                return C.return(y)
            })
        },
        pqb = function(a, b) {
            this.j = a;
            this.C = b
        },
        rqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C;
            return g.J(function(G) {
                switch (G.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey), e = d.entityId, f = [], g.wa(G, 2), g.F(G, qqb(a, e), 4);
                    case 4:
                        f = G.B;
                        if ((h = f) == null || !h.length) {
                            G.Fa(5);
                            break
                        }
                        return g.F(G, Xnb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(G, 3);
                        break;
                    case 2:
                        return l = g.ya(G), m = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", n = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", l instanceof g.qt && l.type === "QUOTA_EXCEEDED" && (m = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", n = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"),
                            G.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, m, n));
                    case 3:
                        return p = [], g.F(G, Bnb(a.j, "musicTrack", f), 7);
                    case 7:
                        f = G.B;
                        if (f.length)
                            for (q = g.w(f), r = q.next(); !r.done; r = q.next())
                                if (t = r.value, u = t.offlineVideoData, y = void 0, (y = u) == null ? 0 : y.videoId) B = void 0, C = Number(((B = b.actionMetadata) == null ? void 0 : B.priority) || 0) + 1, p.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", u.videoId, "musicTrack", C, b7, G6(b, u, e)));
                        return G.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, p))
                }
            })
        },
        sqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb, rb, Za, A, D, E, I, L, Y, ha, ca, K, la, qa, ia, Ka, ob, Mb, qc, Ta, Oc, he, Me, Qg, Ne, Th, Pc, Ei, Rg, Uf, Fi, Dj, Lk, ed, Ej, Fj, fd, Uh;
            return g.J(function(dc) {
                switch (dc.j) {
                    case 1:
                        return c = m6(b), d = b.entityKey, e = g.FK(d).entityId, f = [], h = !1, e === "!*$_ALL_ENTITIES_!*$" ? (h = !0, g.F(dc, b6(a.j, "musicPlaylist"), 5)) : g.F(dc, a6(a.j, d, "musicPlaylist"), 4);
                    case 4:
                        (l = dc.B) && f.push(l);
                        dc.Fa(3);
                        break;
                    case 5:
                        f = dc.B;
                    case 3:
                        if ((m = f) == null || !m.length) return dc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        n = g.Q(b.actionMetadata, $nb);
                        q = (p = n) == null ? void 0 : p.autoSync;
                        r = [];
                        u = t = !0;
                        y = !1;
                        B = void 0;
                        if (!h && q === !1) {
                            dc.Fa(6);
                            break
                        }
                        g.wa(dc, 7);
                        return g.F(dc,
                            iob(0, !!q, !0, f), 9);
                    case 9:
                        r = dc.B;
                        g.xa(dc, 8);
                        break;
                    case 7:
                        C = g.ya(dc);
                        if (!(C instanceof Error && C.message === "No data")) {
                            C instanceof Error && C.message === "Empty response body" && g6(C.message);
                            dc.Fa(8);
                            break
                        }
                        return e === "!*$_ALL_ENTITIES_!*$" ? g.F(dc, F6(a.j, b, a.C), 8) : g.F(dc, E6(e, "musicPlaylist", a.j, b, a.C), 8);
                    case 8:
                        if (!r.length || !h && r[0].playlistId !== e) return dc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                    case 6:
                        if (h) {
                            G = [];
                            H = g.w(r);
                            for (N = H.next(); !N.done; N = H.next()) M = N.value, M.upToDate ||
                                q && !M.shouldAutoSyncMetadata || !M.playlistId || (X = {
                                    autoSync: q
                                }, G.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH", M.playlistId, "musicPlaylist", 0, b7, {
                                    musicPlaylistEntityActionMetadata: X
                                })));
                            return dc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, G))
                        }
                        r.length && (W = r[0], y = !!W.upToDate, q && (t = (fa = W.shouldAutoSyncMetadata) != null ? fa : !0, u = (pa = W.shouldAutoSyncVideos) != null ? pa : !0, W.checkInSeconds && (B = W.checkInSeconds)));
                        if (y || !t) return dc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c));
                        ba = [];
                        R = f[0];
                        V = void 0;
                        if (!R.downloadMetadata) {
                            dc.Fa(15);
                            break
                        }
                        return g.F(dc, a6(a.j, R.downloadMetadata, "musicPlaylistDownloadMetadataEntity"), 16);
                    case 16:
                        v = dc.B, V = Number((bb = (U = v) == null ? void 0 : U.addedTimestampMillis) != null ? bb : "0") / 1E3;
                    case 15:
                        return g.wa(dc, 17), g.F(dc, qqb(a, e, (yb = V) == null ? void 0 : yb.toString(), B), 19);
                    case 19:
                        ba = dc.B;
                        g.xa(dc, 18);
                        break;
                    case 17:
                        lb = g.ya(dc);
                        if (!(lb instanceof Error && lb.message === "No data")) {
                            if (lb instanceof Error && lb.message === "Empty response body") g6(lb.message);
                            else return Ea =
                                "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", cb = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", lb instanceof g.qt && lb.type === "QUOTA_EXCEEDED" && (Ea = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", cb = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), dc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, Ea, cb));
                            dc.Fa(18);
                            break
                        }
                        return g.F(dc, E6(e, "musicPlaylist", a.j, b, a.C), 18);
                    case 18:
                        if (!u) return dc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c));
                        rb = [];
                        Za = new Map;
                        if ((A = ba) == null ? 0 : A.length)
                            for (D = g.w(ba), E = D.next(); !E.done; E = D.next()) I = E.value, L = I.offlineVideoData, Y = void 0, ((Y = L) == null ? 0 : Y.videoId) && Za.set(L.videoId, L);
                        ha = new Map;
                        ca = [];
                        if ((K = R) == null ? 0 : (la = K.tracks) == null ? 0 : la.length)
                            for (qa = g.w(R.tracks), ia = qa.next(); !ia.done; ia = qa.next())
                                if (Ka = ia.value, ob = g.FK(Ka).entityId) Za.has(ob) ? (ha.set(ob, Za.get(ob)), Za.delete(ob)) : ca.push(ob);
                        qc = Number(((Mb = b.actionMetadata) == null ? void 0 : Mb.priority) || 0) + 1;
                        Ta = g.w(Za.entries());
                        for (Oc = Ta.next(); !Oc.done; Oc =
                            Ta.next()) he = Oc.value, Me = g.w(he), Qg = Me.next().value, Ne = Me.next().value, Th = Qg, Pc = Ne, rb.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", Th, "musicTrack", qc, b7, G6(b, Pc)));
                        Ei = g.w(ha.entries());
                        for (Rg = Ei.next(); !Rg.done; Rg = Ei.next()) Uf = Rg.value, Fi = g.w(Uf), Dj = Fi.next().value, Lk = Fi.next().value, ed = Dj, Ej = Lk, rb.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH", ed, "musicTrack", qc, b7, G6(b, Ej)));
                        Fj = g.w(ca);
                        for (fd = Fj.next(); !fd.done; fd = Fj.next()) Uh = fd.value, rb.push(K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE",
                            Uh, "musicTrack", 0, b7));
                        return dc.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, rb))
                }
            })
        },
        tqb = function(a, b) {
            var c, d;
            return g.J(function(e) {
                switch (e.j) {
                    case 1:
                        return c = m6(b), g.wa(e, 2), d = g.FK(b.entityKey).entityId, d === "!*$_ALL_ENTITIES_!*$" ? g.F(e, F6(a.j, b, a.C), 5) : g.F(e, E6(d, "musicPlaylist", a.j, b, a.C), 6);
                    case 6:
                        return g.F(e, Ynb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(e, 3);
                        break;
                    case 2:
                        return g.ya(e), e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 3:
                        return e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c))
                }
            })
        },
        qqb = function(a, b, c, d) {
            var e, f, h;
            return g.J(function(l) {
                switch (l.j) {
                    case 1:
                        return g.F(l, cob([b]), 2);
                    case 2:
                        return e = l.B, g.F(l, uqb(a, e[0], c, d), 3);
                    case 3:
                        return f = l.B, h = t6(f.thumbnailDetails), g.F(l, y6(h), 4);
                    case 4:
                        return l.return(e[0].videos)
                }
            })
        },
        uqb = function(a, b, c, d) {
            var e, f, h, l, m, n, p, q, r;
            return g.J(function(t) {
                return t.j == 1 ? (e = b.playlistId, f = Znb(b), h = f.y3, l = f.x3, m = c ? (Number(c) * 1E3).toString() : Date.now().toString(), n = b.lastModifiedTimestamp ? (Number(b.lastModifiedTimestamp) * 1E3).toString() : "0", p = {
                    id: g.GK(e, "musicPlaylistDownloadMetadataEntity"),
                    trackDownloadMetadatas: l,
                    lastModifiedTimestampMillis: n,
                    addedTimestampMillis: m,
                    syncState: "DOWNLOAD_SYNC_STATE_UP_TO_DATE"
                }, q = {
                    id: g.GK(e, "musicPlaylist"),
                    title: b.title,
                    playlistId: e,
                    thumbnailDetails: b.thumbnail,
                    visibility: vqb(b),
                    trackCount: b.totalVideoCount,
                    tracks: h,
                    downloadMetadata: p.id
                }, d && (((r = q) == null ? 0 : r.entityMetadata) ? q.entityMetadata.nextAutoRefreshIntervalSeconds = String(d) : q && (q.entityMetadata = {
                    nextAutoRefreshIntervalSeconds: String(d)
                })), g.F(t, Z5(a.j, {
                    mode: "readwrite",
                    Pb: !0
                }, function(u) {
                    var y = V5(u, q, "musicPlaylist");
                    u = V5(u, p, "musicPlaylistDownloadMetadataEntity");
                    return g.zt.all([y, u])
                }), 2)) : t.return(q)
            })
        },
        vqb = function(a) {
            switch (a.privacy) {
                case "PRIVATE":
                    return "PLAYLIST_ENTITY_VISIBILITY_PRIVATE";
                case "PUBLIC":
                    return "PLAYLIST_ENTITY_VISIBILITY_PUBLIC";
                case "UNLISTED":
                    return "PLAYLIST_ENTITY_VISIBILITY_UNLISTED";
                default:
                    return "PLAYLIST_ENTITY_VISIBILITY_UNKNOWN"
            }
        },
        wqb = function(a, b) {
            this.j = a;
            this.C = b
        },
        Aqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u;
            return g.J(function(y) {
                switch (y.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey), e = d.entityId, f = g.Q(b.actionMetadata, xqb), g.wa(y, 2), g.F(y, yqb(a, e, void 0, (h = f) == null ? void 0 : h.track, (l = f) == null ? void 0 : l.albumRelease), 4);
                    case 4:
                        if ((m = f) == null ? 0 : m.playlistId) {
                            y.Fa(5);
                            break
                        }
                        return g.F(y, Xnb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(y, 3);
                        break;
                    case 2:
                        return n = g.ya(y), p = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", q = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", n instanceof g.qt && n.type === "QUOTA_EXCEEDED" &&
                            (p = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", q = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), y.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, p, q));
                    case 3:
                        t = Number(((r = b.actionMetadata) == null ? void 0 : r.priority) || 0) + 1;
                        var B = (B = g.Q(b.actionMetadata, xqb)) ? {
                            playbackDataActionMetadata: {
                                maximumDownloadQuality: B.maximumDownloadQuality
                            }
                        } : void 0;
                        u = K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", e, "playbackData", t, zqb, B);
                        return y.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c, [u]))
                }
            })
        },
        Bqb = function(a, b) {
            var c, d, e, f, h, l, m, n, p, q, r, t, u, y, B;
            return g.J(function(C) {
                switch (C.j) {
                    case 1:
                        return c = m6(b), d = g.FK(b.entityKey), e = d.entityId, g.F(C, a6(a.j, b.entityKey, "musicTrack"), 2);
                    case 2:
                        f = C.B;
                        if (!f) {
                            h = void 0;
                            C.Fa(3);
                            break
                        }
                        return g.F(C, a6(a.j, f.downloadMetadata, "musicTrackDownloadMetadataEntity"), 4);
                    case 4:
                        h = C.B;
                    case 3:
                        l = h;
                        if (!f || !l) return C.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c));
                        n = g.Q(b.actionMetadata, xqb);
                        g.wa(C, 5);
                        return g.F(C, yqb(a, e, l.addedTimestampMillis, (p = n) == null ? void 0 : p.track, (q = n) == null ? void 0 : q.albumRelease),
                            7);
                    case 7:
                        t = Number(((r = b.actionMetadata) == null ? void 0 : r.priority) || 0) + 1;
                        m = K6("OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH", e, "playbackData", t, zqb);
                        g.xa(C, 6);
                        break;
                    case 5:
                        u = g.ya(C);
                        if (!(u instanceof Error && u.message === "No data")) {
                            if (u instanceof Error && u.message === "Empty response body") g6(u.message);
                            else return y = "OFFLINE_OPERATION_FAILURE_REASON_UNKNOWN", B = "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED", u instanceof g.qt && u.type === "QUOTA_EXCEEDED" && (y = "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED",
                                B = "OFFLINE_ORCHESTRATION_FAILURE_REASON_NO_STORAGE"), C.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, y, B));
                            C.Fa(6);
                            break
                        }
                        return g.F(C, D6(e, a.j, b, a.C), 6);
                    case 6:
                        return C.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS", c, m ? [m] : void 0))
                }
            })
        },
        Cqb = function(a, b) {
            var c, d;
            return g.J(function(e) {
                switch (e.j) {
                    case 1:
                        return c = m6(b), g.wa(e, 2), d = g.FK(b.entityKey).entityId, d === "!*$_ALL_ENTITIES_!*$" ? g.F(e, F6(a.j, b, a.C), 5) : g.F(e, D6(d, a.j, b, a.C), 6);
                    case 6:
                        return g.F(e, Ynb(a.j, b.entityKey), 5);
                    case 5:
                        g.xa(e, 3);
                        break;
                    case 2:
                        return g.ya(e), e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_FAILURE", c, void 0, "OFFLINE_OPERATION_FAILURE_REASON_DATABASE_REQUEST_FAILED", "OFFLINE_ORCHESTRATION_FAILURE_REASON_DATABASE_OPERATION_FAILED"));
                    case 3:
                        return e.return(new L6("OFFLINE_ORCHESTRATION_ACTION_RESULT_SUCCESS",
                            c))
                }
            })
        },
        yqb = function(a, b, c, d, e) {
            var f, h, l, m, n, p;
            return g.J(function(q) {
                switch (q.j) {
                    case 1:
                        if (f = d) {
                            q.Fa(2);
                            break
                        }
                        return g.F(q, bob([b]), 3);
                    case 3:
                        h = q.B, l = h[0], f = Wnb(l);
                    case 2:
                        return g.F(q, Dqb(a, f, b, e, c), 4);
                    case 4:
                        m = q.B;
                        n = m.musicTrackEntity;
                        p = m.I7;
                        var r = t6(n.thumbnailDetails),
                            t = [];
                        p && (t = t6(p.thumbnailDetails));
                        return g.F(q, y6(r.concat(t)), 0)
                }
            })
        },
        Dqb = function(a, b, c, d, e) {
            var f;
            return g.J(function(h) {
                return h.j == 1 ? (e || (e = Date.now().toString()), f = {
                    id: g.GK(c, "musicTrackDownloadMetadataEntity"),
                    playbackData: g.GK(c, "playbackData"),
                    addedTimestampMillis: e,
                    videoDownloadContextEntity: g.GK(c, "videoDownloadContextEntity")
                }, d && (b.albumRelease = d.id), g.F(h, Z5(a.j, {
                    mode: "readwrite",
                    Pb: !0
                }, function(l) {
                    var m = [],
                        n = V5(l, f, "musicTrackDownloadMetadataEntity");
                    m.push(n);
                    n = V5(l, b, "musicTrack");
                    m.push(n);
                    d && (l = V5(l, d, "musicAlbumRelease"), m.push(l));
                    return g.zt.all(m)
                }), 2)) : h.j != 3 ? g.F(h, q6(c, "musicTrackDownloadMetadataEntity",
                    a.j, "DOWNLOAD_STATE_PENDING_DOWNLOAD"), 3) : h.return({
                    musicTrackEntity: b,
                    I7: d
                })
            })
        },
        c7 = function() {
            X6.apply(this, arguments);
            this.Y = "musicTrack"
        },
        Eqb = function(a, b, c) {
            b = b === void 0 ? 43200 : b;
            c = c === void 0 ? !0 : c;
            var d = d === void 0 ? !1 : d;
            var e, f;
            return g.J(function(h) {
                switch (h.j) {
                    case 1:
                        if (!a.K.ph()) return h.return([]);
                        e = [];
                        g.wa(h, 2);
                        return g.F(h, iob(b, c, d), 4);
                    case 4:
                        e = h.B;
                        g.xa(h, 3);
                        break;
                    case 2:
                        g.ya(h);
                    case 3:
                        return f = Kpb(a, e, c, "musicPlaylist"), h.return(f)
                }
            })
        },
        Fqb = function() {
            g.VX.apply(this, arguments);
            var a = this;
            this.events = new g.DE(this);
            this.X = this.player.U();
            this.bd = {
                uoa: function() {
                    return a.j
                },
                LK: function() {
                    return a.LK()
                },
                PQ: function(b) {
                    return a.PQ(b)
                }
            }
        },
        Gqb = function(a) {
            var b;
            a = g.Q((b = a.getWatchNextResponse()) == null ? void 0 : b.currentVideoEndpoint, g.BQ);
            if (a == null ? 0 : a.playlistId) var c = a.playlistId;
            return c
        },
        Hqb = function(a, b) {
            var c, d, e, f;
            return g.J(function(h) {
                if (h.j == 1) {
                    c = b.clientPlaybackNonce;
                    d = {
                        cpn: c,
                        offlineSourceVisualElement: g.ww(b.Ga || "").getAsJson(),
                        selectedOfflineMode: "OFFLINE_NOW",
                        isPartialPlayback: !1
                    };
                    b.B && (d.videoFmt = Number(b.B.itag));
                    b.D && (d.audioFmt = Number(b.D.itag));
                    if ((e = Gqb(b)) && b.videoId) {
                        var l = b.videoId;
                        l = e !== "PPSV" ? Promise.resolve(!1) : a.j.AV(l);
                        h = g.F(h, l, 3)
                    } else h = h.Fa(2);
                    return h
                }
                h.j != 2 && (f = h.B) && (d.selectedOfflineMode = "OFFLINE_MODE_TYPE_AUTO_OFFLINE");
                a.B = c;
                g.jt("offlinePlaybackStarted", d);
                g.va(h)
            })
        };
    g.z(N5, M5);
    g.ea.Object.defineProperties(N5.prototype, {
        entityMetadata: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.j.entityMetadata
            },
            set: function(a) {
                this.j.entityMetadata = a
            }
        }
    });
    g.z(Lkb, N5);
    Lkb.prototype.B = function() {
        return []
    };
    g.z(Mkb, N5);
    Mkb.prototype.B = function() {
        return []
    };
    g.z(Nkb, N5);
    Nkb.prototype.B = function() {
        var a = [];
        this.j.alternateChannel && a.push(this.j.alternateChannel);
        this.j.alternateChannelList && a.push.apply(a, g.x(this.j.alternateChannelList));
        this.j.oneofChannelEntity && a.push(this.j.oneofChannelEntity);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Okb, N5);
    Okb.prototype.B = function() {
        var a = [];
        this.j.entryCollection && a.push(this.j.entryCollection);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Pkb, M5);
    Pkb.prototype.B = function() {
        var a = [];
        this.j.video && a.push(this.j.video);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Qkb, N5);
    Qkb.prototype.B = function() {
        var a = [];
        this.j.parentPlaylist && a.push(this.j.parentPlaylist);
        if (this.j.entries)
            for (var b = g.w(this.j.entries), c = b.next(); !c.done; c = b.next()) a.push.apply(a, g.x((new Pkb(c.value)).B()));
        return [].concat(g.x(new Set(a)))
    };
    g.z(Rkb, N5);
    Rkb.prototype.B = function() {
        var a = [];
        this.j.descriptionEntity && a.push(this.j.descriptionEntity);
        this.j.creators && a.push.apply(a, g.x(this.j.creators));
        this.j.theBiggestFan && a.push(this.j.theBiggestFan);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Skb, N5);
    Skb.prototype.B = function() {
        return []
    };
    g.z(Tkb, N5);
    Tkb.prototype.B = function() {
        return []
    };
    g.z(Ukb, N5);
    Ukb.prototype.B = function() {
        return []
    };
    g.z(Vkb, N5);
    Vkb.prototype.B = function() {
        return []
    };
    g.z(Wkb, N5);
    Wkb.prototype.B = function() {
        return []
    };
    g.z(Xkb, N5);
    Xkb.prototype.B = function() {
        return []
    };
    g.z(Ykb, N5);
    Ykb.prototype.B = function() {
        return []
    };
    g.z(Zkb, N5);
    Zkb.prototype.B = function() {
        return []
    };
    g.z($kb, N5);
    $kb.prototype.B = function() {
        var a = [];
        this.j.downloadsList && a.push(this.j.downloadsList);
        this.j.smartDownloadsList && a.push(this.j.smartDownloadsList);
        this.j.recommendedDownloadsList && a.push(this.j.recommendedDownloadsList);
        this.j.refresh && a.push(this.j.refresh);
        return [].concat(g.x(new Set(a)))
    };
    g.z(alb, M5);
    alb.prototype.B = function() {
        var a = [];
        this.j.video && a.push(this.j.video);
        this.j.playlist && a.push(this.j.playlist);
        this.j.videoItem && a.push(this.j.videoItem);
        this.j.playlistItem && a.push(this.j.playlistItem);
        return [].concat(g.x(new Set(a)))
    };
    g.z(blb, N5);
    blb.prototype.B = function() {
        var a = [];
        this.j.refresh && a.push(this.j.refresh);
        if (this.j.downloads)
            for (var b = g.w(this.j.downloads), c = b.next(); !c.done; c = b.next()) a.push.apply(a, g.x((new alb(c.value)).B()));
        return [].concat(g.x(new Set(a)))
    };
    g.z(clb, N5);
    clb.prototype.B = function() {
        var a = [];
        this.j.localImageEntities && a.push.apply(a, g.x(this.j.localImageEntities));
        return [].concat(g.x(new Set(a)))
    };
    g.z(dlb, N5);
    dlb.prototype.B = function() {
        var a = [];
        this.j.playbackData && a.push(this.j.playbackData);
        this.j.localImageEntities && a.push.apply(a, g.x(this.j.localImageEntities));
        this.j.videoDownloadContextEntity && a.push(this.j.videoDownloadContextEntity);
        return [].concat(g.x(new Set(a)))
    };
    g.z(elb, N5);
    elb.prototype.B = function() {
        return []
    };
    g.z(flb, N5);
    flb.prototype.B = function() {
        var a = [];
        this.j.fakeChildren && a.push.apply(a, g.x(this.j.fakeChildren));
        return [].concat(g.x(new Set(a)))
    };
    g.z(glb, N5);
    glb.prototype.B = function() {
        var a = [];
        this.j.video && a.push(this.j.video);
        this.j.playbackData && a.push(this.j.playbackData);
        this.j.offlineVideoPolicy && a.push(this.j.offlineVideoPolicy);
        return [].concat(g.x(new Set(a)))
    };
    g.z(hlb, N5);
    hlb.prototype.B = function() {
        return []
    };
    g.z(ilb, N5);
    ilb.prototype.B = function() {
        var a = [];
        this.j.channelOwner && a.push(this.j.channelOwner);
        this.j.videos && a.push.apply(a, g.x(this.j.videos));
        this.j.collaboratorChannels && a.push.apply(a, g.x(this.j.collaboratorChannels));
        this.j.downloadState && a.push(this.j.downloadState);
        this.j.refresh && a.push(this.j.refresh);
        return [].concat(g.x(new Set(a)))
    };
    g.z(jlb, N5);
    jlb.prototype.B = function() {
        var a = [];
        this.j.video && a.push(this.j.video);
        this.j.channelContributor && a.push(this.j.channelContributor);
        return [].concat(g.x(new Set(a)))
    };
    g.z(klb, M5);
    klb.prototype.B = function() {
        var a = [];
        this.j.localImageEntities && a.push.apply(a, g.x(this.j.localImageEntities));
        this.j.videoDownloadContextEntity && a.push(this.j.videoDownloadContextEntity);
        return [].concat(g.x(new Set(a)))
    };
    g.z(llb, M5);
    llb.prototype.B = function() {
        var a = [];
        this.j.recommendedVideoMetadata && a.push.apply(a, g.x((new klb(this.j.recommendedVideoMetadata)).B()));
        return [].concat(g.x(new Set(a)))
    };
    g.z(mlb, M5);
    mlb.prototype.B = function() {
        var a = [];
        this.j.playbackPosition && a.push(this.j.playbackPosition);
        return [].concat(g.x(new Set(a)))
    };
    g.z(nlb, N5);
    nlb.prototype.B = function() {
        var a = [];
        this.j.owner && a.push(this.j.owner);
        this.j.downloadState && a.push(this.j.downloadState);
        this.j.userState && a.push.apply(a, g.x((new mlb(this.j.userState)).B()));
        this.j.additionalMetadata && a.push.apply(a, g.x((new llb(this.j.additionalMetadata)).B()));
        return [].concat(g.x(new Set(a)))
    };
    g.z(olb, N5);
    olb.prototype.B = function() {
        var a = [];
        this.j.userChannelDetails && a.push(this.j.userChannelDetails);
        return [].concat(g.x(new Set(a)))
    };
    g.z(plb, N5);
    plb.prototype.B = function() {
        var a = [];
        this.j.channelOwner && a.push(this.j.channelOwner);
        this.j.playbackPosition && a.push(this.j.playbackPosition);
        this.j.localImageEntities && a.push.apply(a, g.x(this.j.localImageEntities));
        this.j.downloadStatus && a.push(this.j.downloadStatus);
        return [].concat(g.x(new Set(a)))
    };
    g.z(qlb, N5);
    qlb.prototype.B = function() {
        return []
    };
    g.z(rlb, N5);
    rlb.prototype.B = function() {
        return []
    };
    g.z(slb, N5);
    slb.prototype.B = function() {
        return []
    };
    g.z(tlb, N5);
    tlb.prototype.B = function() {
        return []
    };
    g.z(ulb, N5);
    ulb.prototype.B = function() {
        return []
    };
    g.z(vlb, N5);
    vlb.prototype.B = function() {
        return []
    };
    g.z(wlb, N5);
    wlb.prototype.B = function() {
        return []
    };
    g.z(xlb, N5);
    xlb.prototype.B = function() {
        return []
    };
    g.z(ylb, N5);
    ylb.prototype.B = function() {
        var a = [];
        this.j.trackDownloadMetadatas && a.push.apply(a, g.x(this.j.trackDownloadMetadatas));
        return [].concat(g.x(new Set(a)))
    };
    g.z(zlb, N5);
    zlb.prototype.B = function() {
        var a = [];
        this.j.downloadedTracks && a.push.apply(a, g.x(this.j.downloadedTracks));
        this.j.smartDownloadedTracks && a.push.apply(a, g.x(this.j.smartDownloadedTracks));
        this.j.downloadedEpisodes && a.push.apply(a, g.x(this.j.downloadedEpisodes));
        this.j.downloadedAlbumReleases && a.push.apply(a, g.x(this.j.downloadedAlbumReleases));
        this.j.smartDownloadedAlbumReleases && a.push.apply(a, g.x(this.j.smartDownloadedAlbumReleases));
        this.j.downloadedPlaylists && a.push.apply(a, g.x(this.j.downloadedPlaylists));
        this.j.smartDownloadedPlaylists &&
            a.push.apply(a, g.x(this.j.smartDownloadedPlaylists));
        this.j.metadataOnlyTracks && a.push.apply(a, g.x(this.j.metadataOnlyTracks));
        return [].concat(g.x(new Set(a)))
    };
    g.z(Alb, N5);
    Alb.prototype.B = function() {
        var a = [];
        this.j.trackDownloadMetadatas && a.push.apply(a, g.x(this.j.trackDownloadMetadatas));
        return [].concat(g.x(new Set(a)))
    };
    g.z(Blb, N5);
    Blb.prototype.B = function() {
        var a = [];
        this.j.playbackData && a.push(this.j.playbackData);
        this.j.localImageEntities && a.push.apply(a, g.x(this.j.localImageEntities));
        this.j.videoDownloadContextEntity && a.push(this.j.videoDownloadContextEntity);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Clb, N5);
    Clb.prototype.B = function() {
        var a = [];
        this.j.musicLibraryStatusEntity && a.push(this.j.musicLibraryStatusEntity);
        this.j.primaryArtists && a.push.apply(a, g.x(this.j.primaryArtists));
        this.j.details && a.push(this.j.details);
        this.j.userDetails && a.push(this.j.userDetails);
        this.j.tracks && a.push.apply(a, g.x(this.j.tracks));
        this.j.share && a.push(this.j.share);
        this.j.downloadMetadata && a.push(this.j.downloadMetadata);
        this.j.refresh && a.push(this.j.refresh);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Dlb, N5);
    Dlb.prototype.B = function() {
        var a = [];
        this.j.albumRelease && a.push(this.j.albumRelease);
        this.j.tracks && a.push.apply(a, g.x(this.j.tracks));
        return [].concat(g.x(new Set(a)))
    };
    g.z(Elb, N5);
    Elb.prototype.B = function() {
        var a = [];
        this.j.albumRelease && a.push(this.j.albumRelease);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Flb, N5);
    Flb.prototype.B = function() {
        var a = [];
        this.j.details && a.push(this.j.details);
        this.j.userDetails && a.push(this.j.userDetails);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Glb, N5);
    Glb.prototype.B = function() {
        var a = [];
        this.j.parentArtist && a.push(this.j.parentArtist);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Hlb, N5);
    Hlb.prototype.B = function() {
        var a = [];
        this.j.parentArtist && a.push(this.j.parentArtist);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Ilb, N5);
    Ilb.prototype.B = function() {
        return []
    };
    g.z(Jlb, N5);
    Jlb.prototype.B = function() {
        return []
    };
    g.z(Klb, M5);
    Klb.prototype.B = function() {
        var a = [];
        this.j.creatorEntity && a.push(this.j.creatorEntity);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Llb, N5);
    Llb.prototype.B = function() {
        var a = [];
        this.j.tracks && a.push.apply(a, g.x(this.j.tracks));
        this.j.refresh && a.push(this.j.refresh);
        this.j.musicLibraryStatusEntity && a.push(this.j.musicLibraryStatusEntity);
        this.j.details && a.push(this.j.details);
        this.j.downloadMetadata && a.push(this.j.downloadMetadata);
        this.j.sideloadMetadata && a.push(this.j.sideloadMetadata);
        this.j.userDetails && a.push(this.j.userDetails);
        this.j.entryCollection && a.push(this.j.entryCollection);
        this.j.share && a.push(this.j.share);
        this.j.podcastShowAdditionalMetadata && a.push.apply(a,
            g.x((new Klb(this.j.podcastShowAdditionalMetadata)).B()));
        return [].concat(g.x(new Set(a)))
    };
    g.z(Mlb, N5);
    Mlb.prototype.B = function() {
        return []
    };
    g.z(Nlb, N5);
    Nlb.prototype.B = function() {
        var a = [];
        this.j.musicLibraryStatusEntity && a.push(this.j.musicLibraryStatusEntity);
        this.j.artists && a.push.apply(a, g.x(this.j.artists));
        this.j.audioModeVersion && a.push(this.j.audioModeVersion);
        this.j.videoModeVersion && a.push(this.j.videoModeVersion);
        this.j.userDetails && a.push(this.j.userDetails);
        this.j.details && a.push(this.j.details);
        this.j.albumRelease && a.push(this.j.albumRelease);
        this.j.share && a.push(this.j.share);
        this.j.libraryEdit && a.push(this.j.libraryEdit);
        this.j.downloadMetadata &&
            a.push(this.j.downloadMetadata);
        this.j.playbackPosition && a.push(this.j.playbackPosition);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Olb, N5);
    Olb.prototype.B = function() {
        var a = [];
        this.j.parentTrack && a.push(this.j.parentTrack);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Plb, N5);
    Plb.prototype.B = function() {
        var a = [];
        this.j.parentTrack && a.push(this.j.parentTrack);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Qlb, N5);
    Qlb.prototype.B = function() {
        return []
    };
    g.z(Rlb, N5);
    Rlb.prototype.B = function() {
        return []
    };
    g.z(Slb, N5);
    Slb.prototype.B = function() {
        return []
    };
    g.z(Tlb, N5);
    Tlb.prototype.B = function() {
        return []
    };
    g.z(Ulb, N5);
    Ulb.prototype.B = function() {
        var a = [];
        this.j.transfer && a.push(this.j.transfer);
        this.j.adsPlaybackData && a.push.apply(a, g.x(this.j.adsPlaybackData));
        this.j.drmLicense && a.push(this.j.drmLicense);
        this.j.offlineVideoPolicy && a.push(this.j.offlineVideoPolicy);
        this.j.videoDownloadContextEntity && a.push(this.j.videoDownloadContextEntity);
        return [].concat(g.x(new Set(a)))
    };
    g.z(Vlb, N5);
    Vlb.prototype.B = function() {
        return []
    };
    g.z(Wlb, N5);
    Wlb.prototype.B = function() {
        var a = [];
        this.j.offlineVideoStreams && a.push.apply(a, g.x(this.j.offlineVideoStreams));
        this.j.captionTrack && a.push.apply(a, g.x(this.j.captionTrack));
        return [].concat(g.x(new Set(a)))
    };
    g.z(Xlb, N5);
    Xlb.prototype.B = function() {
        return []
    };
    g.z(Ylb, N5);
    Ylb.prototype.B = function() {
        return []
    };
    g.z(Zlb, N5);
    Zlb.prototype.B = function() {
        return []
    };
    g.z($lb, N5);
    $lb.prototype.B = function() {
        return []
    };
    g.z(amb, N5);
    amb.prototype.B = function() {
        return []
    };
    g.z(bmb, N5);
    bmb.prototype.B = function() {
        return []
    };
    g.z(cmb, N5);
    cmb.prototype.B = function() {
        return []
    };
    g.z(dmb, N5);
    dmb.prototype.B = function() {
        return []
    };
    g.z(emb, N5);
    emb.prototype.B = function() {
        return []
    };
    g.z(fmb, N5);
    fmb.prototype.B = function() {
        return []
    };
    g.z(gmb, N5);
    gmb.prototype.B = function() {
        return []
    };
    g.z(hmb, N5);
    hmb.prototype.B = function() {
        return []
    };
    g.z(imb, N5);
    imb.prototype.B = function() {
        return []
    };
    g.z(jmb, N5);
    jmb.prototype.B = function() {
        return []
    };
    g.z(kmb, N5);
    kmb.prototype.B = function() {
        return []
    };
    var job = ["browse", "music/browse", "unplugged/browse"],
        oob = ["offline/playlist_sync_check"],
        aob = ["offline"],
        kob = ["offline/offline_video_playback_position_sync"],
        mob = ["offline/get_playback_data_entity"];
    O5.getInstance = function() {
        return g.J(function(a) {
            return a.return(new Promise(function(b) {
                g.$t().then(function(c) {
                    c ? (O5.instance || (O5.instance = new O5(c)), b(O5.instance)) : b(void 0)
                })
            }))
        })
    };
    O5.prototype.get = function(a) {
        var b = this,
            c, d, e;
        return g.J(function(f) {
            if (f.j == 1) return g.F(f, lmb(b.token), 2);
            if (f.j != 3) return c = f.B, g.F(f, c.get("prefs", a), 3);
            d = f.B;
            if (!d) return f.return();
            e = (0, g.S)();
            return d.expirationTimestampMs <= e ? f.return() : f.return(d.value)
        })
    };
    O5.prototype.set = function(a, b, c) {
        c = c === void 0 ? 31536E3 : c;
        var d = this,
            e, f, h;
        return g.J(function(l) {
            if (l.j == 1) return e = (0, g.S)(), f = {
                key: a,
                value: b,
                expirationTimestampMs: e + c * 1E3
            }, g.F(l, lmb(d.token), 2);
            h = l.B;
            return g.F(l, g.It(h, "prefs", f), 0)
        })
    };
    O5.prototype.remove = function(a) {
        var b = this,
            c;
        return g.J(function(d) {
            if (d.j == 1) return g.F(d, lmb(b.token), 2);
            c = d.B;
            return g.F(d, c.delete("prefs", a), 0)
        })
    };
    var P5;
    g.z(Q5, g.Us);
    g.z(R5, tmb);
    R5.prototype.C = function(a, b) {
        b = vmb(b);
        a = (new TextEncoder).encode(JSON.stringify(a));
        return this.j.encrypt(a, b)
    };
    R5.prototype.B = function(a, b) {
        if (!(a instanceof Uint8Array)) throw pmb(1);
        var c = new TextDecoder;
        b = vmb(b);
        a = this.j.decrypt(a, b);
        return JSON.parse(c.decode(a))
    };
    var wmb = {
        buttonEntity: emb,
        captionTrack: Qlb,
        channelHandle: Lkb,
        commerceAcquisitionClientPayloadEntity: gmb,
        commerceCartListEntity: hmb,
        contextNoteFeedEntityPayload: Mkb,
        continuationTokenEntity: hlb,
        downloadQualityPickerEntity: Xkb,
        downloadsPageRefreshTokenEntity: Zkb,
        downloadsPageViewConfigurationEntity: qlb,
        downloadStatusEntity: Ykb,
        sfvAudioItemCurrentlyPlayingEntity: Ylb,
        emojiFountainDataEntity: cmb,
        emojiCustomizationSetEntity: bmb,
        fakeChannel: Nkb,
        fakePlaylist: Okb,
        fakePlaylistEntryCollection: Qkb,
        fakeVideo: Rkb,
        fakeVideoDescription: Skb,
        featuredProductsEntity: vlb,
        flowStateEntity: Tkb,
        iconBadgeEntity: imb,
        interstitialInteractionStateEntity: Vkb,
        liveChatPollStateEntity: Wkb,
        liveReactionsDataEntity: dmb,
        logoEntity: Ukb,
        macroMarkerEntity: rlb,
        mainDownloadsLibraryEntity: $kb,
        mainDownloadsListEntity: blb,
        mainPlaylistDownloadStateEntity: clb,
        mainPlaylistEntity: ilb,
        mainPlaylistVideoEntity: jlb,
        mainVideoDownloadStateEntity: dlb,
        mainVideoEntity: nlb,
        markersEngagementPanelSyncEntity: slb,
        markersVisibilityOverrideEntity: tlb,
        musicAlbumReleaseDetail: Dlb,
        musicAlbumReleaseDownloadMetadataEntity: ylb,
        musicAlbumRelease: Clb,
        musicAlbumReleaseUserDetail: Elb,
        musicArtistDetail: Glb,
        musicArtist: Flb,
        musicArtistUserDetail: Hlb,
        musicDownloadsLibraryEntity: zlb,
        musicLibraryEdit: Ilb,
        musicLibraryStatusEntity: Jlb,
        musicPlaylist: Llb,
        musicPlaylistDownloadMetadataEntity: Alb,
        musicShare: Mlb,
        musicTrackDetail: Olb,
        musicTrackDownloadMetadataEntity: Blb,
        musicTrack: Nlb,
        musicTrackUserDetail: Plb,
        offlineOrchestrationActionWrapperEntity: Rlb,
        offlineVideoPolicy: Slb,
        offlineVideoStreams: Tlb,
        offlineabilityEntity: elb,
        orchestrationWebSamplingEntity: flb,
        pageHeaderEntity: amb,
        pdpStateEntity: jmb,
        pinnedProductEntity: wlb,
        playbackData: Ulb,
        playerStateEntity: ulb,
        quantityIncrementerEntity: kmb,
        refresh: Vlb,
        saveToPlaylistListEntity: Zlb,
        settingEntity: $lb,
        transfer: Wlb,
        trendingOfferEntity: xlb,
        videoDownloadContextEntity: Xlb,
        videoPlaybackPositionEntity: fmb,
        ytMainChannelEntity: olb,
        ytMainDownloadedVideoEntity: glb,
        ytMainVideoEntity: plb
    };
    g.z(X5, tmb);
    X5.prototype.C = function(a) {
        return a
    };
    X5.prototype.B = function(a) {
        if (a instanceof Uint8Array) throw pmb(0);
        return a
    };
    g.z(Y5, g.O);
    Y5.prototype.B = function(a) {
        Kmb(this, a.data)
    };
    Y5.prototype.xa = function() {
        this.channel.close()
    };
    var Qmb;
    var Mnb = new g.zq("elementsCommand");
    var A6 = new g.zq("entityBatchUpdate");
    var Anb = new g.zq("downloadStatusEntity");
    var Qpb = new g.zq("mainPlaylistEntityActionMetadata");
    var $6 = new g.zq("mainVideoEntityActionMetadata");
    var $nb = new g.zq("musicPlaylistEntityActionMetadata");
    var xqb = new g.zq("musicTrackEntityActionMetadata");
    var Nnb = new g.zq("offlineOrchestrationActionCommand");
    var eqb = new g.zq("localImageEntityActionMetadata");
    var M6 = new g.zq("playbackDataActionMetadata");
    var Mob = new g.zq("transferEntityActionMetadata");
    var xob = new g.zq("videoPlaybackPositionEntityActionMetadata");
    g.GK("", "downloadsPageViewConfigurationEntity");
    g.GK("DOWNLOADS_LIST_ENTITY_ID_MANUAL_DOWNLOADS", "mainDownloadsListEntity");
    var B6 = g.GK("DOWNLOADS_LIST_ENTITY_ID_SMART_DOWNLOADS", "mainDownloadsListEntity");
    g.GK("DOWNLOADS_LIST_ENTITY_ID_SMART_DOWNLOADS", "refresh");
    g.GK("SMART_DOWNLOADS_ENABLED", "settingEntity");
    g.GK("SMART_DOWNLOADS_OPT_IN_BANNER_DISMISSED", "settingEntity");
    var enb;
    new g.oj;
    new g.oj;
    jnb.prototype.request = function(a, b, c) {
        b = b === void 0 ? {} : b;
        return this.locks.request(a, b, function(d) {
            return c(d)
        })
    };
    var f6 = g.La.caches,
        e6, onb;
    d6.prototype.open = function(a) {
        return f6.open(mnb(a))
    };
    d6.prototype.has = function(a) {
        return f6.has(mnb(a))
    };
    d6.prototype.delete = function(a) {
        return f6.delete(mnb(a))
    };
    d6.prototype.match = function(a, b) {
        var c = this,
            d, e, f, h, l, m;
        return g.J(function(n) {
            switch (n.j) {
                case 1:
                    return g.F(n, c.keys(), 2);
                case 2:
                    d = n.B, e = g.w(d), f = e.next();
                case 3:
                    if (f.done) {
                        n.Fa(5);
                        break
                    }
                    h = f.value;
                    return g.F(n, c.open(h), 6);
                case 6:
                    return l = n.B, g.F(n, l.match(a, b), 7);
                case 7:
                    if (m = n.B) return n.return(m);
                    f = e.next();
                    n.Fa(3);
                    break;
                case 5:
                    return n.return()
            }
        })
    };
    g.z(lnb, d6);
    lnb.prototype.keys = function() {
        var a, b, c, d, e, f, h, l, m;
        return g.J(function(n) {
            if (n.j == 1) return a = [], b = g.Vs("CacheStorage keys"), g.F(n, f6.keys(), 2);
            c = n.B;
            d = g.w(c);
            for (e = d.next(); !e.done; e = d.next()) {
                f = e.value;
                var p = f.indexOf(":");
                h = p === -1 ? {
                    iM: f
                } : {
                    iM: f.substring(0, p),
                    datasyncId: f.substring(p + 1)
                };
                l = h.iM;
                m = h.datasyncId;
                m === b && a.push(l)
            }
            return n.return(a)
        })
    };
    g.z(h6, g.O);
    h6.prototype.C = function(a) {
        this.api.gb("onOfflineOperationFailure", a.data)
    };
    h6.prototype.D = function(a) {
        this.api.publish("offlinetransferpause", a.data)
    };
    h6.prototype.xa = function() {
        var a;
        (a = this.j) == null || a.close();
        var b;
        (b = this.B) == null || b.close()
    };
    rnb.prototype.Nf = function() {
        this.j && j6(this)
    };
    rnb.prototype.HM = function() {
        this.B && this.B.resolve();
        this.C = this.j = !1;
        this.Y()
    };
    var bpb = ["OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD", "OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH"];
    var Jnb = "captionTrack downloadStatusEntity ytMainChannelEntity mainPlaylistEntity mainPlaylistDownloadStateEntity mainPlaylistVideoEntity mainVideoEntity mainVideoDownloadStateEntity offlineVideoPolicy offlineVideoStreams playbackData transfer videoDownloadContextEntity videoPlaybackPositionEntity".split(" ");
    var Vnb = "downloadStatusEntity musicAlbumRelease musicDownloadsLibraryEntity musicPlaylist musicTrack musicTrackDownloadMetadataEntity offlineVideoPolicy offlineVideoStreams playbackData transfer videoDownloadContextEntity".split(" ");
    g.z(qob, J6);
    qob.prototype.B = function(a) {
        return n6(a) ? tob(this, a) : o6(a) ? uob(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    g.z(vob, J6);
    vob.prototype.B = function(a) {
        return o6(a) ? wob(this, a) : znb(a) ? yob(this, a) : p6(a) ? zob(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    g.k = Aob.prototype;
    g.k.jba = function(a) {
        var b = this,
            c, d, e, f;
        return g.J(function(h) {
            if (!g.Z(a.state, 128)) return h.Fa(0);
            c = a.state.hh;
            var l = (d = c) == null ? void 0 : d.errorCode,
                m = (e = c) == null ? void 0 : e.tA;
            f = l === "net.connect" && m === 1 ? "TRANSFER_FAILURE_REASON_NETWORK_LOST" : (l == null ? 0 : l.startsWith("net.")) ? "TRANSFER_FAILURE_REASON_NETWORK" : "TRANSFER_FAILURE_REASON_INTERNAL";
            return g.F(h, b.Jy(b.player.getVideoData().videoId, f), 0)
        })
    };
    g.k.Jy = function(a, b) {
        var c = this;
        return g.J(function(d) {
            if (d.j == 1) {
                if (c.B) return d.return();
                c.B = !0;
                return b === "TRANSFER_FAILURE_REASON_NETWORK_LOST" ? (P6(c, a, !1, !0), d.Fa(0)) : g.F(d, O6(c, a), 3)
            }
            g.YP(a, 4);
            return g.F(d, c.j.Jy(b), 0)
        })
    };
    g.k.XL = function(a) {
        a.status === 2 ? (a.status !== this.C && (xpb(this.j), g.YP(a.videoId, 2)), a.rH && Cpb(this.j, a.videoId, a.rH)) : a.status === 4 ? (O6(this, a.videoId), this.Jy(a.videoId, a.VK ? "TRANSFER_FAILURE_REASON_FILESYSTEM_WRITE" : "TRANSFER_FAILURE_REASON_INTERNAL")) : a.status === 1 && Bpb(this.j);
        this.C = a.status;
        this.api.gb("localmediachange", {
            videoId: a.videoId,
            status: a.status
        })
    };
    g.k.CS = function() {
        var a = this,
            b;
        return g.J(function(c) {
            if (c.j == 1) {
                if (a.B) return c.return();
                a.B = !0;
                b = a.player.getVideoData().videoId;
                return g.F(c, O6(a, b), 2)
            }
            return g.F(c, a.j.CS(), 0)
        })
    };
    g.k.lQ = function(a) {
        switch (a) {
            case "HD_1080":
                return "hd1080";
            case "HD":
                return "hd720";
            case "SD":
                return "large";
            case "LD":
                return "tiny";
            default:
                return "hd720"
        }
    };
    g.k.L = function(a) {
        return this.api.U().L(a)
    };
    g.z(Hob, J6);
    Hob.prototype.B = function(a) {
        return n6(a) ? Job(this, a) : o6(a) ? Kob(this, a) : znb(a) ? Lob(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    Rob.prototype.j = function(a, b) {
        var c = a.action.actionMetadata.priority - b.action.actionMetadata.priority;
        c === 0 && (a.j < b.j ? c = -1 : a.j > b.j && (c = 1));
        return c
    };
    g.z(Q6, g.O);
    Q6.prototype.xa = function() {
        this.Y && this.Y();
        g.O.prototype.xa.call(this)
    };
    Q6.prototype.createAction = function(a, b) {
        var c = g.FK(a.entityKey).entityType,
            d = g.vv(16);
        return new u6(c, d, a, b.actionId, b.rootActionId)
    };
    Q6.prototype.qa = function(a) {
        var b = this,
            c, d, e, f, h, l, m, n, p;
        return g.J(function(q) {
            if (q.j == 1) {
                if (b.Ja()) return q.return();
                d = (c = a.offlineOrchestrationActionWrapperEntity) != null ? c : new Set;
                e = [];
                f = g.w(d);
                for (h = f.next(); !h.done; h = f.next()) l = h.value, m = g.FK(l), n = m.entityId, Uob(b.j, n) || e.push(l);
                return g.F(q, epb(b, e), 2)
            }
            p = q.B;
            return g.F(q, dpb(b, p), 0)
        })
    };
    Q6.prototype.retry = function() {
        var a = this;
        return g.J(function(b) {
            return g.F(b, fpb(a), 0)
        })
    };
    g.z(R6, g.O);
    R6.prototype.xa = function() {
        this.B && this.B();
        g.O.prototype.xa.call(this)
    };
    R6.prototype.C = function(a) {
        var b = this,
            c, d, e, f, h, l, m, n;
        return g.J(function(p) {
            d = (c = a.transfer) != null ? c : new Set;
            e = [];
            f = g.w(d);
            for (h = f.next(); !h.done; h = f.next()) l = h.value, m = g.FK(l), n = m.entityId, e.push(n);
            return e.length === 0 ? p.return() : g.F(p, lpb(b, e), 0)
        })
    };
    g.z(qpb, g.O);
    g.k = qpb.prototype;
    g.k.xa = function() {
        this.Ba && this.Ba();
        this.Da.dispose();
        this.D.dispose();
        this.Ma && g.Oh(this.K.Pm, this.Ma);
        this.Ka && g.Oh(this.K.Pm, this.Ka);
        g.O.prototype.xa.call(this)
    };
    g.k.sda = function(a) {
        var b = this,
            c, d, e;
        return g.J(function(f) {
            switch (f.j) {
                case 1:
                    c = g.GK(a, "transfer");
                    if (b.j && c === b.j.key) {
                        P6(b.N, b.G, !0);
                        b.D.stop();
                        f.Fa(0);
                        break
                    }
                    return g.F(f, Z5(b.B, {
                        mode: "readwrite",
                        Pb: !0
                    }, function(h) {
                        return S5(h, c, "transfer").then(function(l) {
                            if (l && l.transferState !== "TRANSFER_STATE_COMPLETE" && l.transferState !== "TRANSFER_STATE_FAILED") return l.transferState = "TRANSFER_STATE_PAUSED_BY_USER", V5(h, l, "transfer").then(function() {
                                return l
                            })
                        })
                    }), 3);
                case 3:
                    d = f.B;
                    if (!d) {
                        f.Fa(0);
                        break
                    }
                    if (!a || !b.C) {
                        f.Fa(5);
                        break
                    }
                    return g.F(f, q6(a, b.C, b.B, "DOWNLOAD_STATE_PAUSED"), 5);
                case 5:
                    return g.F(f, U6(b, a), 7);
                case 7:
                    e = f.B, xnb({
                        videoId: a,
                        lm: d,
                        offlineModeType: e
                    }), g.va(f)
            }
        })
    };
    g.k.rda = function() {
        var a = this;
        if (this.j && this.G) {
            P6(this.N, this.G, !1);
            var b = this.j,
                c = (b == null ? 0 : b.key) ? g.FK(b.key).entityId : "";
            c && this.C && (new Promise(function(d, e) {
                q6(c, a.C, a.B, "DOWNLOAD_STATE_PAUSED").catch(function(f) {
                    e(f)
                })
            })).catch(function(d) {
                g6("Download state setting error", d)
            })
        }
        this.D.stop()
    };
    g.k.KH = function() {
        this.j ? tpb(this, this.j) : T6(this)
    };
    g.k.u5 = function(a) {
        var b = this;
        return g.J(function(c) {
            switch (c.j) {
                case 1:
                    if (!b.j) {
                        c.Fa(2);
                        break
                    }
                    if (b.j.transferState === "TRANSFER_STATE_COMPLETE" || b.j.transferState === "TRANSFER_STATE_FAILED" || !a.transfer || !a.transfer.has(b.j.key)) {
                        c.Fa(3);
                        break
                    }
                    return g.F(c, a6(b.B, b.j.key, "transfer"), 4);
                case 4:
                    b.j = c.B;
                    if (b.j) {
                        c.Fa(3);
                        break
                    }
                    return g.F(c, upb(b), 3);
                case 3:
                    if (b.j) return c.return();
                case 2:
                    return g.F(c, T6(b), 0)
            }
        })
    };
    g.k.Jy = function(a, b) {
        var c = this,
            d, e, f, h, l;
        return g.J(function(m) {
            switch (m.j) {
                case 1:
                    if (!c.j) {
                        V6(c, "onTransferFailure: " + a);
                        m.Fa(2);
                        break
                    }
                    d = c.j;
                    f = ((e = d) == null ? 0 : e.key) ? g.FK(d.key).entityId : "";
                    a: switch (a) {
                        case "TRANSFER_FAILURE_REASON_FILESYSTEM_WRITE":
                        case "TRANSFER_FAILURE_REASON_EXTERNAL_FILESYSTEM_WRITE":
                        case "TRANSFER_FAILURE_REASON_PLAYABILITY":
                        case "TRANSFER_FAILURE_REASON_TOO_MANY_RETRIES":
                            var n = !1;
                            break a;
                        default:
                            n = !0
                    }
                    return n && Dpb(c) ? g.F(m, W6(c, "TRANSFER_STATE_TRANSFER_IN_QUEUE"), 8) : g.F(m,
                        Epb(c, a), 5);
                case 5:
                    if (!f || !c.C) {
                        m.Fa(2);
                        break
                    }
                    return g.F(m, q6(f, c.C, c.B, "DOWNLOAD_STATE_FAILED"), 2);
                case 8:
                    return g.F(m, U6(c, f), 9);
                case 9:
                    h = m.B;
                    l6({
                        transferStatusType: "TRANSFER_STATUS_TYPE_REENQUEUED_BY_RETRY"
                    }, {
                        videoId: f,
                        lm: d,
                        offlineModeType: h
                    });
                    if (!f || !c.C) {
                        m.Fa(2);
                        break
                    }
                    return g.F(m, q6(f, c.C, c.B, "DOWNLOAD_STATE_RETRYABLE_FAILURE"), 2);
                case 2:
                    S6(c), l = T6(c, !0), b && b(l), g.va(m)
            }
        })
    };
    g.k.CS = function(a) {
        var b = this,
            c, d, e, f, h, l, m, n, p, q, r, t;
        return g.J(function(u) {
            switch (u.j) {
                case 1:
                    if (!b.j) {
                        V6(b, "onMaybeTransferStreamsExpired");
                        u.Fa(2);
                        break
                    }
                    return Dpb(b) ? g.F(u, W6(b, "TRANSFER_STATE_WAITING_FOR_PLAYER_RESPONSE_REFRESH"), 9) : g.F(u, Epb(b, "TRANSFER_FAILURE_REASON_STREAM_MISSING"), 5);
                case 5:
                    if (!b.C) {
                        u.Fa(2);
                        break
                    }
                    c = b.j;
                    e = ((d = c) == null ? 0 : d.key) ? g.FK(c.key).entityId : "";
                    if (!e) {
                        u.Fa(2);
                        break
                    }
                    return g.F(u, q6(e, b.C, b.B, "DOWNLOAD_STATE_FAILED"), 2);
                case 9:
                    return b.j || V6(b, "onMaybeTransferStreamsExpiredRetryAttempting"),
                        f = b.j, l = ((h = f) == null ? 0 : h.key) ? g.FK(f.key).entityId : "", g.F(u, U6(b, l), 10);
                case 10:
                    return m = u.B, l6({
                        transferStatusType: "TRANSFER_STATUS_TYPE_DEQUEUED_BY_PLAYER_RESPONSE_EXPIRATION"
                    }, {
                        videoId: l,
                        lm: f,
                        offlineModeType: m
                    }), n = Dnb(), g.Nw(n, M6, {
                        isEnqueuedForExpiredStreamUrlRefetch: !0
                    }), p = g.GK(l, "playbackData"), q = {
                        actionType: "OFFLINE_ORCHESTRATION_ACTION_TYPE_ADD",
                        entityKey: p,
                        actionMetadata: n
                    }, r = w6(new u6("playbackData", l, q)), g.F(u, $5(b.B, r, "offlineOrchestrationActionWrapperEntity"), 2);
                case 2:
                    S6(b), t = T6(b, !0),
                        a && a(t), g.va(u)
            }
        })
    };
    var Iqb = {},
        Fpb = (Iqb.TRANSFER_STATE_TRANSFERRING = 1, Iqb.TRANSFER_STATE_TRANSFER_IN_QUEUE = 2, Iqb);
    g.k = X6.prototype;
    g.k.qR = function() {
        return this.G.promise
    };
    g.k.CU = function() {
        if (this.B && this.N) return this.G.promise;
        Ipb(this).then(this.G.resolve).catch(this.G.reject);
        return this.G.promise
    };
    g.k.DF = function(a) {
        var b = {};
        return b.playbackData = new qob(a, this.X, this.j), b.transfer = new Hob(a, this.X), b.videoPlaybackPositionEntity = new vob(a, this.X), b
    };
    g.k.PT = function() {
        var a = this;
        return g.J(function(b) {
            return a.B ? g.F(b, rpb(a.B), 0) : b.Fa(0)
        })
    };
    g.k.GU = function() {
        var a = this,
            b, c;
        return g.J(function(d) {
            if (d.j == 1) return a.B || a.N ? g.F(d, a.qR(), 2) : d.return();
            a.Z !== void 0 && (g.rr(a.Z), a.Z = void 0);
            a.D !== void 0 && (g.rr(a.D), a.D = void 0);
            (b = a.B) == null || b.dispose();
            a.B = void 0;
            (c = a.N) == null || c.dispose();
            a.N = void 0;
            a.api.gb("onOrchestrationLostLeader");
            a.G = new g.oj;
            g.va(d)
        })
    };
    g.k.isOrchestrationLeader = function() {
        return this.C.j
    };
    g.k.AV = function() {
        return g.J(function(a) {
            return a.return(!1)
        })
    };
    g.k.fT = function(a) {
        var b = this.j;
        b.api.publish("offlinetransferpause", a);
        var c;
        (c = b.B) == null || c.postMessage(a)
    };
    g.k.KH = function(a) {
        var b, c;
        return g.J(function(d) {
            if (d.j == 1) return g.F(d, c6(), 2);
            b = d.B;
            if (!b) return d.return();
            c = g.GK(a, "transfer");
            return g.F(d, Z5(b, {
                mode: "readwrite",
                Pb: !0
            }, function(e) {
                var f = S5(e, c, "transfer"),
                    h = S5(e, g.GK(a, "videoDownloadContextEntity"), "videoDownloadContextEntity");
                return g.zt.all([f, h]).then(function(l) {
                    l = g.w(l);
                    var m = l.next().value;
                    var n = l.next().value;
                    return m && m.transferState === "TRANSFER_STATE_PAUSED_BY_USER" ? (m.transferState = "TRANSFER_STATE_TRANSFER_IN_QUEUE", V5(e, m, "transfer").then(function() {
                        l6({
                            transferStatusType: "TRANSFER_STATUS_TYPE_REENQUEUED_BY_USER_RESUME",
                            statusType: "USER_RESUMED"
                        }, {
                            videoId: a,
                            lm: m,
                            offlineModeType: n == null ? void 0 : n.offlineModeType
                        });
                        return g.zt.resolve(null)
                    })) : g.zt.resolve(null)
                })
            }), 0)
        })
    };
    g.k.yT = function(a) {
        a = a === void 0 ? 43200 : a;
        var b = this,
            c, d, e, f, h, l, m, n;
        return g.J(function(p) {
            if (p.j == 1) return b.K.ph() ? g.F(p, c6(), 2) : p.return(Jpb());
            if (p.j != 3) {
                c = p.B;
                if (!c) return p.return([]);
                d = Date.now() / 1E3;
                return g.F(p, b6(c, "offlineVideoPolicy"), 3)
            }
            e = p.B;
            f = [];
            h = g.w(e);
            for (l = h.next(); !l.done; l = h.next()) m = l.value, Number(m.lastUpdatedTimestampSeconds) + a <= d && (n = g.FK(m.key).entityId, f.push(n));
            return f.length ? p.return(Y6(b, f, b.Y, "OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH")) : p.return([])
        })
    };
    g.k.deleteAll = function() {
        return Y6(this, ["!*$_ALL_ENTITIES_!*$"], this.Y, "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE", {
            offlineLoggingData: {
                offlineDeleteReason: "OFFLINE_DELETE_REASON_USER_INITIATED"
            }
        })
    };
    g.k.refreshAllStaleEntities = function(a) {
        var b = this;
        return g.J(function(c) {
            return c.j == 1 ? g.F(c, b.yT(a), 2) : c.return(c.B)
        })
    };
    g.k.setUpPositionSyncInterval = function(a) {
        var b = this;
        this.D !== void 0 && (g.rr(this.D), this.D = void 0);
        var c = a != null ? a : 864E5;
        this.D = g.pr(function() {
            b.kN(c)
        }, c)
    };
    g.k.kN = function(a) {
        var b = this,
            c, d, e, f, h, l;
        return g.J(function(m) {
            switch (m.j) {
                case 1:
                    return g.wa(m, 2), g.F(m, O5.getInstance(), 4);
                case 4:
                    c = m.B;
                    if (!c) throw Error("prefStorage is undefined");
                    return g.F(m, c.get("psi"), 5);
                case 5:
                    d = m.B;
                    f = ((e = d) == null ? 0 : e.FR) ? Number(d.FR) / 1E3 : 0;
                    h = Date.now();
                    if (!(f + a <= h)) {
                        m.Fa(6);
                        break
                    }
                    return g.F(m, Y6(b, ["!*$_ALL_ENTITIES_!*$"], "videoPlaybackPositionEntity", "OFFLINE_ORCHESTRATION_ACTION_TYPE_REFRESH"), 6);
                case 6:
                    g.xa(m, 0);
                    break;
                case 2:
                    l = g.ya(m), g6("Offline manager error", l),
                        g.va(m)
            }
        })
    };
    g.k.LT = function() {
        var a = this,
            b, c, d, e, f, h, l;
        return g.J(function(m) {
            if (m.j == 1) return g.F(m, c6(), 2);
            if (m.j != 3) return (b = m.B) ? g.F(m, b6(b, "transfer"), 3) : m.return([]);
            c = m.B;
            d = [];
            e = g.w(c);
            for (f = e.next(); !f.done; f = e.next()) h = f.value, h.transferState === "TRANSFER_STATE_WAITING_FOR_PLAYER_RESPONSE_REFRESH" && h.key && (l = g.FK(h.key).entityId, d.push(l));
            return m.return(Lpb(a, d))
        })
    };
    g.k.hP = function() {
        return g.J(function(a) {
            return a.return([])
        })
    };
    g.k.Z_ = function() {
        return g.J(function(a) {
            g.va(a)
        })
    };
    g.k.AX = function() {
        return g.J(function(a) {
            g.va(a)
        })
    };
    g.z(Mpb, J6);
    Mpb.prototype.B = function(a) {
        return n6(a) ? Ppb(this, a) : o6(a) ? Rpb(this, a) : p6(a) ? Spb(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    var Z6 = [10];
    g.z(Xpb, J6);
    Xpb.prototype.B = function(a) {
        return n6(a) ? $pb(this, a) : o6(a) ? aqb(this, a) : p6(a) ? bqb(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    var Zpb = [10];
    g.z(dqb, J6);
    dqb.prototype.B = function(a) {
        return o6(a) ? fqb(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    g.z(gqb, X6);
    g.k = gqb.prototype;
    g.k.DF = function(a) {
        var b = X6.prototype.DF.call(this, a);
        b.mainVideoEntity = new Xpb(a, this.X, this.j);
        b.mainPlaylistEntity = new Mpb(a, this.X, this.j);
        b.mainDownloadsListEntity = new dqb(a, this.X, this.j);
        return b
    };
    g.k.refreshAllStaleEntities = function(a, b) {
        var c = this,
            d, e, f, h, l, m, n, p, q, r, t;
        return g.J(function(u) {
            switch (u.j) {
                case 1:
                    d = [];
                    if (!c.X.L("web_player_offline_playlist_auto_refresh")) {
                        u.Fa(2);
                        break
                    }
                    return g.F(u, hqb(c, a, b), 3);
                case 3:
                    d = u.B;
                case 2:
                    return g.F(u, O5.getInstance(), 4);
                case 4:
                    return e = u.B, g.F(u, (f = e) == null ? void 0 : f.get("sdois"), 5);
                case 5:
                    return h = u.B, g.F(u, (l = e) == null ? void 0 : l.get("lmqf"), 6);
                case 6:
                    m = u.B;
                    if (!h) {
                        u.Fa(7);
                        break
                    }
                    p = d;
                    q = p.concat;
                    return g.F(u, iqb(c, h, (n = m) != null ? n : "SD", a === 0), 8);
                case 8:
                    d =
                        q.call(p, u.B);
                case 7:
                    return r = d, t = r.concat, g.F(u, X6.prototype.refreshAllStaleEntities.call(c, a, b), 9);
                case 9:
                    return d = t.call(r, u.B), u.return(d)
            }
        })
    };
    g.k.AV = function(a) {
        var b, c, d, e, f, h, l, m;
        return g.J(function(n) {
            if (n.j == 1) return g.F(n, c6(), 2);
            if (n.j != 3) return (b = n.B) ? g.F(n, a6(b, B6, "mainDownloadsListEntity"), 3) : n.return(!1);
            c = n.B;
            if ((d = c) == null ? 0 : (e = d.downloads) == null ? 0 : e.length)
                for (f = g.GK(a, "mainVideoEntity"), h = g.w(c.downloads), l = h.next(); !l.done; l = h.next())
                    if (m = l.value, m.videoItem === f) return n.return(!0);
            return n.return(!1)
        })
    };
    g.k.hP = function() {
        var a = this,
            b, c, d, e, f, h, l, m;
        return g.J(function(n) {
            if (n.j == 1) return g.F(n, c6(), 2);
            if (n.j != 3) return (b = n.B) ? g.F(n, b6(b, "downloadStatusEntity"), 3) : n.return([]);
            c = n.B;
            d = [];
            e = g.w(c);
            for (f = e.next(); !f.done; f = e.next()) h = f.value, h.downloadState === "DOWNLOAD_STATE_USER_DELETED" && h.key && (l = g.FK(h.key).entityId, d.push(l));
            return d.length ? (m = {
                offlineLoggingData: {
                    offlineDeleteReason: "OFFLINE_DELETE_REASON_USER_INITIATED"
                }
            }, n.return(Y6(a, d, "mainVideoEntity", "OFFLINE_ORCHESTRATION_ACTION_TYPE_DELETE",
                m))) : n.return([])
        })
    };
    g.k.AX = function() {
        var a;
        return g.J(function(b) {
            return b.j == 1 ? g.F(b, c6(), 2) : (a = b.B) ? g.F(b, Z5(a, {
                mode: "readwrite",
                Pb: !0
            }, function(c) {
                return T5(c, "mainVideoEntity").then(function(d) {
                    var e = [];
                    d = g.w(d);
                    for (var f = d.next(); !f.done; f = d.next()) {
                        f = f.value;
                        var h = void 0;
                        (h = f.userState) != null && h.playbackPosition || (h = g.FK(f.key).entityId, h = {
                            key: g.GK(h, "videoPlaybackPositionEntity"),
                            videoId: h,
                            lastPlaybackPositionSeconds: "0"
                        }, e.push(V5(c, h, "videoPlaybackPositionEntity")), f.userState = {
                            playbackPosition: h.key
                        }, e.push(V5(c,
                            f, "mainVideoEntity")))
                    }
                    return g.zt.all(e)
                })
            }), 0) : b.return()
        })
    };
    g.k.Z_ = function() {
        var a, b, c, d, e, f, h, l, m, n, p, q, r, t, u, y, B, C, G, H, N, M, X, W, fa, pa, ba, R, V, v, U, bb, yb, lb, Ea, cb, rb, Za;
        return g.J(function(A) {
            if (A.j == 1) return g.F(A, c6(), 2);
            if (A.j != 3) {
                a = A.B;
                if (!a) return A.return();
                b = g.GK("DOWNLOADS_LIST_ENTITY_ID_MANUAL_DOWNLOADS", "mainDownloadsListEntity");
                return g.F(A, Z5(a, {
                    mode: "readonly",
                    Pb: !0
                }, function(D) {
                    return g.zt.all([S5(D, b, "mainDownloadsListEntity"), S5(D, B6, "mainDownloadsListEntity"), T5(D, "mainVideoEntity"), T5(D, "mainPlaylistEntity")])
                }), 3)
            }
            c = A.B;
            d = g.w(c);
            e = d.next().value;
            f = d.next().value;
            h = d.next().value;
            l = d.next().value;
            m = e;
            n = f;
            p = h;
            q = l;
            r = new Set;
            if ((t = m) == null ? 0 : (u = t.downloads) == null ? 0 : u.length)
                for (y = g.w(m.downloads), B = y.next(); !B.done; B = y.next()) C = B.value, G = void 0, (H = (G = C.videoItem) != null ? G : C.playlistItem) && r.add(H);
            if ((N = n) == null ? 0 : (M = N.downloads) == null ? 0 : M.length)
                for (X = g.w(n.downloads), W = X.next(); !W.done; W = X.next()) fa = W.value, fa.videoItem && r.add(fa.videoItem);
            pa = new Set;
            ba = [];
            R = g.w(q);
            for (V = R.next(); !V.done; V = R.next()) {
                v = V.value;
                if (v.videos)
                    for (U =
                        g.w(v.videos), bb = U.next(); !bb.done; bb = U.next()) yb = bb.value, (lb = JSON.parse(g.FK(yb).entityId).videoId) && pa.add(lb);
                v.key && !r.has(v.key) && ba.push(v.key)
            }
            Ea = g.w(p);
            for (cb = Ea.next(); !cb.done; cb = Ea.next()) rb = cb.value, rb.key && !r.has(rb.key) && (Za = g.FK(rb.key).entityId, pa.has(Za) || ba.push(rb.key));
            return ba.length ? g.F(A, Rnb(a, ba), 0) : A.Fa(0)
        })
    };
    g.z(jqb, J6);
    jqb.prototype.B = function(a) {
        return n6(a) ? lqb(this, a) : o6(a) ? mqb(this, a) : p6(a) ? nqb(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    var a7 = [10];
    g.z(pqb, J6);
    pqb.prototype.B = function(a) {
        return n6(a) ? rqb(this, a) : o6(a) ? sqb(this, a) : p6(a) ? tqb(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    var b7 = [10];
    g.z(wqb, J6);
    wqb.prototype.B = function(a) {
        return n6(a) ? Aqb(this, a) : o6(a) ? Bqb(this, a) : p6(a) ? Cqb(this, a) : Promise.reject(Error("Unsupported action type: " + a.actionType))
    };
    var zqb = [10];
    g.z(c7, X6);
    c7.prototype.DF = function(a) {
        var b = X6.prototype.DF.call(this, a);
        b.musicTrack = new wqb(a, this.j);
        b.musicPlaylist = new pqb(a, this.j);
        b.musicAlbumRelease = new jqb(a, this.j);
        return b
    };
    c7.prototype.refreshAllStaleEntities = function(a, b) {
        var c = this,
            d, e, f;
        return g.J(function(h) {
            if (h.j == 1) return g.F(h, Eqb(c, a, b), 2);
            if (h.j != 3) return e = d = h.B, f = e.concat, g.F(h, X6.prototype.refreshAllStaleEntities.call(c, a, b), 3);
            d = f.call(e, h.B);
            return h.return(d)
        })
    };
    g.z(Fqb, g.VX);
    g.k = Fqb.prototype;
    g.k.create = function() {
        var a = this;
        g.P(this, this.events);
        g.qP(this.X) ? this.j = new gqb(this.X, this.player) : g.Ly(this.X) && (this.j = new c7(this.X, this.player));
        this.events.T(this.player, "onPlaybackStartExternal", function() {
            a.LK()
        });
        this.events.T(this.player, "videodatachange", function() {
            a.LK()
        });
        this.X.L("html5_offline_playback_position_sync") && this.events.T(this.player, "presentingplayerstatechange", this.PQ)
    };
    g.k.Dn = function() {
        return !1
    };
    g.k.S1 = function(a, b, c, d) {
        var e = this;
        return g.J(function(f) {
            return e.j ? f.return(Y6(e.j, a, b, c, d)) : f.return(Promise.reject())
        })
    };
    g.k.deleteAll = function() {
        return this.j.deleteAll()
    };
    g.k.yT = function(a) {
        return this.j.yT(a)
    };
    g.k.refreshAllStaleEntities = function(a) {
        return this.j.refreshAllStaleEntities(a)
    };
    g.k.setUpPositionSyncInterval = function(a) {
        this.j.setUpPositionSyncInterval(a)
    };
    g.k.fT = function(a) {
        this.j.fT(a)
    };
    g.k.KH = function(a) {
        return this.j.KH(a)
    };
    g.k.LK = function() {
        var a = this,
            b;
        return g.J(function(c) {
            b = a.player.getVideoData();
            return g.mR(b) ? Gqb(b) && a.B !== b.clientPlaybackNonce ? g.F(c, Hqb(a, b), 0) : c.Fa(0) : c.return()
        })
    };
    g.k.PQ = function(a) {
        var b = this,
            c, d, e, f;
        return g.J(function(h) {
            if (!g.py(a, 2) && !g.py(a, 512)) return h.return();
            c = Math.floor(b.player.getCurrentTime()).toString();
            d = b.player.getVideoData();
            e = d.videoId;
            f = {
                videoPlaybackPositionEntityActionMetadata: {
                    lastPlaybackPositionSeconds: c
                }
            };
            return g.F(h, b.S1([e], "videoPlaybackPositionEntity", "OFFLINE_ORCHESTRATION_ACTION_TYPE_UPDATE", f), 0)
        })
    };
    g.k.isOrchestrationLeader = function() {
        return this.j.isOrchestrationLeader()
    };
    g.k.updateDownloadState = function(a, b) {
        var c, d, e, f;
        return g.J(function(h) {
            if (h.j == 1) return g.F(h, c6(), 2);
            c = h.B;
            if (!c) return g6("PES is undefined"), h.return();
            d = g.FK(a);
            e = d.entityType;
            f = d.entityId;
            return g.F(h, q6(f, e, c, b, !0), 0)
        })
    };
    g.UX("offline", Fqb);
})(_yt_player);